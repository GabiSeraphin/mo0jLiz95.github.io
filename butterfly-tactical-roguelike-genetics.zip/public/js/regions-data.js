// ════════════════════════════════════════════════════════════════
// REGIONS DATA - Copie este arquivo para seu projeto!
// Versão JavaScript pura para usar com seu código existente
// ════════════════════════════════════════════════════════════════

const REGIONS = {
  jardim_encantado: {
    id: 'jardim_encantado',
    name: 'Enchanted Garden',
    namePt: 'Jardim Encantado',
    desc: 'A peaceful garden full of flowers and friendly creatures.',
    descPt: 'Um jardim tranquilo cheio de flores e criaturas amigáveis.',
    icon: '🌸',
    iconImg: '/images/regions/garden.png',
    
    // Aventura
    duration: 30000,
    nectarCost: 10,
    dangerLevel: 1,
    deathChance: 0.02,
    butterflyChance: 0.3,
    seedChance: 0.4,
    
    // Dungeon
    floors: 3,
    roomsPerFloor: 5,
    
    // Visual
    backgroundColor: '#e8f5e9',
    ambientColor: '#a5d6a7',
    particleEmoji: ['🌸', '🌺', '🌷', '🦋', '✨', '🌼'],
    
    // Tiles
    tiles: [
      { id: 'grass', name: 'Grama', emoji: '🌿', color: '#7cb342', walkable: true, spawnWeight: 50 },
      { id: 'flower_pink', name: 'Flor Rosa', emoji: '🌸', color: '#f8bbd9', walkable: true, 
        effect: { type: 'heal', value: 5, message: 'A flor te cura!' }, spawnWeight: 15 },
      { id: 'flower_yellow', name: 'Girassol', emoji: '🌻', color: '#fff59d', walkable: true,
        effect: { type: 'buff', value: 1, message: 'Energizado pela luz!' }, spawnWeight: 10 },
      { id: 'flower_red', name: 'Rosa', emoji: '🌹', color: '#ef5350', walkable: true,
        effect: { type: 'nectar', value: 2, message: '+2 Néctar de Rosa!' }, spawnWeight: 8 },
      { id: 'bush', name: 'Arbusto', emoji: '🌳', color: '#558b2f', walkable: false, spawnWeight: 10 },
      { id: 'pond', name: 'Lago', emoji: '💧', color: '#4fc3f7', walkable: false, spawnWeight: 5 },
      { id: 'mushroom', name: 'Cogumelo', emoji: '🍄', color: '#d7ccc8', walkable: true,
        effect: { type: 'heal', value: 10, message: 'Cogumelo curativo!' }, spawnWeight: 2 }
    ],
    
    // Traits Exclusivas
    exclusiveTraits: [
      { id: 'garden_blessing', name: 'Garden Blessing', namePt: 'Bênção do Jardim',
        description: 'Esta borboleta carrega a bênção do jardim.',
        rarity: 'uncommon', statBonus: { fertility: 0.1, beauty: 5 }, combatBonus: { healing: 10 } },
      { id: 'petal_wings', name: 'Petal Wings', namePt: 'Asas de Pétala',
        description: 'Asas que brilham como pétalas de flores.',
        rarity: 'rare', statBonus: { beauty: 15, agility: 3 }, combatBonus: { dodge: 5 } },
      { id: 'nectar_collector', name: 'Expert Nectar Collector', namePt: 'Coletor de Néctar Expert',
        description: 'Excepcionalmente habilidoso em coletar néctar.',
        rarity: 'common', statBonus: { stamina: 5 } }
    ],
    
    // Sementes
    seeds: ['rosa', 'girassol', 'margarida'],
    
    // Cores e Padrões Exclusivos
    exclusiveColors: ['#FFB6C1', '#FFC0CB', '#FF69B4', '#FFD700', '#98FB98'],
    exclusivePatterns: ['spotted_pink', 'striped_gold', 'gradient_spring'],
    
    // Inimigos
    enemies: [
      { id: 'bee', name: 'Worker Bee', namePt: 'Abelha Operária', emoji: '🐝',
        hp: 30, attack: 8, defense: 3, speed: 4, abilities: ['sting', 'buzz'], dropChance: 0.3 },
      { id: 'ladybug', name: 'Angry Ladybug', namePt: 'Joaninha Irritada', emoji: '🐞',
        hp: 25, attack: 6, defense: 5, speed: 3, abilities: ['shell_defense'], dropChance: 0.2 },
      { id: 'caterpillar', name: 'Hungry Caterpillar', namePt: 'Lagarta Faminta', emoji: '🐛',
        hp: 40, attack: 5, defense: 2, speed: 2, abilities: ['munch', 'curl'], dropChance: 0.25 }
    ],
    
    // Boss
    boss: {
      id: 'queen_bee',
      name: 'Queen Bee',
      namePt: 'Abelha Rainha',
      emoji: '👑🐝',
      title: 'Ruler of the Garden',
      titlePt: 'Governante do Jardim',
      hp: 200,
      attack: 15,
      defense: 8,
      speed: 3,
      phases: [
        { hpPercent: 75, message: 'You dare challenge the Queen?!', messagePt: 'Vocês ousam desafiar a Rainha?!',
          attackBonus: 1.2, newAbility: 'summon_swarm' },
        { hpPercent: 40, message: 'My subjects will destroy you!', messagePt: 'Meus súditos irão destruí-los!',
          attackBonus: 1.5, newAbility: 'royal_fury' }
      ],
      abilities: [
        { name: 'Royal Sting', namePt: 'Ferrão Real', damage: 25, range: 2, cooldown: 2, effect: 'poison' },
        { name: 'Summon Swarm', namePt: 'Invocar Enxame', damage: 10, range: 5, cooldown: 4, aoe: 3 },
        { name: 'Honey Trap', namePt: 'Armadilha de Mel', damage: 5, range: 3, cooldown: 3, effect: 'slow', aoe: 2 }
      ],
      dialogue: {
        intro: 'Intruders in MY garden?! You will become food for my larvae!',
        introPt: 'Invasores no MEU jardim?! Vocês se tornarão comida para minhas larvas!',
        phase2: 'ENOUGH! Feel the wrath of the hive!',
        phase2Pt: 'CHEGA! Sintam a fúria da colmeia!',
        death: 'The garden... will remember... my reign...',
        deathPt: 'O jardim... lembrará... do meu reinado...'
      },
      loot: { nectar: { min: 50, max: 100, type: 'basic' }, seedChance: 0.8, butterflyChance: 0.5, exclusiveTraitChance: 0.3 }
    },
    
    unlockRequirement: null // Starting region
  },

  floresta_sombria: {
    id: 'floresta_sombria',
    name: 'Shadow Forest',
    namePt: 'Floresta Sombria',
    desc: 'A dark forest where light barely penetrates the canopy.',
    descPt: 'Uma floresta escura onde a luz mal penetra o dossel.',
    icon: '🌲',
    iconImg: '/images/regions/forest.png',
    
    duration: 60000,
    nectarCost: 25,
    dangerLevel: 2,
    deathChance: 0.08,
    butterflyChance: 0.25,
    seedChance: 0.3,
    
    floors: 4,
    roomsPerFloor: 6,
    
    backgroundColor: '#1b2a1b',
    ambientColor: '#2e4a2e',
    particleEmoji: ['🍂', '🌲', '🦉', '🕸️', '✨', '🍃'],
    
    tiles: [
      { id: 'dark_grass', name: 'Grama Escura', emoji: '🌑', color: '#2d3a2d', walkable: true, spawnWeight: 45 },
      { id: 'dead_leaves', name: 'Folhas Mortas', emoji: '🍂', color: '#5d4037', walkable: true, spawnWeight: 20 },
      { id: 'mushroom_glow', name: 'Cogumelo Brilhante', emoji: '🍄', color: '#7c4dff', walkable: true,
        effect: { type: 'buff', value: 2, message: 'Energia mística flui através de você!' }, spawnWeight: 8 },
      { id: 'spider_web', name: 'Teia de Aranha', emoji: '🕸️', color: '#e0e0e0', walkable: true,
        effect: { type: 'debuff', value: 2, message: 'Preso na teia! Velocidade reduzida!' }, spawnWeight: 10 },
      { id: 'tree_trunk', name: 'Tronco de Árvore', emoji: '🌲', color: '#3e2723', walkable: false, spawnWeight: 12 },
      { id: 'hollow_log', name: 'Tronco Oco', emoji: '🪵', color: '#4e342e', walkable: true,
        effect: { type: 'heal', value: 8, message: 'Descanse no tronco oco...' }, spawnWeight: 5 }
    ],
    
    exclusiveTraits: [
      { id: 'shadow_cloak', name: 'Shadow Cloak', namePt: 'Manto das Sombras',
        description: 'Pode se misturar às sombras para proteção.',
        rarity: 'rare', statBonus: { stamina: 8 }, combatBonus: { dodge: 15, stealth: 20 } },
      { id: 'night_vision', name: 'Night Vision', namePt: 'Visão Noturna',
        description: 'Pode ver perfeitamente no escuro.',
        rarity: 'uncommon', statBonus: { agility: 5 }, combatBonus: { accuracy: 10 } },
      { id: 'forest_whisper', name: 'Forest Whisper', namePt: 'Sussurro da Floresta',
        description: 'Pode se comunicar com criaturas da floresta.',
        rarity: 'legendary', statBonus: { beauty: 10, stamina: 10 }, combatBonus: { charm: 25 } }
    ],
    
    seeds: ['cogumelo_lunar', 'erva_sombria'],
    
    exclusiveColors: ['#2c2c2c', '#4a4a4a', '#6b4c9a', '#1a1a2e', '#483d8b'],
    exclusivePatterns: ['shadow_swirl', 'night_spots', 'web_pattern'],
    
    enemies: [
      { id: 'shadow_spider', name: 'Shadow Spider', namePt: 'Aranha das Sombras', emoji: '🕷️',
        hp: 35, attack: 12, defense: 4, speed: 5, abilities: ['web_shot', 'poison_bite', 'ambush'], dropChance: 0.3 },
      { id: 'dark_moth', name: 'Dark Moth', namePt: 'Mariposa Sombria', emoji: '🦋',
        hp: 28, attack: 10, defense: 3, speed: 6, abilities: ['dust_cloud', 'drain_life'], dropChance: 0.25 },
      { id: 'forest_spirit', name: 'Forest Spirit', namePt: 'Espírito da Floresta', emoji: '👻',
        hp: 45, attack: 14, defense: 6, speed: 3, abilities: ['haunt', 'curse', 'phase'], dropChance: 0.35 }
    ],
    
    boss: {
      id: 'spider_queen',
      name: 'Arachne the Weaver',
      namePt: 'Arachne a Tecelã',
      emoji: '🕷️👑',
      title: 'Queen of Webs',
      titlePt: 'Rainha das Teias',
      hp: 350,
      attack: 22,
      defense: 12,
      speed: 5,
      phases: [
        { hpPercent: 70, message: 'My children, come feast!', messagePt: 'Meus filhos, venham festejar!',
          attackBonus: 1.3, newAbility: 'spawn_spiderlings' },
        { hpPercent: 35, message: 'I will wrap you in eternal darkness!', messagePt: 'Eu irei envolvê-los em escuridão eterna!',
          attackBonus: 1.8, newAbility: 'cocoon_prison' }
      ],
      abilities: [
        { name: 'Venomous Fangs', namePt: 'Presas Venenosas', damage: 30, range: 2, cooldown: 2, effect: 'poison' },
        { name: 'Web Prison', namePt: 'Prisão de Teia', damage: 15, range: 4, cooldown: 3, effect: 'stun', aoe: 2 },
        { name: 'Shadow Step', namePt: 'Passo das Sombras', damage: 20, range: 6, cooldown: 4 }
      ],
      dialogue: {
        intro: 'Welcome to my parlor, little butterflies... You shall never leave!',
        introPt: 'Bem-vindos ao meu lar, pequenas borboletas... Vocês nunca sairão!',
        death: 'My web... unravels... but darkness... remains...',
        deathPt: 'Minha teia... se desfaz... mas a escuridão... permanece...'
      },
      loot: { nectar: { min: 80, max: 150, type: 'FlordaLua' }, seedChance: 0.7, butterflyChance: 0.4, exclusiveTraitChance: 0.4 }
    },
    
    unlockRequirement: { type: 'boss', value: 'queen_bee', descriptionPt: 'Derrote a Abelha Rainha' }
  },

  caverna_cristalina: {
    id: 'caverna_cristalina',
    name: 'Crystal Cavern',
    namePt: 'Caverna Cristalina',
    desc: 'Sparkling caves filled with magical crystals.',
    descPt: 'Cavernas cintilantes cheias de cristais mágicos.',
    icon: '💎',
    iconImg: '/images/regions/crystal.png',
    
    duration: 90000,
    nectarCost: 40,
    dangerLevel: 3,
    deathChance: 0.12,
    butterflyChance: 0.2,
    seedChance: 0.25,
    
    floors: 5,
    roomsPerFloor: 7,
    
    backgroundColor: '#1a1a2e',
    ambientColor: '#4a4e69',
    particleEmoji: ['💎', '✨', '💠', '🔮', '⚡', '🌟'],
    
    tiles: [
      { id: 'cave_floor', name: 'Chão de Caverna', emoji: '🪨', color: '#37474f', walkable: true, spawnWeight: 40 },
      { id: 'crystal_blue', name: 'Cristal Azul', emoji: '💎', color: '#00bcd4', walkable: true,
        effect: { type: 'buff', value: 3, message: 'Energia cristalina te fortalece!' }, spawnWeight: 12 },
      { id: 'crystal_purple', name: 'Cristal Roxo', emoji: '🔮', color: '#9c27b0', walkable: true,
        effect: { type: 'heal', value: 15, message: 'Cura mágica!' }, spawnWeight: 8 },
      { id: 'crystal_spike', name: 'Espinho de Cristal', emoji: '🗡️', color: '#b388ff', walkable: true,
        effect: { type: 'damage', value: 10, message: 'Cristal afiado te corta!' }, spawnWeight: 10 },
      { id: 'stalagmite', name: 'Estalagmite', emoji: '🗿', color: '#455a64', walkable: false, spawnWeight: 15 },
      { id: 'crystal_pool', name: 'Lago de Cristal', emoji: '💠', color: '#4dd0e1', walkable: true,
        effect: { type: 'heal', value: 20, message: 'O lago restaura sua energia!' }, spawnWeight: 5 },
      { id: 'gem_deposit', name: 'Depósito de Gemas', emoji: '💰', color: '#ffd700', walkable: true,
        effect: { type: 'nectar', value: 5, message: '+5 Néctar de Cristal!' }, spawnWeight: 3 }
    ],
    
    exclusiveTraits: [
      { id: 'crystal_wings', name: 'Crystal Wings', namePt: 'Asas de Cristal',
        description: 'Asas feitas de cristal puro que refletem luz.',
        rarity: 'legendary', statBonus: { beauty: 25, stamina: 5 }, combatBonus: { defense: 10, reflect: 15 } },
      { id: 'gem_sense', name: 'Gem Sense', namePt: 'Sentido de Gemas',
        description: 'Pode detectar gemas e tesouros valiosos.',
        rarity: 'rare', statBonus: { agility: 8 } },
      { id: 'resonance', name: 'Crystal Resonance', namePt: 'Ressonância Cristalina',
        description: 'Harmoniza com energia cristalina.',
        rarity: 'uncommon', statBonus: { stamina: 10 }, combatBonus: { magicPower: 15 } }
    ],
    
    seeds: ['flor_cristal', 'musgo_brilhante'],
    
    exclusiveColors: ['#00bcd4', '#9c27b0', '#e91e63', '#3f51b5', '#00e5ff'],
    exclusivePatterns: ['crystal_facets', 'gem_sparkle', 'prismatic_gradient'],
    
    enemies: [
      { id: 'crystal_golem', name: 'Crystal Golem', namePt: 'Golem de Cristal', emoji: '🗿',
        hp: 60, attack: 18, defense: 15, speed: 2, abilities: ['crystal_smash', 'harden', 'reflect'], dropChance: 0.35 },
      { id: 'gem_beetle', name: 'Gem Beetle', namePt: 'Besouro de Gemas', emoji: '🪲',
        hp: 35, attack: 14, defense: 10, speed: 4, abilities: ['gem_spit', 'burrow'], dropChance: 0.3 },
      { id: 'cave_bat', name: 'Crystal Bat', namePt: 'Morcego de Cristal', emoji: '🦇',
        hp: 25, attack: 12, defense: 5, speed: 7, abilities: ['sonic_screech', 'drain'], dropChance: 0.25 }
    ],
    
    boss: {
      id: 'crystal_guardian',
      name: 'Prismatic Guardian',
      namePt: 'Guardião Prismático',
      emoji: '💎🗿',
      title: 'Keeper of the Crystals',
      titlePt: 'Guardião dos Cristais',
      hp: 500,
      attack: 28,
      defense: 20,
      speed: 3,
      phases: [
        { hpPercent: 65, message: 'The crystals... they sing... of your destruction!',
          messagePt: 'Os cristais... eles cantam... sobre sua destruição!', attackBonus: 1.4 },
        { hpPercent: 30, message: 'I AM the mountain! I AM eternal!',
          messagePt: 'EU SOU a montanha! EU SOU eterno!', attackBonus: 2.0 }
      ],
      abilities: [
        { name: 'Crystal Slam', namePt: 'Pancada de Cristal', damage: 35, range: 2, cooldown: 2, aoe: 2 },
        { name: 'Gem Barrage', namePt: 'Barragem de Gemas', damage: 20, range: 5, cooldown: 3, aoe: 3 },
        { name: 'Crystallize', namePt: 'Cristalizar', damage: 0, range: 4, cooldown: 5, effect: 'stun', aoe: 2 }
      ],
      dialogue: {
        introPt: 'POR MILÊNIOS EU GUARDEI ESTES SALÕES. VOCÊS NÃO PASSARÃO!',
        deathPt: 'Os cristais... irão... lembrar...'
      },
      loot: { nectar: { min: 120, max: 200, type: 'Cristal' }, seedChance: 0.6, butterflyChance: 0.35, exclusiveTraitChance: 0.5 }
    },
    
    unlockRequirement: { type: 'boss', value: 'spider_queen', descriptionPt: 'Derrote Arachne a Tecelã' }
  },

  pantano_misterioso: {
    id: 'pantano_misterioso',
    name: 'Mysterious Swamp',
    namePt: 'Pântano Misterioso',
    desc: 'A toxic swamp filled with strange creatures and poisonous plants.',
    descPt: 'Um pântano tóxico cheio de criaturas estranhas e plantas venenosas.',
    icon: '🐸',
    iconImg: '/images/regions/swamp.png',
    
    duration: 120000,
    nectarCost: 60,
    dangerLevel: 4,
    deathChance: 0.18,
    butterflyChance: 0.18,
    seedChance: 0.35,
    
    floors: 5,
    roomsPerFloor: 8,
    
    backgroundColor: '#1a3a1a',
    ambientColor: '#4a6a4a',
    particleEmoji: ['🐸', '🦎', '💀', '🌿', '💧', '🦟'],
    
    tiles: [
      { id: 'swamp_mud', name: 'Lama', emoji: '🟤', color: '#5d4037', walkable: true,
        effect: { type: 'debuff', value: 1, message: 'Lama te deixa lento!' }, spawnWeight: 35 },
      { id: 'toxic_water', name: 'Água Tóxica', emoji: '💚', color: '#7cb342', walkable: true,
        effect: { type: 'damage', value: 8, message: 'Água tóxica queima!' }, spawnWeight: 20 },
      { id: 'lily_pad', name: 'Vitória-régia', emoji: '🌸', color: '#66bb6a', walkable: true,
        effect: { type: 'heal', value: 5, message: 'Seguro na vitória-régia!' }, spawnWeight: 15 },
      { id: 'dead_tree', name: 'Árvore Morta', emoji: '🌳', color: '#3e2723', walkable: false, spawnWeight: 10 },
      { id: 'poison_mushroom', name: 'Cogumelo Venenoso', emoji: '🍄', color: '#7b1fa2', walkable: true,
        effect: { type: 'damage', value: 15, message: 'Esporos venenosos!' }, spawnWeight: 8 },
      { id: 'healing_moss', name: 'Musgo Curativo', emoji: '🌿', color: '#4caf50', walkable: true,
        effect: { type: 'heal', value: 12, message: 'Musgo medicinal te cura!' }, spawnWeight: 7 },
      { id: 'quicksand', name: 'Areia Movediça', emoji: '⚠️', color: '#795548', walkable: true,
        effect: { type: 'trap', value: 2, message: 'Preso na areia movediça!' }, spawnWeight: 5 }
    ],
    
    exclusiveTraits: [
      { id: 'poison_immunity', name: 'Poison Immunity', namePt: 'Imunidade a Veneno',
        description: 'Completamente imune a efeitos de veneno.',
        rarity: 'rare', statBonus: { stamina: 15 }, combatBonus: { poisonImmune: 100 } },
      { id: 'toxic_wings', name: 'Toxic Wings', namePt: 'Asas Tóxicas',
        description: 'Asas cobertas com toxinas naturais.',
        rarity: 'legendary', statBonus: { beauty: -5, stamina: 20 }, combatBonus: { poisonDamage: 25 } },
      { id: 'swamp_camouflage', name: 'Swamp Camouflage', namePt: 'Camuflagem do Pântano',
        description: 'Se mistura perfeitamente com o ambiente do pântano.',
        rarity: 'uncommon', statBonus: { agility: 10 }, combatBonus: { dodge: 20 } }
    ],
    
    seeds: ['lirio_venenoso', 'erva_pantano', 'flor_sapo'],
    
    exclusiveColors: ['#7cb342', '#558b2f', '#33691e', '#827717', '#9e9d24'],
    exclusivePatterns: ['toxic_spots', 'swamp_camo', 'poison_gradient'],
    
    enemies: [
      { id: 'poison_frog', name: 'Poison Dart Frog', namePt: 'Sapo Venenoso', emoji: '🐸',
        hp: 30, attack: 20, defense: 5, speed: 6, abilities: ['poison_spit', 'tongue_lash'], dropChance: 0.3 },
      { id: 'swamp_snake', name: 'Swamp Serpent', namePt: 'Serpente do Pântano', emoji: '🐍',
        hp: 45, attack: 22, defense: 8, speed: 5, abilities: ['constrict', 'venom_bite'], dropChance: 0.35 },
      { id: 'bog_monster', name: 'Bog Monster', namePt: 'Monstro do Pântano', emoji: '👹',
        hp: 70, attack: 18, defense: 12, speed: 2, abilities: ['mud_throw', 'swallow'], dropChance: 0.4 }
    ],
    
    boss: {
      id: 'swamp_witch',
      name: 'Murkmire the Swamp Witch',
      namePt: 'Murkmire a Bruxa do Pântano',
      emoji: '🧙‍♀️🐸',
      title: 'Mistress of Poisons',
      titlePt: 'Mestra dos Venenos',
      hp: 450,
      attack: 32,
      defense: 15,
      speed: 4,
      phases: [
        { hpPercent: 60, messagePt: 'Borbulha, borbulha, trabalho e confusão!', attackBonus: 1.5 },
        { hpPercent: 25, messagePt: 'VOCÊS SE JUNTARÃO À MINHA COLEÇÃO DE ESPÉCIMES!', attackBonus: 2.2 }
      ],
      abilities: [
        { name: 'Poison Brew', namePt: 'Poção Venenosa', damage: 25, range: 4, cooldown: 2, effect: 'poison', aoe: 2 },
        { name: 'Frog Curse', namePt: 'Maldição do Sapo', damage: 15, range: 5, cooldown: 4, effect: 'curse' },
        { name: 'Summon Familiars', namePt: 'Invocar Familiares', damage: 0, range: 6, cooldown: 5 }
      ],
      dialogue: {
        introPt: 'Ohohoho! Mais ingredientes para meu caldeirão! Que delícia!',
        deathPt: 'Minhas poções... minhas preciosas poções... *coaxar*'
      },
      loot: { nectar: { min: 150, max: 250, type: 'Veneno' }, seedChance: 0.75, butterflyChance: 0.3, exclusiveTraitChance: 0.55 }
    },
    
    unlockRequirement: { type: 'boss', value: 'crystal_guardian', descriptionPt: 'Derrote o Guardião Prismático' }
  },

  vulcao_ardente: {
    id: 'vulcao_ardente',
    name: 'Burning Volcano',
    namePt: 'Vulcão Ardente',
    desc: 'A dangerous volcanic region with rivers of lava.',
    descPt: 'Uma região vulcânica perigosa com rios de lava.',
    icon: '🌋',
    iconImg: '/images/regions/volcano.png',
    
    duration: 150000,
    nectarCost: 80,
    dangerLevel: 5,
    deathChance: 0.25,
    butterflyChance: 0.15,
    seedChance: 0.2,
    
    floors: 6,
    roomsPerFloor: 8,
    
    backgroundColor: '#2a0a0a',
    ambientColor: '#4a1a1a',
    particleEmoji: ['🔥', '🌋', '💨', '✨', '☄️', '💀'],
    
    tiles: [
      { id: 'volcanic_rock', name: 'Rocha Vulcânica', emoji: '🪨', color: '#424242', walkable: true, spawnWeight: 35 },
      { id: 'lava', name: 'Lava', emoji: '🔥', color: '#ff5722', walkable: true,
        effect: { type: 'damage', value: 25, message: 'QUEIMANDO na lava!' }, spawnWeight: 20 },
      { id: 'cooled_lava', name: 'Lava Resfriada', emoji: '⬛', color: '#212121', walkable: true, spawnWeight: 15 },
      { id: 'fire_vent', name: 'Respiradouro de Fogo', emoji: '💨', color: '#ff9800', walkable: true,
        effect: { type: 'damage', value: 15, message: 'Vapor quente queima!' }, spawnWeight: 10 },
      { id: 'obsidian', name: 'Obsidiana', emoji: '🖤', color: '#1a1a1a', walkable: false, spawnWeight: 10 },
      { id: 'fire_flower', name: 'Flor de Fogo', emoji: '🌺', color: '#ff4081', walkable: true,
        effect: { type: 'buff', value: 5, message: 'Energia de fogo te fortalece!' }, spawnWeight: 5 },
      { id: 'ash_pile', name: 'Pilha de Cinzas', emoji: '⚫', color: '#616161', walkable: true,
        effect: { type: 'nectar', value: 3, message: '+3 Néctar de Fogo!' }, spawnWeight: 5 }
    ],
    
    exclusiveTraits: [
      { id: 'flame_wings', name: 'Flame Wings', namePt: 'Asas de Chama',
        description: 'Asas feitas de fogo vivo.',
        rarity: 'legendary', statBonus: { beauty: 20, stamina: -5 }, combatBonus: { fireDamage: 30, burnImmune: 100 } },
      { id: 'heat_resistance', name: 'Heat Resistance', namePt: 'Resistência ao Calor',
        description: 'Pode suportar temperaturas extremas.',
        rarity: 'rare', statBonus: { stamina: 20 }, combatBonus: { fireResist: 50 } },
      { id: 'phoenix_blood', name: 'Phoenix Blood', namePt: 'Sangue de Fênix',
        description: 'Pode reviver uma vez por batalha.',
        rarity: 'legendary', statBonus: { stamina: 10, agility: 5 }, combatBonus: { revive: 1 } }
    ],
    
    seeds: ['flor_fogo', 'cinza_viva'],
    
    exclusiveColors: ['#ff5722', '#ff9800', '#ffc107', '#f44336', '#e91e63'],
    exclusivePatterns: ['flame_pattern', 'ember_spots', 'lava_flow'],
    
    enemies: [
      { id: 'fire_elemental', name: 'Fire Elemental', namePt: 'Elemental de Fogo', emoji: '🔥',
        hp: 50, attack: 28, defense: 10, speed: 5, abilities: ['fireball', 'flame_aura'], dropChance: 0.35 },
      { id: 'lava_slug', name: 'Lava Slug', namePt: 'Lesma de Lava', emoji: '🐌',
        hp: 80, attack: 20, defense: 18, speed: 1, abilities: ['lava_trail', 'melt'], dropChance: 0.3 },
      { id: 'ash_phoenix', name: 'Ash Phoenix', namePt: 'Fênix de Cinzas', emoji: '🐦‍🔥',
        hp: 40, attack: 25, defense: 8, speed: 7, abilities: ['phoenix_dive', 'rebirth'], dropChance: 0.4 }
    ],
    
    boss: {
      id: 'volcano_lord',
      name: 'Ignius the Volcano Lord',
      namePt: 'Ignius o Senhor do Vulcão',
      emoji: '🌋👑',
      title: 'Master of Flames',
      titlePt: 'Mestre das Chamas',
      hp: 600,
      attack: 40,
      defense: 22,
      speed: 4,
      phases: [
        { hpPercent: 70, messagePt: 'SINTAM O CALOR DE MIL SÓIS!', attackBonus: 1.5 },
        { hpPercent: 35, messagePt: 'ESTA MONTANHA É MEU CORPO! EU SOU ETERNO!', attackBonus: 2.5 }
      ],
      abilities: [
        { name: 'Magma Blast', namePt: 'Explosão de Magma', damage: 45, range: 3, cooldown: 2, effect: 'burn', aoe: 2 },
        { name: 'Lava Wave', namePt: 'Onda de Lava', damage: 35, range: 5, cooldown: 4, effect: 'burn', aoe: 4 },
        { name: 'Volcanic Rage', namePt: 'Fúria Vulcânica', damage: 0, range: 0, cooldown: 6 }
      ],
      dialogue: {
        introPt: 'MORTAIS OUSAM ENTRAR NO MEU DOMÍNIO?! VOCÊS SERÃO REDUZIDOS A CINZAS!',
        deathPt: 'A montanha... dorme... mas irá... despertar...'
      },
      loot: { nectar: { min: 200, max: 350, type: 'Fogo' }, seedChance: 0.5, butterflyChance: 0.25, exclusiveTraitChance: 0.6 }
    },
    
    unlockRequirement: { type: 'boss', value: 'swamp_witch', descriptionPt: 'Derrote Murkmire a Bruxa do Pântano' }
  },

  templo_celestial: {
    id: 'templo_celestial',
    name: 'Celestial Temple',
    namePt: 'Templo Celestial',
    desc: 'An ancient temple floating among the clouds, home to divine butterflies.',
    descPt: 'Um templo antigo flutuando entre as nuvens, lar das borboletas divinas.',
    icon: '🏛️',
    iconImg: '/images/regions/temple.png',
    
    duration: 200000,
    nectarCost: 120,
    dangerLevel: 6,
    deathChance: 0.3,
    butterflyChance: 0.12,
    seedChance: 0.15,
    
    floors: 7,
    roomsPerFloor: 10,
    
    backgroundColor: '#e8f4f8',
    ambientColor: '#b3e5fc',
    particleEmoji: ['✨', '⭐', '🌟', '💫', '☁️', '🦋'],
    
    tiles: [
      { id: 'cloud', name: 'Nuvem', emoji: '☁️', color: '#e3f2fd', walkable: true, spawnWeight: 35 },
      { id: 'marble', name: 'Piso de Mármore', emoji: '⬜', color: '#fafafa', walkable: true, spawnWeight: 25 },
      { id: 'starlight', name: 'Luz Estelar', emoji: '⭐', color: '#fff9c4', walkable: true,
        effect: { type: 'buff', value: 5, message: 'Abençoado pela luz das estrelas!' }, spawnWeight: 10 },
      { id: 'divine_pool', name: 'Lago Divino', emoji: '💠', color: '#80deea', walkable: true,
        effect: { type: 'heal', value: 30, message: 'Cura divina!' }, spawnWeight: 5 },
      { id: 'pillar', name: 'Pilar do Templo', emoji: '🏛️', color: '#d7ccc8', walkable: false, spawnWeight: 10 },
      { id: 'void', name: 'Vazio', emoji: '🕳️', color: '#1a1a2e', walkable: true,
        effect: { type: 'damage', value: 50, message: 'Caindo no vazio!' }, spawnWeight: 8 },
      { id: 'celestial_flower', name: 'Flor Celestial', emoji: '🌸', color: '#f8bbd9', walkable: true,
        effect: { type: 'nectar', value: 10, message: '+10 Néctar Celestial!' }, spawnWeight: 2 }
    ],
    
    exclusiveTraits: [
      { id: 'divine_wings', name: 'Divine Wings', namePt: 'Asas Divinas',
        description: 'Asas abençoadas pelos deuses celestiais.',
        rarity: 'legendary', statBonus: { beauty: 30, stamina: 15, agility: 10 }, combatBonus: { allStats: 10, holyDamage: 25 } },
      { id: 'celestial_blessing', name: 'Celestial Blessing', namePt: 'Bênção Celestial',
        description: 'Permanentemente abençoado pela luz divina.',
        rarity: 'legendary', statBonus: { fertility: 0.2, beauty: 20 }, combatBonus: { healingReceived: 50, regeneration: 5 } },
      { id: 'starborn', name: 'Starborn', namePt: 'Nascido das Estrelas',
        description: 'Nascido da própria luz das estrelas.',
        rarity: 'legendary', statBonus: { beauty: 25, agility: 15, stamina: 10 }, combatBonus: { critChance: 20, critDamage: 50 } }
    ],
    
    seeds: ['flor_celestial', 'orvalho_estrelar'],
    
    exclusiveColors: ['#ffffff', '#e1f5fe', '#b3e5fc', '#fce4ec', '#f3e5f5'],
    exclusivePatterns: ['divine_glow', 'star_pattern', 'celestial_gradient', 'holy_wings'],
    
    enemies: [
      { id: 'celestial_guardian', name: 'Celestial Guardian', namePt: 'Guardião Celestial', emoji: '👼',
        hp: 80, attack: 30, defense: 20, speed: 5, abilities: ['holy_smite', 'divine_shield'], dropChance: 0.4 },
      { id: 'star_sprite', name: 'Star Sprite', namePt: 'Sprite Estelar', emoji: '⭐',
        hp: 40, attack: 35, defense: 10, speed: 8, abilities: ['star_bolt', 'blink'], dropChance: 0.35 },
      { id: 'cloud_serpent', name: 'Cloud Serpent', namePt: 'Serpente das Nuvens', emoji: '🐉',
        hp: 100, attack: 35, defense: 25, speed: 4, abilities: ['lightning_breath', 'coil'], dropChance: 0.45 }
    ],
    
    boss: {
      id: 'moth_emperor',
      name: 'Lunaris the Moth Emperor',
      namePt: 'Lunaris o Imperador Mariposa',
      emoji: '🦋👑✨',
      title: 'Divine Ruler of All Butterflies',
      titlePt: 'Governante Divino de Todas as Borboletas',
      hp: 800,
      attack: 50,
      defense: 30,
      speed: 6,
      phases: [
        { hpPercent: 75, messagePt: 'Vocês vieram de longe, pequenos. Mas é aqui que sua jornada termina.', attackBonus: 1.3 },
        { hpPercent: 50, messagePt: 'Impressionante... vocês me forçam a revelar minha verdadeira forma!', attackBonus: 1.8 },
        { hpPercent: 25, messagePt: 'TESTEMUNHEM O PODER DO TRONO CELESTIAL!', attackBonus: 3.0 }
      ],
      abilities: [
        { name: 'Divine Light', namePt: 'Luz Divina', damage: 50, range: 5, cooldown: 2, effect: 'bless', aoe: 3 },
        { name: 'Star Storm', namePt: 'Tempestade de Estrelas', damage: 35, range: 8, cooldown: 4, aoe: 5 },
        { name: 'Lunar Eclipse', namePt: 'Eclipse Lunar', damage: 0, range: 10, cooldown: 6, effect: 'curse' },
        { name: 'Rebirth', namePt: 'Renascimento', damage: -100, range: 0, cooldown: 10 }
      ],
      dialogue: {
        introPt: 'Então, vocês ascenderam ao meu reino... Poucos mortais já alcançaram o Templo Celestial. Provem ser dignos!',
        deathPt: 'Finalmente... sucessores dignos... O reino celestial... é de vocês agora... Governem-no... com sabedoria...'
      },
      loot: { nectar: { min: 300, max: 500, type: 'Celestial' }, seedChance: 0.9, butterflyChance: 0.6, exclusiveTraitChance: 0.8 }
    },
    
    unlockRequirement: { type: 'boss', value: 'volcano_lord', descriptionPt: 'Derrote Ignius o Senhor do Vulcão' }
  }
};

// ════════════════════════════════════════════════════════════════
// PLANTAS/SEMENTES
// ════════════════════════════════════════════════════════════════

const PLANTS = {
  // Jardim Encantado
  rosa: { id: 'rosa', name: 'Rose', namePt: 'Rosa', icon: '🌹', growthTime: 100, nectarType: 'Rosa', nectarAmount: 3, cost: 15, region: 'jardim_encantado' },
  girassol: { id: 'girassol', name: 'Sunflower', namePt: 'Girassol', icon: '🌻', growthTime: 80, nectarType: 'Girassol', nectarAmount: 4, cost: 20, region: 'jardim_encantado' },
  margarida: { id: 'margarida', name: 'Daisy', namePt: 'Margarida', icon: '🌼', growthTime: 60, nectarType: 'basic', nectarAmount: 2, cost: 10, region: 'jardim_encantado' },
  
  // Floresta Sombria
  cogumelo_lunar: { id: 'cogumelo_lunar', name: 'Moon Mushroom', namePt: 'Cogumelo Lunar', icon: '🍄', growthTime: 150, nectarType: 'FlordaLua', nectarAmount: 5, cost: 40, region: 'floresta_sombria' },
  erva_sombria: { id: 'erva_sombria', name: 'Shadow Herb', namePt: 'Erva Sombria', icon: '🌿', growthTime: 120, nectarType: 'basic', nectarAmount: 6, cost: 30, region: 'floresta_sombria' },
  
  // Caverna Cristalina
  flor_cristal: { id: 'flor_cristal', name: 'Crystal Flower', namePt: 'Flor de Cristal', icon: '💠', growthTime: 200, nectarType: 'Cristal', nectarAmount: 8, cost: 60, region: 'caverna_cristalina' },
  musgo_brilhante: { id: 'musgo_brilhante', name: 'Glowing Moss', namePt: 'Musgo Brilhante', icon: '✨', growthTime: 100, nectarType: 'basic', nectarAmount: 4, cost: 25, region: 'caverna_cristalina' },
  
  // Pântano Misterioso
  lirio_venenoso: { id: 'lirio_venenoso', name: 'Poison Lily', namePt: 'Lírio Venenoso', icon: '☠️', growthTime: 180, nectarType: 'Veneno', nectarAmount: 6, cost: 50, region: 'pantano_misterioso' },
  erva_pantano: { id: 'erva_pantano', name: 'Swamp Herb', namePt: 'Erva do Pântano', icon: '🌿', growthTime: 90, nectarType: 'basic', nectarAmount: 5, cost: 30, region: 'pantano_misterioso' },
  flor_sapo: { id: 'flor_sapo', name: 'Frog Flower', namePt: 'Flor de Sapo', icon: '🐸', growthTime: 120, nectarType: 'Sapo', nectarAmount: 4, cost: 35, region: 'pantano_misterioso' },
  
  // Vulcão Ardente
  flor_fogo: { id: 'flor_fogo', name: 'Fire Blossom', namePt: 'Flor de Fogo', icon: '🔥', growthTime: 250, nectarType: 'Fogo', nectarAmount: 10, cost: 80, region: 'vulcao_ardente' },
  cinza_viva: { id: 'cinza_viva', name: 'Living Ash', namePt: 'Cinza Viva', icon: '⚫', growthTime: 150, nectarType: 'basic', nectarAmount: 7, cost: 45, region: 'vulcao_ardente' },
  
  // Templo Celestial
  flor_celestial: { id: 'flor_celestial', name: 'Celestial Bloom', namePt: 'Flor Celestial', icon: '✨', growthTime: 300, nectarType: 'Celestial', nectarAmount: 15, cost: 150, region: 'templo_celestial' },
  orvalho_estrelar: { id: 'orvalho_estrelar', name: 'Star Dew', namePt: 'Orvalho Estrelar', icon: '⭐', growthTime: 200, nectarType: 'basic', nectarAmount: 10, cost: 80, region: 'templo_celestial' }
};

// ════════════════════════════════════════════════════════════════
// FUNÇÕES AUXILIARES
// ════════════════════════════════════════════════════════════════

function getRegion(id) {
  return REGIONS[id];
}

function isRegionUnlocked(regionId, defeatedBosses) {
  const region = REGIONS[regionId];
  if (!region.unlockRequirement) return true;
  if (region.unlockRequirement.type === 'boss') {
    return defeatedBosses.includes(region.unlockRequirement.value);
  }
  return false;
}

function getUnlockedRegions(defeatedBosses) {
  return Object.values(REGIONS).filter(r => isRegionUnlocked(r.id, defeatedBosses || []));
}

function generateRegionTileGrid(regionId, width, height) {
  width = width || 10;
  height = height || 10;
  
  const region = REGIONS[regionId];
  if (!region) return null;
  
  const grid = [];
  const totalWeight = region.tiles.reduce(function(sum, t) { return sum + t.spawnWeight; }, 0);
  
  for (let y = 0; y < height; y++) {
    const row = [];
    for (let x = 0; x < width; x++) {
      let random = Math.random() * totalWeight;
      let selectedTile = region.tiles[0];
      
      for (let i = 0; i < region.tiles.length; i++) {
        random -= region.tiles[i].spawnWeight;
        if (random <= 0) {
          selectedTile = region.tiles[i];
          break;
        }
      }
      
      row.push(Object.assign({}, selectedTile));
    }
    grid.push(row);
  }
  
  // Garantir caminho walkable
  const walkableTile = region.tiles.find(function(t) { return t.walkable && !t.effect; }) || 
                       region.tiles.find(function(t) { return t.walkable; });
  
  let px = 0, py = 0;
  while (px < width - 1 || py < height - 1) {
    grid[py][px] = Object.assign({}, walkableTile);
    if (px < width - 1 && py < height - 1) {
      if (Math.random() < 0.5) px++;
      else py++;
    } else if (px < width - 1) {
      px++;
    } else {
      py++;
    }
  }
  grid[height - 1][width - 1] = Object.assign({}, walkableTile);
  
  return grid;
}

function getAvailableSeeds(unlockedRegionIds) {
  const seeds = [];
  unlockedRegionIds.forEach(function(regionId) {
    const region = REGIONS[regionId];
    if (region && region.seeds) {
      region.seeds.forEach(function(seedId) {
        if (PLANTS[seedId] && !seeds.find(function(s) { return s.id === seedId; })) {
          seeds.push(PLANTS[seedId]);
        }
      });
    }
  });
  return seeds;
}

function getRegionExclusiveColor(regionId) {
  const region = REGIONS[regionId];
  if (region && region.exclusiveColors && region.exclusiveColors.length > 0) {
    return region.exclusiveColors[Math.floor(Math.random() * region.exclusiveColors.length)];
  }
  return null;
}

function getRegionExclusiveTrait(regionId) {
  const region = REGIONS[regionId];
  if (!region || !region.exclusiveTraits || region.exclusiveTraits.length === 0) return null;
  
  const rarityChance = { common: 0.5, uncommon: 0.3, rare: 0.15, legendary: 0.05 };
  
  // Shuffle and try each trait
  const shuffled = region.exclusiveTraits.slice().sort(function() { return Math.random() - 0.5; });
  
  for (let i = 0; i < shuffled.length; i++) {
    const trait = shuffled[i];
    if (Math.random() < (rarityChance[trait.rarity] || 0.1)) {
      return trait;
    }
  }
  
  return null;
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.REGIONS = REGIONS;
  window.PLANTS = PLANTS;
  window.getRegion = getRegion;
  window.isRegionUnlocked = isRegionUnlocked;
  window.getUnlockedRegions = getUnlockedRegions;
  window.generateRegionTileGrid = generateRegionTileGrid;
  window.getAvailableSeeds = getAvailableSeeds;
  window.getRegionExclusiveColor = getRegionExclusiveColor;
  window.getRegionExclusiveTrait = getRegionExclusiveTrait;
}

console.log('🦋 Regions Data loaded! 6 regions, ' + Object.keys(PLANTS).length + ' plants available.');
