import { useState, useEffect } from 'react';
import { GameState, Butterfly, DungeonRoom, CombatUnit, Position, Ability, RegionKey, PlantType } from './types';
import { createStartingButterflies, breedButterflies, createButterfly, calculateInbreeding, getPhenotype, REGION_TRAIT_LABELS } from './genetics';
import { createDungeonRun, generateMysteryEvent, getRoomDescription, MysteryEvent, getRoomIcon, generateTreasureReward, generateButterflyEncounter, generateBossReward } from './dungeon';
import { createEnemyGroup } from './enemies';
import { initializeCombat, getValidMoves, getValidTargets, moveUnit, useAbility, endPlayerTurn, executeEnemyTurn } from './combat';
import { ButterflyCard } from './components/ButterflyCard';
import { CombatGrid, AbilityBar, CombatLog } from './components/CombatGrid';
import { DungeonMap } from './components/DungeonMap';
import { CLASS_DATA } from './classes';
import { REGIONS, PLANTS } from './regions';

const NEGATIVE_TRAIT_LABELS: Record<string, string> = {
  fragile_wings: 'Asas frágeis — quebram facilmente',
  weak_immunity: 'Imunidade fraca — adoece frequentemente',
  poor_vision: 'Visão ruim — menos sucesso em exploração',
  sterile: 'Estéril — não pode se reproduzir',
  deformed: 'Deformado — todos os atributos reduzidos'
};

const PERSONALITY_LABELS: Record<string, { label: string; color: string; desc: string }> = {
  curioso: { label: 'Curioso', color: 'bg-blue-600', desc: 'Encontra mais tesouros' },
  corajoso: { label: 'Corajoso', color: 'bg-red-600', desc: 'Mais resistente em batalha' },
  brincalhao: { label: 'Brincalhão', color: 'bg-yellow-600', desc: 'Mais veloz' },
  sabio: { label: 'Sábio', color: 'bg-purple-600', desc: 'Ganha mais experiência' },
  timido: { label: 'Tímido', color: 'bg-gray-600', desc: 'Mais chance de sobreviver' },
  agressivo: { label: 'Agressivo', color: 'bg-orange-600', desc: 'Dano aumentado' }
};

function App() {
  const [gameState, setGameState] = useState<GameState>({
    screen: 'menu',
    household: [],
    deadButterflies: [],
    gold: 100,
    nectar: { basic: 50, premium: 0, mythic: 0 },
    dungeonRun: null,
    combatState: null,
    selectedButterflies: [],
    breedingPair: [null, null],
    breedSlot1: null,
    breedSlot2: null,
    activeAdventures: [],
    selectedBf: null,
    plants: [null, null, null, null, null, null],
    unlockedRegions: ['jardim_encantado'],
    selectedRegion: null
  });
  
  const [mysteryEvent, setMysteryEvent] = useState<MysteryEvent | null>(null);
  const [butterflyEncounter, setButterflyEncounter] = useState<{ butterfly: Butterfly; captureChance: number } | null>(null);
  const [message, setMessage] = useState<string>('');
  const [messageType, setMessageType] = useState<'success' | 'danger' | 'warn' | 'info'>('info');
  
  const notify = (msg: string, type: 'success' | 'danger' | 'warn' | 'info' = 'info') => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 4000);
  };
  
  // Start new game
  const startNewGame = () => {
    const startingButterflies = createStartingButterflies();
    setGameState({
      ...gameState,
      screen: 'household',
      household: startingButterflies,
      deadButterflies: [],
      gold: 100,
      nectar: { basic: 50, premium: 0, mythic: 0 },
      activeAdventures: [],
      unlockedRegions: ['jardim_encantado'],
      plants: [null, null, null, null, null, null]
    });
  };
  
  // Navigation
  const goToScreen = (screen: GameState['screen']) => {
    setGameState(prev => ({ 
      ...prev, 
      screen,
      selectedButterflies: [],
      breedingPair: [null, null],
      breedSlot1: null,
      breedSlot2: null
    }));
  };
  
  // Breeding with gender check
  const selectForBreeding = (index: number) => {
    const bf = gameState.household[index];
    if (bf.onAdventure) {
      notify('Esta borboleta está em uma aventura!', 'warn');
      return;
    }
    
    setGameState(prev => {
      if (prev.breedSlot1 === null) {
        return { ...prev, breedSlot1: index, breedingPair: [bf, prev.breedingPair[1]] };
      } else if (prev.breedSlot2 === null && index !== prev.breedSlot1) {
        const bf1 = prev.household[prev.breedSlot1];
        const bf2 = bf;
        if (bf1.gender === bf2.gender) {
          notify('Devem ser de gêneros diferentes! ♂ + ♀', 'danger');
          return prev;
        }
        return { ...prev, breedSlot2: index, breedingPair: [bf1, bf2] };
      } else {
        return { ...prev, breedSlot1: index, breedSlot2: null, breedingPair: [bf, null] };
      }
    });
  };
  
  const canBreed = (): { canBreed: boolean; warning: string | null } => {
    const [p1, p2] = gameState.breedingPair;
    if (!p1 || !p2) return { canBreed: false, warning: null };
    
    const sterile1 = p1.negativeTraits.includes('sterile');
    const sterile2 = p2.negativeTraits.includes('sterile');
    if (sterile1 || sterile2) {
      return { canBreed: false, warning: '⛔ Não pode reproduzir! Um ou ambos os pais são estéreis.' };
    }
    
    const coeff = calculateInbreeding(p1, p2);
    if (coeff > 0.4) {
      return { canBreed: false, warning: `⚠️ Coeficiente de consanguinidade muito alto (${Math.round(coeff * 100)}%)!` };
    }
    if (coeff > 0.1) {
      return { canBreed: true, warning: `⚠️ Aviso de consanguinidade! Parentesco: ${Math.round(coeff * 100)}%. Pode causar defeitos.` };
    }
    
    return { canBreed: true, warning: null };
  };
  
  const performBreeding = () => {
    const [parent1, parent2] = gameState.breedingPair;
    if (!parent1 || !parent2) return;
    if (gameState.gold < 25) {
      notify('Ouro insuficiente!', 'danger');
      return;
    }
    
    const child = breedButterflies(parent1, parent2);
    const ph = getPhenotype(child.genetics);
    
    let msg = `🎉 ${child.name} nasceu! (${ph.colorLabel}, Gen ${child.generation})`;
    if (child.isInbred) {
      msg += ` ⚠️ CONSANGUÍNEO (${child.negativeTraits.length} defeitos)`;
    }
    
    setGameState(prev => ({
      ...prev,
      household: [...prev.household, child],
      breedingPair: [null, null],
      breedSlot1: null,
      breedSlot2: null,
      gold: prev.gold - 25
    }));
    
    notify(msg, child.isInbred ? 'warn' : 'success');
  };
  
  // Party selection for dungeon
  const togglePartyMember = (butterfly: Butterfly) => {
    if (butterfly.onAdventure) {
      notify('Esta borboleta está em uma aventura!', 'warn');
      return;
    }
    
    setGameState(prev => {
      const isSelected = prev.selectedButterflies.find(b => b.id === butterfly.id);
      if (isSelected) {
        return { ...prev, selectedButterflies: prev.selectedButterflies.filter(b => b.id !== butterfly.id) };
      } else if (prev.selectedButterflies.length < 4) {
        return { ...prev, selectedButterflies: [...prev.selectedButterflies, butterfly] };
      }
      return prev;
    });
  };
  
  // Select region and start dungeon
  const selectRegion = (regionKey: RegionKey) => {
    if (!gameState.unlockedRegions.includes(regionKey)) {
      notify('Esta região está bloqueada!', 'warn');
      return;
    }
    setGameState(prev => ({ ...prev, selectedRegion: regionKey }));
  };
  
  // Start dungeon run with selected region
  const startDungeonRun = () => {
    if (gameState.selectedButterflies.length === 0) {
      notify('Selecione pelo menos uma borboleta!', 'warn');
      return;
    }
    if (!gameState.selectedRegion) {
      notify('Selecione uma região!', 'warn');
      return;
    }
    
    const region = REGIONS[gameState.selectedRegion];
    if (gameState.nectar.basic < region.nectarCost) {
      notify(`Néctar insuficiente! Precisa de ${region.nectarCost} 🍯`, 'danger');
      return;
    }
    
    const run = createDungeonRun(gameState.selectedButterflies, 1, gameState.selectedRegion);
    setGameState(prev => ({
      ...prev,
      screen: 'dungeon',
      dungeonRun: run,
      nectar: { ...prev.nectar, basic: prev.nectar.basic - region.nectarCost }
    }));
  };
  
  // Handle room selection
  const handleRoomSelect = (room: DungeonRoom) => {
    const run = gameState.dungeonRun;
    if (!run) return;
    
    // Check if room is accessible
    const currentRoom = run.rooms.find(r => r.id === run.currentRoomId);
    if (!currentRoom?.connections.includes(room.id) && room.id !== run.currentRoomId) {
      return;
    }
    
    // Move to room
    const newRun = { ...run, currentRoomId: room.id };
    
    if (room.type === 'combat' || room.type === 'elite' || room.type === 'boss') {
      const enemies = createEnemyGroup(room.type, run.floor, run.region);
      const combat = initializeCombat(run.party, enemies);
      setGameState(prev => ({
        ...prev,
        screen: 'combat',
        dungeonRun: newRun,
        combatState: combat
      }));
    } else if (room.type === 'rest') {
      const healedParty = newRun.party.map(b => ({
        ...b,
        stats: { ...b.stats, hp: Math.min(b.stats.maxHp, b.stats.hp + Math.floor(b.stats.maxHp * 0.4)) }
      }));
      setGameState(prev => ({
        ...prev,
        dungeonRun: { ...newRun, party: healedParty, rooms: markRoomComplete(run.rooms, room.id) }
      }));
      notify('🏕️ Seu grupo descansou e recuperou 40% do HP!', 'success');
    } else if (room.type === 'shop') {
      const newGold = newRun.gold + 50;
      setGameState(prev => ({
        ...prev,
        dungeonRun: { ...newRun, gold: newGold, rooms: markRoomComplete(run.rooms, room.id) }
      }));
      notify('🛒 Você negociou com o comerciante e ganhou 50 de ouro!', 'success');
    } else if (room.type === 'mystery') {
      const event = generateMysteryEvent(run.region);
      setMysteryEvent(event);
      setGameState(prev => ({
        ...prev,
        dungeonRun: newRun
      }));
    } else if (room.type === 'treasure') {
      const reward = generateTreasureReward(run.region, run.floor);
      let msg = `💰 Você encontrou ${reward.gold} de ouro!`;
      if (reward.seeds.length > 0) {
        msg += ` E ${reward.seedDescriptions.join(', ')}!`;
      }
      setGameState(prev => ({
        ...prev,
        dungeonRun: { 
          ...newRun, 
          gold: newRun.gold + reward.gold, 
          foundSeeds: [...newRun.foundSeeds, ...reward.seeds],
          rooms: markRoomComplete(run.rooms, room.id) 
        }
      }));
      notify(msg, 'success');
    } else if (room.type === 'butterfly_encounter') {
      const encounter = generateButterflyEncounter(run.region);
      setButterflyEncounter({ butterfly: encounter.butterfly, captureChance: encounter.captureChance });
      setGameState(prev => ({
        ...prev,
        dungeonRun: newRun
      }));
    }
  };
  
  const handleButterflyCapture = (tryCapture: boolean) => {
    if (!butterflyEncounter || !gameState.dungeonRun) return;
    
    const run = gameState.dungeonRun;
    
    if (tryCapture) {
      if (Math.random() < butterflyEncounter.captureChance) {
        const newButterfly = butterflyEncounter.butterfly;
        const ph = getPhenotype(newButterfly.genetics);
        setGameState(prev => ({
          ...prev,
          dungeonRun: {
            ...run,
            foundButterflies: [...run.foundButterflies, newButterfly],
            rooms: markRoomComplete(run.rooms, run.currentRoomId)
          }
        }));
        notify(`🦋 Você capturou ${newButterfly.name}! (${ph.colorLabel}, ${ph.regionTraitLabel || 'Selvagem'})`, 'success');
      } else {
        setGameState(prev => ({
          ...prev,
          dungeonRun: { ...run, rooms: markRoomComplete(run.rooms, run.currentRoomId) }
        }));
        notify('😢 A borboleta escapou!', 'warn');
      }
    } else {
      setGameState(prev => ({
        ...prev,
        dungeonRun: { ...run, rooms: markRoomComplete(run.rooms, run.currentRoomId) }
      }));
      notify('Você deixou a borboleta em paz.', 'info');
    }
    
    setButterflyEncounter(null);
  };
  
  const markRoomComplete = (rooms: DungeonRoom[], roomId: string): DungeonRoom[] => {
    return rooms.map(r => {
      if (r.id === roomId) return { ...r, completed: true };
      // Make connected rooms available
      const completedRoom = rooms.find(cr => cr.id === roomId);
      if (completedRoom?.connections.includes(r.id)) {
        return { ...r, available: true };
      }
      return r;
    });
  };
  
  // Recruit new butterfly
  const recruitButterfly = () => {
    if (gameState.gold < 50) {
      notify('Ouro insuficiente!', 'danger');
      return;
    }
    
    const newButterfly = createButterfly({});
    const ph = getPhenotype(newButterfly.genetics);
    
    setGameState(prev => ({
      ...prev,
      household: [...prev.household, newButterfly],
      gold: prev.gold - 50
    }));
    
    notify(`🦋 ${newButterfly.name} juntou-se à sua casa! (${ph.colorLabel})`, 'success');
  };
  
  // Release butterfly
  const releaseButterfly = (index: number) => {
    const bf = gameState.household[index];
    setGameState(prev => ({
      ...prev,
      household: prev.household.filter((_, i) => i !== index),
      selectedBf: null
    }));
    notify(`${bf.name} foi libertado na natureza.`, 'info');
  };
  
  // Combat handlers
  const [validMoves, setValidMoves] = useState<Position[]>([]);
  const [validTargets, setValidTargets] = useState<Position[]>([]);
  
  useEffect(() => {
    if (gameState.combatState?.selectedUnit) {
      if (gameState.combatState.selectedAbility) {
        setValidMoves([]);
        setValidTargets(getValidTargets(
          gameState.combatState,
          gameState.combatState.selectedUnit,
          gameState.combatState.selectedAbility
        ));
      } else {
        setValidMoves(getValidMoves(gameState.combatState, gameState.combatState.selectedUnit));
        setValidTargets([]);
      }
    } else {
      setValidMoves([]);
      setValidTargets([]);
    }
  }, [gameState.combatState?.selectedUnit, gameState.combatState?.selectedAbility]);
  
  const handleUnitClick = (unit: CombatUnit) => {
    if (!gameState.combatState || gameState.combatState.phase !== 'player') return;
    
    if (unit.isPlayer && !unit.hasMoved && !unit.hasActed) {
      setGameState(prev => ({
        ...prev,
        combatState: prev.combatState ? { ...prev.combatState, selectedUnit: unit, selectedAbility: null } : null
      }));
    }
  };
  
  const handleTileClick = (pos: Position) => {
    if (!gameState.combatState || gameState.combatState.phase !== 'player') return;
    
    const { selectedUnit, selectedAbility } = gameState.combatState;
    
    if (selectedUnit && selectedAbility) {
      // Use ability
      const isValidTarget = validTargets.some(t => t.x === pos.x && t.y === pos.y);
      if (isValidTarget) {
        const newState = useAbility(gameState.combatState, selectedUnit, selectedAbility, pos);
        setGameState(prev => ({
          ...prev,
          combatState: { ...newState, selectedUnit: null, selectedAbility: null }
        }));
      }
    } else if (selectedUnit && !selectedUnit.hasMoved) {
      // Move
      const isValidMove = validMoves.some(m => m.x === pos.x && m.y === pos.y);
      if (isValidMove) {
        const newState = moveUnit(gameState.combatState, selectedUnit, pos);
        setGameState(prev => ({
          ...prev,
          combatState: { ...newState, selectedUnit: { ...selectedUnit, position: pos, hasMoved: true } }
        }));
      }
    }
  };
  
  const handleAbilitySelect = (ability: Ability) => {
    if (!gameState.combatState?.selectedUnit) return;
    setGameState(prev => ({
      ...prev,
      combatState: prev.combatState ? { ...prev.combatState, selectedAbility: ability } : null
    }));
  };
  
  const handleEndTurn = () => {
    if (!gameState.combatState) return;
    
    let newState = endPlayerTurn(gameState.combatState);
    
    // Execute enemy turn with delay
    const executeEnemies = () => {
      if (newState.phase === 'enemy' && !newState.isComplete) {
        newState = executeEnemyTurn(newState);
        setGameState(prev => ({ ...prev, combatState: newState }));
        
        if (newState.phase === 'enemy' && !newState.isComplete) {
          setTimeout(executeEnemies, 500);
        }
      }
    };
    
    setGameState(prev => ({ ...prev, combatState: newState }));
    setTimeout(executeEnemies, 500);
  };
  
  // Check combat completion
  useEffect(() => {
    if (gameState.combatState?.isComplete) {
      const run = gameState.dungeonRun;
      if (!run) return;
      
      if (gameState.combatState.victory) {
        // Calculate loot
        let goldGain = 0;
        let expGain = 0;
        const seedsGained: PlantType[] = [];
        
        gameState.combatState.enemyUnits.forEach(u => {
          if (u.enemy?.loot) {
            goldGain += u.enemy.loot.gold;
            expGain += u.enemy.loot.exp;
            if (u.enemy.loot.seeds) {
              seedsGained.push(...u.enemy.loot.seeds);
            }
          }
        });
        
        // Check if boss room
        const currentRoom = run.rooms.find(r => r.id === run.currentRoomId);
        const isBossRoom = currentRoom?.type === 'boss';
        
        let newFoundButterflies = [...run.foundButterflies];
        
        if (isBossRoom) {
          const bossReward = generateBossReward(run.region, run.floor);
          goldGain += bossReward.gold;
          expGain += bossReward.exp;
          seedsGained.push(...bossReward.seeds);
          newFoundButterflies.push(bossReward.guaranteedButterfly);
          notify(bossReward.message, 'success');
          
          // Unlock next region if boss defeated
          const regionOrder: RegionKey[] = ['jardim_encantado', 'floresta_sombria', 'caverna_cristalina', 'pantano_mistico', 'montanha_celeste', 'ruinas_antigas'];
          const currentIndex = regionOrder.indexOf(run.region);
          if (currentIndex < regionOrder.length - 1) {
            const nextRegion = regionOrder[currentIndex + 1];
            if (!gameState.unlockedRegions.includes(nextRegion)) {
              setGameState(prev => ({
                ...prev,
                unlockedRegions: [...prev.unlockedRegions, nextRegion]
              }));
              notify(`🗝️ Nova região desbloqueada: ${REGIONS[nextRegion].name}!`, 'success');
            }
          }
        }
        
        // Update party with exp
        const updatedParty = run.party.map(b => {
          const unit = gameState.combatState!.playerUnits.find(u => u.butterfly?.id === b.id);
          return {
            ...b,
            exp: b.exp + expGain,
            stats: unit?.butterfly?.stats || b.stats
          };
        });
        
        const newRun: typeof run = {
          ...run,
          gold: run.gold + goldGain,
          party: updatedParty,
          foundSeeds: [...run.foundSeeds, ...seedsGained],
          foundButterflies: newFoundButterflies,
          rooms: markRoomComplete(run.rooms, run.currentRoomId)
        };
        
        setGameState(prev => ({
          ...prev,
          screen: isBossRoom ? 'victory' : 'dungeon',
          dungeonRun: newRun,
          combatState: null
        }));
        
        if (!isBossRoom) {
          let msg = `⚔️ Vitória! +${goldGain} ouro, +${expGain} EXP`;
          if (seedsGained.length > 0) {
            msg += `, +${seedsGained.map(s => PLANTS[s].icon).join('')}`;
          }
          notify(msg, 'success');
        }
      } else {
        // Defeat
        setGameState(prev => ({
          ...prev,
          screen: 'defeat',
          combatState: null
        }));
      }
    }
  }, [gameState.combatState?.isComplete]);
  
  // Handle mystery event choice
  const handleMysteryChoice = (choiceIndex: number) => {
    if (!mysteryEvent || !gameState.dungeonRun) return;
    
    const choice = mysteryEvent.choices[choiceIndex];
    const result = choice.effect(gameState.dungeonRun);
    
    setGameState(prev => ({
      ...prev,
      dungeonRun: { ...result.run, rooms: markRoomComplete(result.run.rooms, result.run.currentRoomId) }
    }));
    
    notify(result.message, 'info');
    setMysteryEvent(null);
  };
  
  // End dungeon run
  const endDungeonRun = (victory: boolean) => {
    const run = gameState.dungeonRun;
    if (!run) return;
    
    // Transfer loot and found items to main game state
    setGameState(prev => ({
      ...prev,
      screen: 'household',
      household: [
        ...prev.household.map(b => {
          const partyMember = run.party.find(p => p.id === b.id);
          return partyMember || b;
        }),
        ...run.foundButterflies // Add any butterflies found during the run
      ],
      gold: prev.gold + run.gold,
      plants: addSeedsToGarden(prev.plants, run.foundSeeds),
      dungeonRun: null,
      selectedButterflies: [],
      selectedRegion: null
    }));
    
    if (victory) {
      notify(`🏆 Dungeon completa! +${run.gold} ouro, ${run.foundButterflies.length} borboletas, ${run.foundSeeds.length} sementes!`, 'success');
    }
  };
  
  // Add seeds to garden
  const addSeedsToGarden = (plants: (typeof gameState.plants[0])[], seeds: PlantType[]): typeof gameState.plants => {
    const newPlants = [...plants];
    seeds.forEach(seed => {
      const emptySlot = newPlants.findIndex(p => p === null);
      if (emptySlot !== -1) {
        newPlants[emptySlot] = { type: seed, progress: 0, planted: Date.now() };
      }
    });
    return newPlants as typeof gameState.plants;
  };

  // Butterfly Detail Panel Component
  const ButterflyDetailPanel = ({ butterfly, onRelease }: { butterfly: Butterfly; onRelease: () => void }) => {
    const ph = getPhenotype(butterfly.genetics);
    const classData = CLASS_DATA[butterfly.class];
    
    return (
      <div className="space-y-4">
        <div className="text-center">
          <ButterflyCard butterfly={butterfly} />
          <h2 className="text-xl font-bold mt-2">{butterfly.name}</h2>
          <p className="text-purple-300">{ph.colorLabel} · {butterfly.gender === 'macho' ? '♂' : '♀'} · Gen {butterfly.generation}</p>
        </div>
        
        <div className="bg-purple-800/50 p-3 rounded-lg">
          <h3 className="font-bold text-sm text-purple-300 mb-2">Classe: {butterfly.class}</h3>
          <p className="text-xs text-purple-400">{classData?.description}</p>
        </div>
        
        <div className="bg-purple-800/50 p-3 rounded-lg">
          <h3 className="font-bold text-sm text-purple-300 mb-2">Personalidade</h3>
          <span className={`px-2 py-1 rounded text-xs ${PERSONALITY_LABELS[butterfly.personality].color}`}>
            {PERSONALITY_LABELS[butterfly.personality].label}
          </span>
          <p className="text-xs text-purple-400 mt-1">{PERSONALITY_LABELS[butterfly.personality].desc}</p>
        </div>
        
        {/* Region Traits */}
        {butterfly.region && (
          <div className="bg-green-800/50 p-3 rounded-lg">
            <h3 className="font-bold text-sm text-green-300 mb-2">🌍 Região: {REGIONS[butterfly.region].name}</h3>
            {butterfly.regionExclusiveTraits && butterfly.regionExclusiveTraits.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {butterfly.regionExclusiveTraits.map((trait, i) => (
                  <span key={i} className="px-2 py-1 bg-green-700/50 rounded text-xs">
                    {REGION_TRAIT_LABELS[trait] || trait}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
        
        {/* Genetics */}
        {butterfly.genetics.regionTrait && (
          <div className="bg-blue-800/50 p-3 rounded-lg">
            <h3 className="font-bold text-sm text-blue-300 mb-2">🧬 Gene Regional</h3>
            <p className="text-xs text-blue-400">
              {REGION_TRAIT_LABELS[butterfly.genetics.regionTrait.dominant] || butterfly.genetics.regionTrait.dominant} / 
              {REGION_TRAIT_LABELS[butterfly.genetics.regionTrait.recessive] || butterfly.genetics.regionTrait.recessive}
            </p>
          </div>
        )}
        
        {/* Negative traits */}
        {butterfly.negativeTraits.length > 0 && (
          <div className="bg-red-900/50 p-3 rounded-lg">
            <h3 className="font-bold text-sm text-red-300 mb-2">⚠️ Defeitos</h3>
            {butterfly.negativeTraits.map(trait => (
              <p key={trait} className="text-xs text-red-400">• {NEGATIVE_TRAIT_LABELS[trait]}</p>
            ))}
          </div>
        )}
        
        <button
          onClick={onRelease}
          className="w-full py-2 bg-red-600/50 hover:bg-red-600 rounded-lg text-sm"
        >
          Libertar na Natureza
        </button>
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-purple-800 to-indigo-900 text-white">
      {/* Message Toast */}
      {message && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-lg shadow-lg ${
          messageType === 'success' ? 'bg-green-600' :
          messageType === 'danger' ? 'bg-red-600' :
          messageType === 'warn' ? 'bg-yellow-600' : 'bg-blue-600'
        }`}>
          {message}
        </div>
      )}
      
      {/* Menu Screen */}
      {gameState.screen === 'menu' && (
        <div className="min-h-screen flex flex-col items-center justify-center p-8">
          <h1 className="text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400">
            🦋 Chrysalis Tactics
          </h1>
          <p className="text-xl text-purple-300 mb-8">Roguelike Tático de Borboletas</p>
          
          <button
            onClick={startNewGame}
            className="px-8 py-4 bg-gradient-to-r from-pink-600 to-purple-600 rounded-lg text-xl font-bold hover:from-pink-500 hover:to-purple-500 transition-all transform hover:scale-105"
          >
            🎮 Novo Jogo
          </button>
          
          {/* Features */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto text-sm">
            <div className="bg-purple-900/30 p-4 rounded-lg">
              <h3 className="font-bold text-pink-400 mb-2">🧬 Sistema Genético</h3>
              <p className="text-purple-200">Cada borboleta tem genes únicos com traços regionais exclusivos!</p>
            </div>
            <div className="bg-purple-900/30 p-4 rounded-lg">
              <h3 className="font-bold text-blue-400 mb-2">🗺️ 6 Regiões Únicas</h3>
              <p className="text-purple-200">Explore regiões com inimigos, sementes e borboletas exclusivas!</p>
            </div>
            <div className="bg-purple-900/30 p-4 rounded-lg">
              <h3 className="font-bold text-yellow-400 mb-2">⚔️ Combate Tático</h3>
              <p className="text-purple-200">Grid 10x10 com 14 classes e habilidades únicas!</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Household Screen */}
      {gameState.screen === 'household' && (
        <div className="p-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">🏠 Sua Casa de Borboletas</h1>
            <div className="flex gap-4 items-center">
              <span className="text-yellow-400">💰 {gameState.gold}</span>
              <span className="text-amber-400">🍯 {gameState.nectar.basic}</span>
              <button 
                onClick={recruitButterfly}
                className="px-4 py-2 bg-green-600 rounded-lg hover:bg-green-500"
                disabled={gameState.gold < 50}
              >
                Recrutar (50 💰)
              </button>
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex gap-4 mb-6">
            <button 
              onClick={() => goToScreen('breeding')}
              className="px-4 py-2 bg-pink-600 rounded-lg hover:bg-pink-500"
            >
              🧬 Criação
            </button>
            <button 
              onClick={() => goToScreen('region-select')}
              className="px-4 py-2 bg-purple-600 rounded-lg hover:bg-purple-500"
            >
              🗺️ Explorar Regiões
            </button>
          </div>
          
          {/* Butterfly Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {gameState.household.map((bf, index) => (
              <div 
                key={bf.id}
                onClick={() => setGameState(prev => ({ ...prev, selectedBf: index }))}
                className={`cursor-pointer transition-all ${gameState.selectedBf === index ? 'ring-2 ring-yellow-400' : ''}`}
              >
                <ButterflyCard butterfly={bf} showDetails />
              </div>
            ))}
          </div>
          
          {/* Selected Butterfly Details */}
          {gameState.selectedBf !== null && gameState.household[gameState.selectedBf] && (
            <div className="fixed right-4 top-20 w-80 bg-purple-900/90 p-4 rounded-lg shadow-xl max-h-[80vh] overflow-y-auto">
              <ButterflyDetailPanel 
                butterfly={gameState.household[gameState.selectedBf]} 
                onRelease={() => releaseButterfly(gameState.selectedBf!)}
              />
            </div>
          )}
        </div>
      )}
      
      {/* Region Select Screen */}
      {gameState.screen === 'region-select' && (
        <div className="p-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">🗺️ Selecionar Região</h1>
            <button 
              onClick={() => goToScreen('household')}
              className="px-4 py-2 bg-gray-600 rounded-lg hover:bg-gray-500"
            >
              ← Voltar
            </button>
          </div>
          
          {/* Regions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {(Object.keys(REGIONS) as RegionKey[]).map(key => {
              const region = REGIONS[key];
              const isUnlocked = gameState.unlockedRegions.includes(key);
              const isSelected = gameState.selectedRegion === key;
              
              return (
                <div 
                  key={key}
                  onClick={() => isUnlocked && selectRegion(key)}
                  className={`p-6 rounded-lg cursor-pointer transition-all ${
                    !isUnlocked ? 'bg-gray-800/50 opacity-50 cursor-not-allowed' :
                    isSelected ? 'ring-2 ring-yellow-400 bg-purple-800/80' : 'bg-purple-800/50 hover:bg-purple-700/50'
                  }`}
                  style={isUnlocked ? { background: region.background } : undefined}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-4xl">{region.icon}</span>
                    <div>
                      <h3 className="font-bold text-lg">{region.name}</h3>
                      {!isUnlocked && <span className="text-sm text-red-400">🔒 Bloqueado</span>}
                    </div>
                  </div>
                  <p className="text-sm text-white/80 mb-4">{region.desc}</p>
                  
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>⏱️ {Math.round(region.duration / 1000)}s</div>
                    <div>🍯 {region.nectarCost} néctar</div>
                    <div>⚠️ Nível {region.dangerLevel}</div>
                    <div>☠️ {Math.round(region.deathChance * 100)}% risco</div>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t border-white/20">
                    <p className="text-xs text-white/70 mb-1">Sementes exclusivas:</p>
                    <div className="flex gap-1">
                      {region.seeds.map(seed => (
                        <span key={seed} title={PLANTS[seed].name}>{PLANTS[seed].icon}</span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mt-2">
                    <p className="text-xs text-white/70 mb-1">Chefe: {region.bossIcon} {region.bossName}</p>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Party Selection */}
          {gameState.selectedRegion && (
            <>
              <h2 className="text-2xl font-bold mb-4">Selecionar Grupo (máx 4)</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
                {gameState.household.filter(b => !b.onAdventure).map(bf => {
                  const isSelected = gameState.selectedButterflies.find(b => b.id === bf.id);
                  return (
                    <div
                      key={bf.id}
                      onClick={() => togglePartyMember(bf)}
                      className={`cursor-pointer transition-all ${isSelected ? 'ring-2 ring-green-400' : ''}`}
                    >
                      <ButterflyCard butterfly={bf} compact />
                    </div>
                  );
                })}
              </div>
              
              <div className="flex gap-4 items-center">
                <span className="text-purple-300">
                  {gameState.selectedButterflies.length}/4 borboletas selecionadas
                </span>
                <button
                  onClick={startDungeonRun}
                  disabled={gameState.selectedButterflies.length === 0}
                  className={`px-6 py-3 rounded-lg font-bold ${
                    gameState.selectedButterflies.length > 0
                      ? 'bg-green-600 hover:bg-green-500'
                      : 'bg-gray-600 cursor-not-allowed'
                  }`}
                >
                  ⚔️ Iniciar Expedição em {REGIONS[gameState.selectedRegion].name}
                </button>
              </div>
            </>
          )}
        </div>
      )}
      
      {/* Breeding Screen */}
      {gameState.screen === 'breeding' && (
        <div className="p-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">🧬 Centro de Criação</h1>
            <div className="flex gap-4">
              <span className="text-yellow-400">💰 {gameState.gold}</span>
              <button 
                onClick={() => goToScreen('household')}
                className="px-4 py-2 bg-gray-600 rounded-lg hover:bg-gray-500"
              >
                ← Voltar
              </button>
            </div>
          </div>
          
          {/* Breeding Slots */}
          <div className="flex justify-center gap-8 mb-8">
            <div className={`w-48 h-64 rounded-lg border-2 ${gameState.breedSlot1 !== null ? 'border-pink-400 bg-pink-900/30' : 'border-dashed border-gray-500'} flex flex-col items-center justify-center`}>
              {gameState.breedSlot1 !== null && gameState.household[gameState.breedSlot1] ? (
                <ButterflyCard butterfly={gameState.household[gameState.breedSlot1]} compact />
              ) : (
                <span className="text-gray-400">Pai 1</span>
              )}
            </div>
            
            <div className="flex items-center text-4xl">❤️</div>
            
            <div className={`w-48 h-64 rounded-lg border-2 ${gameState.breedSlot2 !== null ? 'border-blue-400 bg-blue-900/30' : 'border-dashed border-gray-500'} flex flex-col items-center justify-center`}>
              {gameState.breedSlot2 !== null && gameState.household[gameState.breedSlot2] ? (
                <ButterflyCard butterfly={gameState.household[gameState.breedSlot2]} compact />
              ) : (
                <span className="text-gray-400">Pai 2</span>
              )}
            </div>
          </div>
          
          {/* Breeding Warning/Button */}
          <div className="text-center mb-8">
            {canBreed().warning && (
              <p className={`mb-4 ${canBreed().canBreed ? 'text-yellow-400' : 'text-red-400'}`}>
                {canBreed().warning}
              </p>
            )}
            <button
              onClick={performBreeding}
              disabled={!canBreed().canBreed || gameState.gold < 25}
              className={`px-8 py-3 rounded-lg font-bold ${
                canBreed().canBreed && gameState.gold >= 25
                  ? 'bg-pink-600 hover:bg-pink-500'
                  : 'bg-gray-600 cursor-not-allowed'
              }`}
            >
              🥚 Criar (25 💰)
            </button>
          </div>
          
          {/* Available Butterflies */}
          <h2 className="text-xl font-bold mb-4">Borboletas Disponíveis</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {gameState.household.filter(b => !b.onAdventure).map((bf) => {
              const realIndex = gameState.household.indexOf(bf);
              const isSelected = gameState.breedSlot1 === realIndex || gameState.breedSlot2 === realIndex;
              return (
                <div
                  key={bf.id}
                  onClick={() => selectForBreeding(realIndex)}
                  className={`cursor-pointer transition-all ${isSelected ? 'ring-2 ring-yellow-400' : ''}`}
                >
                  <ButterflyCard butterfly={bf} compact />
                </div>
              );
            })}
          </div>
        </div>
      )}
      
      {/* Dungeon Screen */}
      {gameState.screen === 'dungeon' && gameState.dungeonRun && (
        <div className="p-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold">{REGIONS[gameState.dungeonRun.region].icon} {REGIONS[gameState.dungeonRun.region].name}</h1>
              <p className="text-purple-300">Andar {gameState.dungeonRun.floor}</p>
            </div>
            <div className="flex gap-4 items-center">
              <span className="text-yellow-400">💰 {gameState.dungeonRun.gold}</span>
              {gameState.dungeonRun.foundSeeds.length > 0 && (
                <span className="text-green-400">
                  🌱 {gameState.dungeonRun.foundSeeds.map(s => PLANTS[s].icon).join('')}
                </span>
              )}
              {gameState.dungeonRun.foundButterflies.length > 0 && (
                <span className="text-pink-400">
                  🦋 {gameState.dungeonRun.foundButterflies.length}
                </span>
              )}
              <button 
                onClick={() => endDungeonRun(false)}
                className="px-4 py-2 bg-red-600 rounded-lg hover:bg-red-500"
              >
                Fugir
              </button>
            </div>
          </div>
          
          {/* Party Status */}
          <div className="flex gap-4 mb-6 flex-wrap">
            {gameState.dungeonRun.party.map(bf => (
              <div key={bf.id} className="bg-purple-800/50 p-2 rounded-lg flex items-center gap-2">
                <ButterflyCard butterfly={bf} compact />
                <div className="text-sm">
                  <div className="w-20 h-2 bg-gray-700 rounded overflow-hidden">
                    <div 
                      className="h-full bg-green-500" 
                      style={{ width: `${(bf.stats.hp / bf.stats.maxHp) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs">{bf.stats.hp}/{bf.stats.maxHp}</span>
                </div>
              </div>
            ))}
          </div>
          
          {/* Mystery Event Modal */}
          {mysteryEvent && (
            <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
              <div className="bg-purple-900 p-6 rounded-lg max-w-lg">
                <h2 className="text-2xl font-bold mb-4">❓ {mysteryEvent.title}</h2>
                <p className="text-purple-300 mb-6">{mysteryEvent.description}</p>
                <div className="flex flex-col gap-3">
                  {mysteryEvent.choices.map((choice, i) => (
                    <button
                      key={i}
                      onClick={() => handleMysteryChoice(i)}
                      className="px-4 py-3 bg-purple-700 hover:bg-purple-600 rounded-lg text-left"
                    >
                      {choice.text}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Butterfly Encounter Modal */}
          {butterflyEncounter && (
            <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
              <div className="bg-purple-900 p-6 rounded-lg max-w-lg text-center">
                <h2 className="text-2xl font-bold mb-4">🦋 Borboleta Selvagem!</h2>
                <ButterflyCard butterfly={butterflyEncounter.butterfly} showDetails />
                <p className="text-purple-300 my-4">
                  Uma borboleta rara de {REGIONS[gameState.dungeonRun.region].name} apareceu!
                  <br />
                  Chance de captura: {Math.round(butterflyEncounter.captureChance * 100)}%
                </p>
                {butterflyEncounter.butterfly.regionExclusiveTraits && (
                  <div className="mb-4">
                    <p className="text-sm text-green-400">Traços Exclusivos:</p>
                    {butterflyEncounter.butterfly.regionExclusiveTraits.map((trait, i) => (
                      <span key={i} className="inline-block px-2 py-1 bg-green-800/50 rounded text-xs m-1">
                        {REGION_TRAIT_LABELS[trait] || trait}
                      </span>
                    ))}
                  </div>
                )}
                <div className="flex gap-4 justify-center">
                  <button
                    onClick={() => handleButterflyCapture(true)}
                    className="px-6 py-3 bg-green-600 hover:bg-green-500 rounded-lg font-bold"
                  >
                    🪤 Tentar Capturar
                  </button>
                  <button
                    onClick={() => handleButterflyCapture(false)}
                    className="px-6 py-3 bg-gray-600 hover:bg-gray-500 rounded-lg"
                  >
                    Deixar Ir
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Dungeon Map */}
          <DungeonMap 
            rooms={gameState.dungeonRun.rooms}
            currentRoomId={gameState.dungeonRun.currentRoomId}
            onRoomSelect={handleRoomSelect}
          />
          
          {/* Current Room Info */}
          {gameState.dungeonRun.currentRoomId && (
            <div className="mt-6 p-4 bg-purple-900/50 rounded-lg">
              {(() => {
                const room = gameState.dungeonRun!.rooms.find(r => r.id === gameState.dungeonRun!.currentRoomId);
                if (!room) return null;
                return (
                  <>
                    <h3 className="text-xl font-bold">{getRoomIcon(room.type, gameState.dungeonRun!.region)} {room.type.charAt(0).toUpperCase() + room.type.slice(1)}</h3>
                    <p className="text-purple-300">{getRoomDescription(room.type, gameState.dungeonRun!.region)}</p>
                    {room.connections.length > 0 && (
                      <p className="mt-2 text-sm text-purple-400">
                        Caminhos disponíveis: {room.connections.map(c => {
                          const connRoom = gameState.dungeonRun!.rooms.find(r => r.id === c);
                          return connRoom ? getRoomIcon(connRoom.type, gameState.dungeonRun!.region) : '';
                        }).join(' ')}
                      </p>
                    )}
                  </>
                );
              })()}
            </div>
          )}
        </div>
      )}
      
      {/* Combat Screen */}
      {gameState.screen === 'combat' && gameState.combatState && (
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold">⚔️ Combate!</h1>
            <div className="flex gap-4 items-center">
              <span className="text-purple-300">Turno {gameState.combatState.turn}</span>
              <span className={`px-3 py-1 rounded ${gameState.combatState.phase === 'player' ? 'bg-blue-600' : 'bg-red-600'}`}>
                {gameState.combatState.phase === 'player' ? '🦋 Sua Vez' : '👹 Turno do Inimigo'}
              </span>
            </div>
          </div>
          
          <div className="flex gap-8">
            {/* Combat Grid */}
            <div>
              <CombatGrid
                state={gameState.combatState}
                validMoves={validMoves}
                validTargets={validTargets}
                onTileClick={handleTileClick}
                onUnitClick={handleUnitClick}
                regionId={gameState.dungeonRun?.region || 'jardim_encantado'}
              />
              
              {/* Ability Bar */}
              <AbilityBar
                unit={gameState.combatState.selectedUnit}
                selectedAbility={gameState.combatState.selectedAbility}
                onSelect={handleAbilitySelect}
                abilities={gameState.combatState.selectedUnit?.butterfly?.abilities || gameState.combatState.selectedUnit?.enemy?.abilities || []}
              />
              
              {/* End Turn Button */}
              {gameState.combatState.phase === 'player' && (
                <button
                  onClick={handleEndTurn}
                  className="mt-4 px-6 py-3 bg-yellow-600 hover:bg-yellow-500 rounded-lg font-bold"
                >
                  ⏭️ Finalizar Turno
                </button>
              )}
            </div>
            
            {/* Combat Log & Unit Info */}
            <div className="flex-1 max-w-md">
              {/* Selected Unit Info */}
              {gameState.combatState.selectedUnit && (
                <div className="bg-purple-900/50 p-4 rounded-lg mb-4">
                  {gameState.combatState.selectedUnit.butterfly ? (
                    <ButterflyCard butterfly={gameState.combatState.selectedUnit.butterfly} compact />
                  ) : gameState.combatState.selectedUnit.enemy && (
                    <div className="text-center">
                      <span className="text-4xl">{gameState.combatState.selectedUnit.enemy.icon}</span>
                      <h3 className="font-bold">{gameState.combatState.selectedUnit.enemy.name}</h3>
                      <p className="text-sm text-purple-300">{gameState.combatState.selectedUnit.enemy.description}</p>
                      <div className="mt-2">
                        <div className="w-full h-2 bg-gray-700 rounded overflow-hidden">
                          <div 
                            className="h-full bg-red-500" 
                            style={{ width: `${(gameState.combatState.selectedUnit.enemy.stats.hp / gameState.combatState.selectedUnit.enemy.stats.maxHp) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs">{gameState.combatState.selectedUnit.enemy.stats.hp}/{gameState.combatState.selectedUnit.enemy.stats.maxHp}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              {/* Combat Log */}
              <CombatLog messages={gameState.combatState.log} />
            </div>
          </div>
        </div>
      )}
      
      {/* Victory Screen */}
      {gameState.screen === 'victory' && gameState.dungeonRun && (
        <div className="min-h-screen flex flex-col items-center justify-center p-8">
          <h1 className="text-5xl font-bold text-yellow-400 mb-4">🏆 Vitória!</h1>
          <p className="text-2xl text-purple-300 mb-8">
            Você conquistou {REGIONS[gameState.dungeonRun.region].name}!
          </p>
          
          <div className="bg-purple-900/50 p-6 rounded-lg mb-8 text-center">
            <h2 className="text-xl font-bold mb-4">Recompensas</h2>
            <p className="text-yellow-400 text-2xl">💰 {gameState.dungeonRun.gold} Ouro</p>
            {gameState.dungeonRun.foundSeeds.length > 0 && (
              <p className="text-green-400 mt-2">
                🌱 Sementes: {gameState.dungeonRun.foundSeeds.map(s => `${PLANTS[s].icon} ${PLANTS[s].name}`).join(', ')}
              </p>
            )}
            {gameState.dungeonRun.foundButterflies.length > 0 && (
              <div className="mt-4">
                <p className="text-pink-400 mb-2">🦋 Borboletas Encontradas:</p>
                <div className="flex gap-2 justify-center flex-wrap">
                  {gameState.dungeonRun.foundButterflies.map(bf => (
                    <div key={bf.id} className="bg-purple-800/50 p-2 rounded">
                      <ButterflyCard butterfly={bf} compact />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <button
            onClick={() => endDungeonRun(true)}
            className="px-8 py-4 bg-green-600 hover:bg-green-500 rounded-lg text-xl font-bold"
          >
            🏠 Voltar para Casa
          </button>
        </div>
      )}
      
      {/* Defeat Screen */}
      {gameState.screen === 'defeat' && (
        <div className="min-h-screen flex flex-col items-center justify-center p-8">
          <h1 className="text-5xl font-bold text-red-400 mb-4">💀 Derrota</h1>
          <p className="text-xl text-purple-300 mb-8">Seu grupo foi derrotado...</p>
          
          <button
            onClick={() => goToScreen('household')}
            className="px-8 py-4 bg-purple-600 hover:bg-purple-500 rounded-lg text-xl font-bold"
          >
            🏠 Voltar para Casa
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
