// ════════════════════════════════════════════════════════════════
// PLANTS & SEEDS CONFIGURATION - Easy to edit!
// ════════════════════════════════════════════════════════════════
// Each region has unique seeds that can be found and grown.

import { PlantConfig } from './types.config';

export const PLANTS_CONFIG: Record<string, PlantConfig> = {
  // ═══════════════════════════════════════════════════════════
  // JARDIM ENCANTADO PLANTS
  // ═══════════════════════════════════════════════════════════
  girassol: {
    id: 'girassol',
    name: 'Girassol',
    emoji: '🌻',
    description: 'Flor que segue o sol, rica em néctar dourado.',
    
    growthTime: 100,
    stages: ['🌱', '🌿', '🌾', '🌻'],
    
    harvestYield: {
      nectar: { min: 15, max: 30 },
      seeds: [{ type: 'girassol', chance: 0.3 }]
    },
    
    region: 'jardim_encantado',
    rarity: 'common',
    
    butterflyEffects: {
      type: 'buff',
      value: 5
    }
  },
  
  rosa: {
    id: 'rosa',
    name: 'Rosa Encantada',
    emoji: '🌹',
    description: 'Rosa mágica com pétalas curativas.',
    
    growthTime: 150,
    stages: ['🌱', '🌿', '🌷', '🌹'],
    
    harvestYield: {
      nectar: { min: 20, max: 40 },
      items: [{ id: 'petala_rosa', chance: 0.5 }],
      seeds: [{ type: 'rosa', chance: 0.2 }]
    },
    
    region: 'jardim_encantado',
    rarity: 'uncommon',
    
    butterflyEffects: {
      type: 'heal',
      value: 10
    }
  },
  
  tulipa: {
    id: 'tulipa',
    name: 'Tulipa Arco-Íris',
    emoji: '🌷',
    description: 'Tulipa que muda de cor conforme cresce.',
    
    growthTime: 120,
    stages: ['🌱', '🌿', '🌸', '🌷'],
    
    harvestYield: {
      nectar: { min: 12, max: 25 },
      seeds: [{ type: 'tulipa', chance: 0.35 }]
    },
    
    region: 'jardim_encantado',
    rarity: 'common'
  },
  
  lavanda: {
    id: 'lavanda',
    name: 'Lavanda Mística',
    emoji: '💜',
    description: 'Erva aromática que acalma borboletas.',
    
    growthTime: 180,
    stages: ['🌱', '🌿', '🪻', '💜'],
    
    harvestYield: {
      nectar: { min: 25, max: 50 },
      items: [{ id: 'essencia_lavanda', chance: 0.4 }],
      seeds: [{ type: 'lavanda', chance: 0.25 }]
    },
    
    region: 'jardim_encantado',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'exp',
      value: 20
    }
  },

  // ═══════════════════════════════════════════════════════════
  // FLORESTA SOMBRIA PLANTS
  // ═══════════════════════════════════════════════════════════
  cogumelo_lunar: {
    id: 'cogumelo_lunar',
    name: 'Cogumelo Lunar',
    emoji: '🍄🌙',
    description: 'Cogumelo que brilha na escuridão.',
    
    growthTime: 200,
    stages: ['🟤', '🍄', '🍄✨', '🍄🌙'],
    
    harvestYield: {
      nectar: { min: 30, max: 60 },
      items: [{ id: 'espora_lunar', chance: 0.5 }],
      seeds: [{ type: 'cogumelo_lunar', chance: 0.2 }]
    },
    
    region: 'floresta_sombria',
    rarity: 'uncommon',
    
    butterflyEffects: {
      type: 'trait',
      value: 'visao_noturna'
    }
  },
  
  orquidea_negra: {
    id: 'orquidea_negra',
    name: 'Orquídea Negra',
    emoji: '🖤🌸',
    description: 'Flor rara que só floresce na escuridão total.',
    
    growthTime: 300,
    stages: ['🌱', '🌿', '🌺', '🖤🌸'],
    
    harvestYield: {
      nectar: { min: 50, max: 100 },
      items: [{ id: 'petala_negra', chance: 0.7 }],
      seeds: [{ type: 'orquidea_negra', chance: 0.1 }]
    },
    
    region: 'floresta_sombria',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'buff',
      value: 15
    }
  },
  
  erva_sombria: {
    id: 'erva_sombria',
    name: 'Erva Sombria',
    emoji: '🌿🌑',
    description: 'Erva que absorve a escuridão ao redor.',
    
    growthTime: 150,
    stages: ['🌱', '🌿', '🌿🌑', '🌿🌑'],
    
    harvestYield: {
      nectar: { min: 20, max: 40 },
      items: [{ id: 'essencia_sombria', chance: 0.4 }],
      seeds: [{ type: 'erva_sombria', chance: 0.3 }]
    },
    
    region: 'floresta_sombria',
    rarity: 'common'
  },
  
  flor_noturna: {
    id: 'flor_noturna',
    name: 'Flor Noturna',
    emoji: '🌙🌸',
    description: 'Flor que só abre à noite.',
    
    growthTime: 180,
    stages: ['🌱', '🌿', '🌙', '🌙🌸'],
    
    harvestYield: {
      nectar: { min: 35, max: 70 },
      seeds: [{ type: 'flor_noturna', chance: 0.25 }]
    },
    
    region: 'floresta_sombria',
    rarity: 'uncommon'
  },

  // ═══════════════════════════════════════════════════════════
  // CAVERNA CRISTALINA PLANTS
  // ═══════════════════════════════════════════════════════════
  cristal_semente: {
    id: 'cristal_semente',
    name: 'Cristal Vivo',
    emoji: '💎',
    description: 'Cristal que cresce como uma planta.',
    
    growthTime: 400,
    stages: ['💠', '💎', '💎✨', '💎💎'],
    
    harvestYield: {
      nectar: { min: 60, max: 120 },
      items: [
        { id: 'cristal_puro', chance: 0.6 },
        { id: 'gema_rara', chance: 0.2 }
      ],
      seeds: [{ type: 'cristal_semente', chance: 0.15 }]
    },
    
    region: 'caverna_cristalina',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'buff',
      value: 20
    }
  },
  
  flor_gelo: {
    id: 'flor_gelo',
    name: 'Flor de Gelo',
    emoji: '❄️🌸',
    description: 'Flor congelada eternamente.',
    
    growthTime: 250,
    stages: ['🌱', '❄️', '❄️🌿', '❄️🌸'],
    
    harvestYield: {
      nectar: { min: 40, max: 80 },
      items: [{ id: 'essencia_gelo', chance: 0.5 }],
      seeds: [{ type: 'flor_gelo', chance: 0.2 }]
    },
    
    region: 'caverna_cristalina',
    rarity: 'uncommon'
  },
  
  musgo_luminoso: {
    id: 'musgo_luminoso',
    name: 'Musgo Luminoso',
    emoji: '✨🌿',
    description: 'Musgo que emite luz própria.',
    
    growthTime: 100,
    stages: ['🌱', '🌿', '✨🌿', '✨🌿'],
    
    harvestYield: {
      nectar: { min: 15, max: 30 },
      seeds: [{ type: 'musgo_luminoso', chance: 0.4 }]
    },
    
    region: 'caverna_cristalina',
    rarity: 'common'
  },
  
  fungo_gema: {
    id: 'fungo_gema',
    name: 'Fungo Gema',
    emoji: '🍄💎',
    description: 'Fungo com chapéu de gema preciosa.',
    
    growthTime: 350,
    stages: ['🟤', '🍄', '🍄💠', '🍄💎'],
    
    harvestYield: {
      nectar: { min: 45, max: 90 },
      items: [
        { id: 'gema_fungo', chance: 0.5 },
        { id: 'espora_cristal', chance: 0.3 }
      ],
      seeds: [{ type: 'fungo_gema', chance: 0.15 }]
    },
    
    region: 'caverna_cristalina',
    rarity: 'rare'
  },

  // ═══════════════════════════════════════════════════════════
  // PÂNTANO MISTERIOSO PLANTS
  // ═══════════════════════════════════════════════════════════
  vitoria_regia: {
    id: 'vitoria_regia',
    name: 'Vitória-Régia',
    emoji: '🪷',
    description: 'Grande flor aquática do pântano.',
    
    growthTime: 200,
    stages: ['🌱', '🌿', '🪷', '🪷✨'],
    
    harvestYield: {
      nectar: { min: 35, max: 70 },
      items: [{ id: 'petala_regia', chance: 0.4 }],
      seeds: [{ type: 'vitoria_regia', chance: 0.25 }]
    },
    
    region: 'pantano_misterioso',
    rarity: 'uncommon'
  },
  
  erva_pantano: {
    id: 'erva_pantano',
    name: 'Erva do Pântano',
    emoji: '🌿💧',
    description: 'Erva medicinal que cresce na água.',
    
    growthTime: 120,
    stages: ['🌱', '🌿', '🌿💧', '🌿💧'],
    
    harvestYield: {
      nectar: { min: 20, max: 40 },
      items: [{ id: 'antidoto_pantano', chance: 0.5 }],
      seeds: [{ type: 'erva_pantano', chance: 0.35 }]
    },
    
    region: 'pantano_misterioso',
    rarity: 'common',
    
    butterflyEffects: {
      type: 'heal',
      value: 15
    }
  },
  
  flor_toxica: {
    id: 'flor_toxica',
    name: 'Flor Tóxica',
    emoji: '☠️🌸',
    description: 'Flor venenosa com propriedades especiais.',
    
    growthTime: 280,
    stages: ['🌱', '🌿', '🌺', '☠️🌸'],
    
    harvestYield: {
      nectar: { min: 30, max: 60 },
      items: [
        { id: 'veneno_concentrado', chance: 0.6 },
        { id: 'petala_toxica', chance: 0.4 }
      ],
      seeds: [{ type: 'flor_toxica', chance: 0.2 }]
    },
    
    region: 'pantano_misterioso',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'trait',
      value: 'asas_venenosas'
    }
  },
  
  musgo_curativo: {
    id: 'musgo_curativo',
    name: 'Musgo Curativo',
    emoji: '💚🌿',
    description: 'Musgo com propriedades regenerativas.',
    
    growthTime: 150,
    stages: ['🌱', '🌿', '💚', '💚🌿'],
    
    harvestYield: {
      nectar: { min: 25, max: 50 },
      items: [{ id: 'pomada_musgo', chance: 0.5 }],
      seeds: [{ type: 'musgo_curativo', chance: 0.3 }]
    },
    
    region: 'pantano_misterioso',
    rarity: 'uncommon',
    
    butterflyEffects: {
      type: 'heal',
      value: 25
    }
  },

  // ═══════════════════════════════════════════════════════════
  // VULCÃO ARDENTE PLANTS
  // ═══════════════════════════════════════════════════════════
  flor_fogo: {
    id: 'flor_fogo',
    name: 'Flor de Fogo',
    emoji: '🔥🌸',
    description: 'Flor que queima eternamente.',
    
    growthTime: 300,
    stages: ['🌱', '🔥', '🔥🌿', '🔥🌸'],
    
    harvestYield: {
      nectar: { min: 50, max: 100 },
      items: [{ id: 'essencia_fogo_pura', chance: 0.5 }],
      seeds: [{ type: 'flor_fogo', chance: 0.15 }]
    },
    
    region: 'vulcao_ardente',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'trait',
      value: 'asas_flamejantes'
    }
  },
  
  cacto_vulcanico: {
    id: 'cacto_vulcanico',
    name: 'Cacto Vulcânico',
    emoji: '🌵🔥',
    description: 'Cacto que sobrevive ao calor extremo.',
    
    growthTime: 250,
    stages: ['🌱', '🌵', '🌵🔥', '🌵🔥'],
    
    harvestYield: {
      nectar: { min: 40, max: 80 },
      items: [{ id: 'agua_cacto', chance: 0.6 }],
      seeds: [{ type: 'cacto_vulcanico', chance: 0.25 }]
    },
    
    region: 'vulcao_ardente',
    rarity: 'uncommon'
  },
  
  cinza_fenix: {
    id: 'cinza_fenix',
    name: 'Cinza de Fênix',
    emoji: '🪶🔥',
    description: 'Planta que renasce das cinzas.',
    
    growthTime: 500,
    stages: ['⚫', '🔥', '🪶', '🪶🔥'],
    
    harvestYield: {
      nectar: { min: 80, max: 150 },
      items: [
        { id: 'pena_fenix_jovem', chance: 0.4 },
        { id: 'cinza_renascimento', chance: 0.6 }
      ],
      seeds: [{ type: 'cinza_fenix', chance: 0.1 }]
    },
    
    region: 'vulcao_ardente',
    rarity: 'legendary',
    
    butterflyEffects: {
      type: 'trait',
      value: 'renascimento'
    }
  },
  
  magma_seed: {
    id: 'magma_seed',
    name: 'Semente de Magma',
    emoji: '🟠🌱',
    description: 'Semente feita de lava solidificada.',
    
    growthTime: 350,
    stages: ['🟠', '🟠🌱', '🟠🌿', '🟠🔥'],
    
    harvestYield: {
      nectar: { min: 60, max: 110 },
      items: [{ id: 'gota_magma', chance: 0.5 }],
      seeds: [{ type: 'magma_seed', chance: 0.2 }]
    },
    
    region: 'vulcao_ardente',
    rarity: 'rare'
  },

  // ═══════════════════════════════════════════════════════════
  // TEMPLO CELESTIAL PLANTS
  // ═══════════════════════════════════════════════════════════
  flor_celestial: {
    id: 'flor_celestial',
    name: 'Flor Celestial',
    emoji: '⭐🌸',
    description: 'Flor que brilha com luz estelar.',
    
    growthTime: 400,
    stages: ['🌱', '✨', '⭐', '⭐🌸'],
    
    harvestYield: {
      nectar: { min: 100, max: 200 },
      items: [{ id: 'petala_celestial', chance: 0.6 }],
      seeds: [{ type: 'flor_celestial', chance: 0.15 }]
    },
    
    region: 'templo_celestial',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'buff',
      value: 30
    }
  },
  
  arvore_mundo: {
    id: 'arvore_mundo',
    name: 'Muda da Árvore do Mundo',
    emoji: '🌳✨',
    description: 'Fragmento da lendária Árvore do Mundo.',
    
    growthTime: 1000,
    stages: ['🌱', '🌿', '🌲', '🌳', '🌳✨'],
    
    harvestYield: {
      nectar: { min: 200, max: 500 },
      items: [
        { id: 'folha_mundo', chance: 0.8 },
        { id: 'seiva_divina', chance: 0.5 },
        { id: 'fruto_imortalidade', chance: 0.1 }
      ],
      seeds: [{ type: 'arvore_mundo', chance: 0.05 }]
    },
    
    region: 'templo_celestial',
    rarity: 'legendary',
    
    butterflyEffects: {
      type: 'trait',
      value: 'imortalidade'
    }
  },
  
  semente_divina: {
    id: 'semente_divina',
    name: 'Semente Divina',
    emoji: '🌟🌱',
    description: 'Semente abençoada pelos deuses.',
    
    growthTime: 600,
    stages: ['🌟', '🌟🌱', '🌟🌿', '🌟🌸'],
    
    harvestYield: {
      nectar: { min: 150, max: 300 },
      items: [{ id: 'bencao_divina', chance: 0.7 }],
      seeds: [{ type: 'semente_divina', chance: 0.1 }]
    },
    
    region: 'templo_celestial',
    rarity: 'legendary',
    
    butterflyEffects: {
      type: 'exp',
      value: 100
    }
  },
  
  luz_solidificada: {
    id: 'luz_solidificada',
    name: 'Luz Solidificada',
    emoji: '💡✨',
    description: 'Luz pura cristalizada em forma de planta.',
    
    growthTime: 450,
    stages: ['💡', '💡✨', '✨✨', '💡✨✨'],
    
    harvestYield: {
      nectar: { min: 120, max: 240 },
      items: [
        { id: 'cristal_luz', chance: 0.6 },
        { id: 'essencia_pureza', chance: 0.4 }
      ],
      seeds: [{ type: 'luz_solidificada', chance: 0.12 }]
    },
    
    region: 'templo_celestial',
    rarity: 'rare',
    
    butterflyEffects: {
      type: 'heal',
      value: 50
    }
  }
};

// Helper functions
export function getPlant(id: string): PlantConfig | null {
  return PLANTS_CONFIG[id] || null;
}

export function getPlantsForRegion(regionId: string): PlantConfig[] {
  return Object.values(PLANTS_CONFIG).filter(p => p.region === regionId);
}

export function getAllPlants(): PlantConfig[] {
  return Object.values(PLANTS_CONFIG);
}

export function getPlantsByRarity(rarity: string): PlantConfig[] {
  return Object.values(PLANTS_CONFIG).filter(p => p.rarity === rarity);
}
