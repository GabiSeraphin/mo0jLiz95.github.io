// ════════════════════════════════════════════════════════════════
// MYSTERY EVENTS CONFIGURATION - Easy to edit!
// ════════════════════════════════════════════════════════════════
// Each region has unique mystery events with multiple choices.

import { MysteryEventConfig } from './types.config';

export const EVENTS_CONFIG: Record<string, MysteryEventConfig> = {
  // ═══════════════════════════════════════════════════════════
  // JARDIM ENCANTADO EVENTS
  // ═══════════════════════════════════════════════════════════
  fonte_magica: {
    id: 'fonte_magica',
    title: 'Fonte Mágica',
    description: 'Você encontra uma fonte de água cristalina que brilha com energia mágica. Pétalas de flores flutuam na superfície.',
    region: 'jardim_encantado',
    
    choices: [
      {
        text: 'Beber da água',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'A água rejuvenesce você completamente!', effects: [{ type: 'heal_all', value: 100 }] },
          { chance: 0.3, type: 'reward', message: 'Você se sente mais forte!', effects: [{ type: 'buff_all', value: 'attack_up' }] },
          { chance: 0.1, type: 'penalty', message: 'A água estava amaldiçoada...', effects: [{ type: 'damage_all', value: 10 }] }
        ]
      },
      {
        text: 'Coletar a água',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Você obtém uma poção!', effects: [{ type: 'item', value: 'pocao_cura' }] },
          { chance: 0.2, type: 'neutral', message: 'A água evapora ao ser tocada.', effects: [] }
        ]
      },
      {
        text: 'Deixar uma oferenda',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Uma fada aparece e abençoa você!', effects: [{ type: 'buff_all', value: 'bless' }, { type: 'gold', value: 50 }] },
          { chance: 0.5, type: 'reward', message: 'Você encontra algo brilhante no fundo.', effects: [{ type: 'gold', value: 30 }] }
        ]
      }
    ]
  },
  
  fada_perdida: {
    id: 'fada_perdida',
    title: 'Fada Perdida',
    description: 'Uma pequena fada está chorando, presa em uma teia de aranha. Ela parece exausta.',
    region: 'jardim_encantado',
    
    choices: [
      {
        text: 'Libertar a fada',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'A fada agradece com uma bênção mágica!', effects: [{ type: 'buff_all', value: 'haste' }, { type: 'exp', value: 30 }] },
          { chance: 0.2, type: 'reward', message: 'Era uma armadilha! Mas você vence facilmente.', effects: [{ type: 'combat', value: 'aranha' }] }
        ]
      },
      {
        text: 'Pedir algo em troca primeiro',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'A fada concorda e dá uma semente rara.', effects: [{ type: 'seed', value: 'lavanda' }] },
          { chance: 0.4, type: 'neutral', message: 'A fada fica ofendida e desaparece.', effects: [] }
        ]
      },
      {
        text: 'Ignorar e seguir em frente',
        outcomes: [
          { chance: 1.0, type: 'neutral', message: 'Você continua seu caminho...', effects: [] }
        ]
      }
    ]
  },
  
  colmeia_abandonada: {
    id: 'colmeia_abandonada',
    title: 'Colmeia Abandonada',
    description: 'Uma grande colmeia parece estar abandonada. Mel dourado escorre pelas laterais.',
    region: 'jardim_encantado',
    
    choices: [
      {
        text: 'Coletar o mel',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Mel delicioso! Vocês se recuperam.', effects: [{ type: 'heal_all', value: 20 }, { type: 'nectar', value: 40 }] },
          { chance: 0.5, type: 'penalty', message: 'As abelhas ainda estavam lá!', effects: [{ type: 'combat', value: 'abelha,abelha,abelha' }] }
        ]
      },
      {
        text: 'Investigar com cuidado',
        outcomes: [
          { chance: 0.7, type: 'reward', message: 'Você encontra mel real raro!', effects: [{ type: 'item', value: 'mel_real' }] },
          { chance: 0.3, type: 'reward', message: 'Apenas mel comum, mas bastante.', effects: [{ type: 'nectar', value: 30 }] }
        ]
      },
      {
        text: 'Deixar em paz',
        outcomes: [
          { chance: 1.0, type: 'neutral', message: 'Melhor não arriscar.', effects: [] }
        ]
      }
    ]
  },
  
  jardim_secreto: {
    id: 'jardim_secreto',
    title: 'Jardim Secreto',
    description: 'Atrás de uma cerca de rosas, você vislumbra um jardim escondido com flores que nunca viu antes.',
    region: 'jardim_encantado',
    
    choices: [
      {
        text: 'Entrar no jardim',
        outcomes: [
          { chance: 0.4, type: 'butterfly', message: 'Uma borboleta rara aparece e se junta a você!', effects: [{ type: 'butterfly', value: 'jardim_encantado' }] },
          { chance: 0.4, type: 'reward', message: 'Você coleta sementes raras!', effects: [{ type: 'seed', value: 'rosa' }, { type: 'seed', value: 'lavanda' }] },
          { chance: 0.2, type: 'penalty', message: 'O guardião do jardim não gostou!', effects: [{ type: 'combat', value: 'besouro_dourado' }] }
        ]
      },
      {
        text: 'Observar de longe',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Você aprende algo observando.', effects: [{ type: 'exp', value: 25 }] },
          { chance: 0.2, type: 'neutral', message: 'Nada de especial acontece.', effects: [] }
        ]
      }
    ]
  },

  // ═══════════════════════════════════════════════════════════
  // FLORESTA SOMBRIA EVENTS
  // ═══════════════════════════════════════════════════════════
  altar_sombrio: {
    id: 'altar_sombrio',
    title: 'Altar Sombrio',
    description: 'Um altar de pedra negra ergue-se na clareira. Runas antigas brilham com uma luz púrpura.',
    region: 'floresta_sombria',
    
    choices: [
      {
        text: 'Fazer uma oferenda de néctar',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Os espíritos aceitam sua oferenda!', effects: [{ type: 'nectar', value: -20 }, { type: 'buff_all', value: 'shadow_power' }, { type: 'exp', value: 50 }] },
          { chance: 0.3, type: 'reward', message: 'Uma semente sombria aparece!', effects: [{ type: 'nectar', value: -20 }, { type: 'seed', value: 'orquidea_negra' }] },
          { chance: 0.2, type: 'penalty', message: 'Os espíritos estão furiosos!', effects: [{ type: 'nectar', value: -20 }, { type: 'combat', value: 'lobo_sombra,lobo_sombra' }] }
        ]
      },
      {
        text: 'Tocar as runas',
        outcomes: [
          { chance: 0.4, type: 'reward', message: 'Conhecimento antigo flui para você!', effects: [{ type: 'exp', value: 75 }] },
          { chance: 0.3, type: 'penalty', message: 'Uma maldição cai sobre você!', effects: [{ type: 'debuff_all', value: 'curse' }] },
          { chance: 0.3, type: 'reward', message: 'Você ganha visão noturna!', effects: [{ type: 'trait_random', value: 'visao_noturna' }] }
        ]
      },
      {
        text: 'Afastar-se com cuidado',
        outcomes: [
          { chance: 1.0, type: 'neutral', message: 'Melhor não mexer com forças desconhecidas.', effects: [] }
        ]
      }
    ]
  },
  
  viajante_perdido: {
    id: 'viajante_perdido',
    title: 'Viajante Perdido',
    description: 'Um besouro viajante está perdido na floresta. Ele parece assustado e faminto.',
    region: 'floresta_sombria',
    
    choices: [
      {
        text: 'Compartilhar seu néctar',
        outcomes: [
          { chance: 0.7, type: 'reward', message: 'Ele agradece e dá um mapa!', effects: [{ type: 'nectar', value: -15 }, { type: 'reveal_map', value: 3 }] },
          { chance: 0.3, type: 'reward', message: 'Ele se junta temporariamente a você!', effects: [{ type: 'nectar', value: -15 }, { type: 'temp_ally', value: 'besouro' }] }
        ]
      },
      {
        text: 'Mostrar o caminho',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Ele agradece com ouro!', effects: [{ type: 'gold', value: 40 }] },
          { chance: 0.2, type: 'neutral', message: 'Ele segue seu caminho sem agradecer.', effects: [] }
        ]
      },
      {
        text: 'Ignorar',
        outcomes: [
          { chance: 0.8, type: 'neutral', message: 'Você segue em frente.', effects: [] },
          { chance: 0.2, type: 'penalty', message: 'Era uma armadilha!', effects: [{ type: 'combat', value: 'aranha' }] }
        ]
      }
    ]
  },
  
  cogumelo_falante: {
    id: 'cogumelo_falante',
    title: 'Cogumelo Falante',
    description: 'Um cogumelo gigante com olhos brilhantes fala com você em uma voz grave.',
    region: 'floresta_sombria',
    
    choices: [
      {
        text: 'Ouvir sua história',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'Ele revela segredos da floresta!', effects: [{ type: 'exp', value: 60 }, { type: 'reveal_map', value: 2 }] },
          { chance: 0.4, type: 'reward', message: 'Você aprende sobre plantas!', effects: [{ type: 'seed', value: 'cogumelo_lunar' }] }
        ]
      },
      {
        text: 'Pedir um favor',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Ele cura todos vocês!', effects: [{ type: 'heal_all', value: 50 }] },
          { chance: 0.3, type: 'penalty', message: 'Ele não gostou da sua petulância!', effects: [{ type: 'damage_all', value: 15 }] },
          { chance: 0.2, type: 'reward', message: 'Ele dá uma bênção fungica!', effects: [{ type: 'buff_all', value: 'regen' }] }
        ]
      },
      {
        text: 'Atacar o cogumelo',
        outcomes: [
          { chance: 0.3, type: 'reward', message: 'Você obtém esporos raros!', effects: [{ type: 'item', value: 'espora_lunar' }, { type: 'combat', value: 'cogumelo_guardiao' }] },
          { chance: 0.7, type: 'penalty', message: 'Má ideia! Ele é poderoso!', effects: [{ type: 'combat', value: 'cogumelo_guardiao,cogumelo_guardiao' }] }
        ]
      }
    ]
  },
  
  portal_dimensao: {
    id: 'portal_dimensao',
    title: 'Portal Dimensional',
    description: 'Um portal roxo pulsa na escuridão. Sombras dançam ao seu redor.',
    region: 'floresta_sombria',
    
    choices: [
      {
        text: 'Entrar no portal',
        outcomes: [
          { chance: 0.3, type: 'reward', message: 'Você encontra um tesouro dimensional!', effects: [{ type: 'gold', value: 100 }, { type: 'item', value: 'essencia_sombria' }] },
          { chance: 0.3, type: 'butterfly', message: 'Uma borboleta sombria emerge!', effects: [{ type: 'butterfly', value: 'floresta_sombria' }] },
          { chance: 0.4, type: 'penalty', message: 'Criaturas sombrias atacam!', effects: [{ type: 'combat', value: 'lobo_sombra,aranha,morcego' }] }
        ]
      },
      {
        text: 'Estudar o portal',
        outcomes: [
          { chance: 0.7, type: 'reward', message: 'Você aprende magia sombria!', effects: [{ type: 'exp', value: 80 }] },
          { chance: 0.3, type: 'penalty', message: 'O portal drena sua energia.', effects: [{ type: 'damage_all', value: 20 }] }
        ]
      },
      {
        text: 'Fechar o portal',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Os espíritos agradecem!', effects: [{ type: 'gold', value: 50 }, { type: 'heal_all', value: 30 }] },
          { chance: 0.2, type: 'neutral', message: 'O portal se fecha sozinho.', effects: [] }
        ]
      }
    ]
  },

  // ═══════════════════════════════════════════════════════════
  // CAVERNA CRISTALINA EVENTS
  // ═══════════════════════════════════════════════════════════
  veio_cristal: {
    id: 'veio_cristal',
    title: 'Veio de Cristal',
    description: 'Uma parede inteira brilha com cristais multicoloridos. Alguns parecem extremamente valiosos.',
    region: 'caverna_cristalina',
    
    choices: [
      {
        text: 'Minerar os cristais',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Você obtém cristais valiosos!', effects: [{ type: 'gold', value: 80 }, { type: 'item', value: 'cristal_puro' }] },
          { chance: 0.3, type: 'penalty', message: 'A caverna treme! Golems aparecem!', effects: [{ type: 'combat', value: 'golem_pequeno,golem_pequeno' }] },
          { chance: 0.2, type: 'reward', message: 'Você encontra uma gema rara!', effects: [{ type: 'item', value: 'gema_rara' }, { type: 'gold', value: 50 }] }
        ]
      },
      {
        text: 'Absorver a energia dos cristais',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'Poder cristalino flui em você!', effects: [{ type: 'buff_all', value: 'crystal_power' }] },
          { chance: 0.4, type: 'penalty', message: 'A energia é demais!', effects: [{ type: 'damage_all', value: 25 }, { type: 'buff_all', value: 'attack_up' }] }
        ]
      },
      {
        text: 'Procurar sementes de cristal',
        outcomes: [
          { chance: 0.7, type: 'reward', message: 'Você encontra!', effects: [{ type: 'seed', value: 'cristal_semente' }] },
          { chance: 0.3, type: 'neutral', message: 'Nada encontrado.', effects: [] }
        ]
      }
    ]
  },
  
  eco_ancestral: {
    id: 'eco_ancestral',
    title: 'Eco Ancestral',
    description: 'Vozes antigas ecoam pelas paredes de cristal. Elas parecem contar histórias de eras passadas.',
    region: 'caverna_cristalina',
    
    choices: [
      {
        text: 'Ouvir atentamente',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Sabedoria ancestral!', effects: [{ type: 'exp', value: 100 }] },
          { chance: 0.2, type: 'reward', message: 'Os ancestrais abençoam você!', effects: [{ type: 'trait_random', value: 'corpo_prismatico' }] }
        ]
      },
      {
        text: 'Responder as vozes',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'As vozes aprovam!', effects: [{ type: 'heal_all', value: 100 }, { type: 'gold', value: 60 }] },
          { chance: 0.5, type: 'penalty', message: 'As vozes se irritam!', effects: [{ type: 'debuff_all', value: 'confuse' }] }
        ]
      }
    ]
  },

  // ═══════════════════════════════════════════════════════════
  // PÂNTANO MISTERIOSO EVENTS
  // ═══════════════════════════════════════════════════════════
  poco_toxico: {
    id: 'poco_toxico',
    title: 'Poço Tóxico',
    description: 'Um poço borbulha com líquido verde fluorescente. Um cheiro forte emana dele.',
    region: 'pantano_misterioso',
    
    choices: [
      {
        text: 'Beber (se tiver imunidade a toxinas)',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'O veneno fortalece você!', effects: [{ type: 'buff_all', value: 'poison_power' }, { type: 'trait_random', value: 'asas_venenosas' }] },
          { chance: 0.2, type: 'reward', message: 'Você ganha imunidade permanente!', effects: [{ type: 'trait_random', value: 'imunidade_toxinas' }] }
        ],
        requirements: { type: 'butterfly_trait', value: 'imunidade_toxinas' }
      },
      {
        text: 'Coletar em um frasco',
        outcomes: [
          { chance: 0.7, type: 'reward', message: 'Veneno coletado!', effects: [{ type: 'item', value: 'veneno_concentrado' }] },
          { chance: 0.3, type: 'penalty', message: 'Você se contamina!', effects: [{ type: 'debuff_all', value: 'poison' }] }
        ]
      },
      {
        text: 'Evitar',
        outcomes: [
          { chance: 1.0, type: 'neutral', message: 'Melhor não arriscar.', effects: [] }
        ]
      }
    ]
  },
  
  sapo_sabio: {
    id: 'sapo_sabio',
    title: 'Sapo Sábio',
    description: 'Um sapo enorme e velho medita em uma vitória-régia. Seus olhos brilham com sabedoria.',
    region: 'pantano_misterioso',
    
    choices: [
      {
        text: 'Pedir conselho',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'Ele revela o caminho!', effects: [{ type: 'reveal_map', value: 5 }, { type: 'exp', value: 40 }] },
          { chance: 0.4, type: 'reward', message: 'Ele ensina técnicas de sobrevivência!', effects: [{ type: 'exp', value: 70 }] }
        ]
      },
      {
        text: 'Oferecer presentes',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Ele dá uma semente rara!', effects: [{ type: 'nectar', value: -30 }, { type: 'seed', value: 'vitoria_regia' }] },
          { chance: 0.2, type: 'reward', message: 'Ele abençoa uma borboleta!', effects: [{ type: 'nectar', value: -30 }, { type: 'trait_random', value: 'imunidade_toxinas' }] }
        ]
      },
      {
        text: 'Desafiá-lo',
        outcomes: [
          { chance: 0.3, type: 'reward', message: 'Você vence e ganha respeito!', effects: [{ type: 'combat', value: 'sapo_toxico_elite' }, { type: 'gold', value: 100 }] },
          { chance: 0.7, type: 'penalty', message: 'Má ideia...', effects: [{ type: 'combat', value: 'sapo_anciao_mini' }] }
        ]
      }
    ]
  },

  // ═══════════════════════════════════════════════════════════
  // VULCÃO ARDENTE EVENTS
  // ═══════════════════════════════════════════════════════════
  forja_antiga: {
    id: 'forja_antiga',
    title: 'Forja Antiga',
    description: 'Uma forja antiga ainda arde com chamas eternas. Ferramentas enferrujadas jazem por perto.',
    region: 'vulcao_ardente',
    
    choices: [
      {
        text: 'Usar a forja',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Você forja um item poderoso!', effects: [{ type: 'item', value: 'espada_vulcanica' }] },
          { chance: 0.3, type: 'reward', message: 'A forja abençoa suas armas!', effects: [{ type: 'buff_all', value: 'fire_weapon' }] },
          { chance: 0.2, type: 'penalty', message: 'A forja explode!', effects: [{ type: 'damage_all', value: 30 }] }
        ]
      },
      {
        text: 'Procurar tesouros',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'Itens deixados por ferreiros antigos!', effects: [{ type: 'gold', value: 70 }, { type: 'item', value: 'brasa_eterna' }] },
          { chance: 0.4, type: 'neutral', message: 'Apenas ferrugem.', effects: [] }
        ]
      },
      {
        text: 'Coletar cinzas de fênix',
        outcomes: [
          { chance: 0.4, type: 'reward', message: 'Cinzas preciosas!', effects: [{ type: 'seed', value: 'cinza_fenix' }] },
          { chance: 0.6, type: 'neutral', message: 'Não há cinzas aqui.', effects: [] }
        ]
      }
    ]
  },
  
  dragao_adormecido: {
    id: 'dragao_adormecido',
    title: 'Dragão Adormecido',
    description: 'Um dragão jovem dorme sobre uma pilha de tesouros. Suas escamas brilham como rubis.',
    region: 'vulcao_ardente',
    
    choices: [
      {
        text: 'Roubar tesouro (arriscado)',
        outcomes: [
          { chance: 0.3, type: 'reward', message: 'Sucesso! Você pega muito ouro!', effects: [{ type: 'gold', value: 200 }, { type: 'item', value: 'escama_dragao' }] },
          { chance: 0.7, type: 'penalty', message: 'O dragão acorda!', effects: [{ type: 'combat', value: 'dragao_jovem' }] }
        ]
      },
      {
        text: 'Acordar gentilmente',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'O dragão está de bom humor!', effects: [{ type: 'buff_all', value: 'dragon_blessing' }, { type: 'gold', value: 50 }] },
          { chance: 0.5, type: 'penalty', message: 'O dragão ataca!', effects: [{ type: 'combat', value: 'dragao_jovem' }] }
        ]
      },
      {
        text: 'Deixar em paz',
        outcomes: [
          { chance: 1.0, type: 'neutral', message: 'Você se afasta silenciosamente.', effects: [] }
        ]
      }
    ]
  },

  // ═══════════════════════════════════════════════════════════
  // TEMPLO CELESTIAL EVENTS
  // ═══════════════════════════════════════════════════════════
  oraculo: {
    id: 'oraculo',
    title: 'O Oráculo',
    description: 'Uma entidade de luz pura flutua diante de você. Ela vê passado, presente e futuro.',
    region: 'templo_celestial',
    
    choices: [
      {
        text: 'Perguntar sobre o futuro',
        outcomes: [
          { chance: 0.7, type: 'reward', message: 'O Oráculo revela tudo!', effects: [{ type: 'reveal_map', value: 10 }, { type: 'exp', value: 100 }] },
          { chance: 0.3, type: 'reward', message: 'Você vê sua vitória!', effects: [{ type: 'buff_all', value: 'destiny' }] }
        ]
      },
      {
        text: 'Pedir uma bênção',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Bênção celestial concedida!', effects: [{ type: 'heal_all', value: 100 }, { type: 'buff_all', value: 'bless' }] },
          { chance: 0.3, type: 'reward', message: 'Uma borboleta divina aparece!', effects: [{ type: 'butterfly', value: 'templo_celestial' }] },
          { chance: 0.2, type: 'neutral', message: 'Você ainda não é digno.', effects: [] }
        ]
      },
      {
        text: 'Oferecer sua essência',
        outcomes: [
          { chance: 0.6, type: 'reward', message: 'Transcendência!', effects: [{ type: 'damage_all', value: 20 }, { type: 'trait_random', value: 'transcendencia' }] },
          { chance: 0.4, type: 'reward', message: 'O Oráculo aprova!', effects: [{ type: 'damage_all', value: 20 }, { type: 'item', value: 'essencia_divina' }] }
        ]
      }
    ]
  },
  
  biblioteca_infinita: {
    id: 'biblioteca_infinita',
    title: 'Biblioteca Infinita',
    description: 'Estantes sem fim contêm todo o conhecimento do universo. O que você buscará?',
    region: 'templo_celestial',
    
    choices: [
      {
        text: 'Estudar combate',
        outcomes: [
          { chance: 1.0, type: 'reward', message: 'Conhecimento de batalha absorvido!', effects: [{ type: 'buff_all', value: 'attack_up' }, { type: 'buff_all', value: 'defense_up' }, { type: 'exp', value: 150 }] }
        ]
      },
      {
        text: 'Estudar genética',
        outcomes: [
          { chance: 1.0, type: 'reward', message: 'Segredos da genética revelados!', effects: [{ type: 'trait_random', value: 'asas_imperiais' }, { type: 'exp', value: 100 }] }
        ]
      },
      {
        text: 'Estudar jardinagem',
        outcomes: [
          { chance: 1.0, type: 'reward', message: 'Conhecimento de plantas raras!', effects: [{ type: 'seed', value: 'arvore_mundo' }, { type: 'seed', value: 'flor_celestial' }] }
        ]
      }
    ]
  },
  
  jardim_eden: {
    id: 'jardim_eden',
    title: 'Jardim do Éden',
    description: 'O jardim perfeito, onde todas as flores existem em harmonia eterna.',
    region: 'templo_celestial',
    
    choices: [
      {
        text: 'Descansar no jardim',
        outcomes: [
          { chance: 1.0, type: 'reward', message: 'Paz total. Todos curados.', effects: [{ type: 'heal_all', value: 999 }, { type: 'cleanse_all', value: 1 }] }
        ]
      },
      {
        text: 'Coletar sementes',
        outcomes: [
          { chance: 0.5, type: 'reward', message: 'Sementes lendárias!', effects: [{ type: 'seed', value: 'arvore_mundo' }, { type: 'seed', value: 'semente_divina' }] },
          { chance: 0.5, type: 'reward', message: 'Várias sementes celestiais!', effects: [{ type: 'seed', value: 'flor_celestial' }, { type: 'seed', value: 'luz_solidificada' }] }
        ]
      },
      {
        text: 'Procurar a borboleta original',
        outcomes: [
          { chance: 0.3, type: 'butterfly', message: 'A primeira borboleta se junta a você!', effects: [{ type: 'butterfly', value: 'templo_celestial' }] },
          { chance: 0.7, type: 'reward', message: 'Você sente sua presença, mas ela não aparece.', effects: [{ type: 'buff_all', value: 'primordial_blessing' }] }
        ]
      }
    ]
  },
  
  trono_vazio: {
    id: 'trono_vazio',
    title: 'O Trono Vazio',
    description: 'O trono do Imperador Mariposa está vazio. Um poder imenso emana dele.',
    region: 'templo_celestial',
    
    choices: [
      {
        text: 'Sentar no trono',
        outcomes: [
          { chance: 0.3, type: 'reward', message: 'Você é digno! Poder imperial!', effects: [{ type: 'trait_random', value: 'asas_imperiais' }, { type: 'trait_random', value: 'aura_divina' }] },
          { chance: 0.4, type: 'penalty', message: 'O trono rejeita você!', effects: [{ type: 'damage_all', value: 50 }] },
          { chance: 0.3, type: 'penalty', message: 'O Imperador aparece, furioso!', effects: [{ type: 'combat', value: 'imperador_mariposa' }] }
        ]
      },
      {
        text: 'Examinar o trono',
        outcomes: [
          { chance: 0.8, type: 'reward', message: 'Você encontra segredos!', effects: [{ type: 'exp', value: 200 }, { type: 'gold', value: 150 }] },
          { chance: 0.2, type: 'reward', message: 'Um compartimento secreto!', effects: [{ type: 'item', value: 'coroa_imperador' }] }
        ]
      },
      {
        text: 'Reverenciar e partir',
        outcomes: [
          { chance: 1.0, type: 'reward', message: 'Sua humildade é recompensada.', effects: [{ type: 'buff_all', value: 'humble_blessing' }, { type: 'heal_all', value: 50 }] }
        ]
      }
    ]
  }
};

// Helper functions
export function getEvent(id: string): MysteryEventConfig | null {
  return EVENTS_CONFIG[id] || null;
}

export function getEventsForRegion(regionId: string): MysteryEventConfig[] {
  return Object.values(EVENTS_CONFIG).filter(e => e.region === regionId);
}

export function getRandomEventForRegion(regionId: string): MysteryEventConfig | null {
  const events = getEventsForRegion(regionId);
  if (events.length === 0) return null;
  return events[Math.floor(Math.random() * events.length)];
}

export function getAllEvents(): MysteryEventConfig[] {
  return Object.values(EVENTS_CONFIG);
}
