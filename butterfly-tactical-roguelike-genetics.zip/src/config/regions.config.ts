// ════════════════════════════════════════════════════════════════
// REGIONS CONFIG - Easy to edit!
// Each region has: adventure settings, dungeon tiles, exclusive content
// ════════════════════════════════════════════════════════════════

export interface RegionTile {
  id: string;
  name: string;
  emoji: string;
  imgSrc?: string; // Optional image path
  color: string;
  walkable: boolean;
  effect?: {
    type: 'heal' | 'damage' | 'buff' | 'debuff' | 'teleport' | 'trap' | 'nectar';
    value: number;
    message: string;
  };
  spawnWeight: number; // How often this tile appears (0-100)
}

export interface RegionExclusiveTrait {
  id: string;
  name: string;
  namePt: string;
  description: string;
  descriptionPt: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  statBonus?: { [stat: string]: number };
  combatBonus?: { [stat: string]: number };
}

export interface RegionSeed {
  id: string;
  name: string;
  namePt: string;
  icon: string;
  growthTime: number; // in game ticks
  nectarType: string;
  nectarAmount: number;
  cost: number;
  rarity: 'common' | 'uncommon' | 'rare';
}

export interface RegionEnemy {
  id: string;
  name: string;
  emoji: string;
  hp: number;
  attack: number;
  defense: number;
  speed: number;
  abilities: string[];
  dropChance: number;
}

export interface RegionBoss {
  id: string;
  name: string;
  namePt: string;
  emoji: string;
  title: string;
  titlePt: string;
  hp: number;
  attack: number;
  defense: number;
  speed: number;
  phases: {
    hpPercent: number;
    message: string;
    messagePt: string;
    attackBonus: number;
    newAbility?: string;
  }[];
  abilities: {
    name: string;
    namePt: string;
    damage: number;
    range: number;
    cooldown: number;
    effect?: string;
    aoe?: number;
    description: string;
    descriptionPt: string;
  }[];
  dialogue: {
    intro: string;
    introPt: string;
    phase2?: string;
    phase2Pt?: string;
    death: string;
    deathPt: string;
  };
  loot: {
    nectar: { min: number; max: number; type: string };
    seedChance: number;
    butterflyChance: number;
    exclusiveTraitChance: number;
  };
}

export interface Region {
  // Basic info
  id: string;
  name: string;
  namePt: string;
  desc: string;
  descPt: string;
  icon: string;
  iconImg?: string; // Your image path
  
  // Adventure settings (for timed expeditions)
  duration: number; // ms
  nectarCost: number;
  dangerLevel: number;
  deathChance: number;
  butterflyChance: number;
  seedChance: number;
  
  // Dungeon settings (for tactical combat)
  floors: number;
  roomsPerFloor: number;
  
  // Visual theme
  backgroundColor: string;
  ambientColor: string;
  particleEmoji: string[];
  
  // Tiles for the grid
  tiles: RegionTile[];
  
  // Exclusive content
  exclusiveTraits: RegionExclusiveTrait[];
  seeds: RegionSeed[];
  enemies: RegionEnemy[];
  boss: RegionBoss;
  
  // Butterfly color pools exclusive to this region
  exclusiveColors: string[];
  exclusivePatterns: string[];
  
  // Unlock requirements
  unlockRequirement?: {
    type: 'level' | 'boss' | 'butterflies' | 'nectar';
    value: number | string;
    description: string;
    descriptionPt: string;
  };
}

// ════════════════════════════════════════════════════════════════
// REGION DEFINITIONS - Edit these!
// ════════════════════════════════════════════════════════════════

export const REGIONS: { [key: string]: Region } = {
  jardim_encantado: {
    id: 'jardim_encantado',
    name: 'Enchanted Garden',
    namePt: 'Jardim Encantado',
    desc: 'A peaceful garden full of flowers and friendly creatures.',
    descPt: 'Um jardim tranquilo cheio de flores e criaturas amigáveis.',
    icon: '🌸',
    iconImg: '/images/regions/garden.png',
    
    duration: 30000,
    nectarCost: 10,
    dangerLevel: 1,
    deathChance: 0.02,
    butterflyChance: 0.3,
    seedChance: 0.4,
    
    floors: 3,
    roomsPerFloor: 5,
    
    backgroundColor: '#e8f5e9',
    ambientColor: '#a5d6a7',
    particleEmoji: ['🌸', '🌺', '🌷', '🦋', '✨', '🌼'],
    
    tiles: [
      {
        id: 'grass',
        name: 'Grass',
        emoji: '🌿',
        color: '#7cb342',
        walkable: true,
        spawnWeight: 50
      },
      {
        id: 'flower_pink',
        name: 'Pink Flower',
        emoji: '🌸',
        color: '#f8bbd9',
        walkable: true,
        effect: { type: 'heal', value: 5, message: 'The flower heals you!' },
        spawnWeight: 15
      },
      {
        id: 'flower_yellow',
        name: 'Sunflower',
        emoji: '🌻',
        color: '#fff59d',
        walkable: true,
        effect: { type: 'buff', value: 1, message: 'Energized by sunlight!' },
        spawnWeight: 10
      },
      {
        id: 'flower_red',
        name: 'Rose',
        emoji: '🌹',
        color: '#ef5350',
        walkable: true,
        effect: { type: 'nectar', value: 2, message: '+2 Rose nectar!' },
        spawnWeight: 8
      },
      {
        id: 'bush',
        name: 'Bush',
        emoji: '🌳',
        color: '#558b2f',
        walkable: false,
        spawnWeight: 10
      },
      {
        id: 'pond',
        name: 'Pond',
        emoji: '💧',
        color: '#4fc3f7',
        walkable: false,
        spawnWeight: 5
      },
      {
        id: 'mushroom',
        name: 'Mushroom',
        emoji: '🍄',
        color: '#d7ccc8',
        walkable: true,
        effect: { type: 'heal', value: 10, message: 'Healing mushroom!' },
        spawnWeight: 2
      }
    ],
    
    exclusiveTraits: [
      {
        id: 'garden_blessing',
        name: 'Garden Blessing',
        namePt: 'Bênção do Jardim',
        description: 'This butterfly carries the blessing of the garden.',
        descriptionPt: 'Esta borboleta carrega a bênção do jardim.',
        rarity: 'uncommon',
        statBonus: { fertility: 0.1, beauty: 5 },
        combatBonus: { healing: 10 }
      },
      {
        id: 'petal_wings',
        name: 'Petal Wings',
        namePt: 'Asas de Pétala',
        description: 'Wings that shimmer like flower petals.',
        descriptionPt: 'Asas que brilham como pétalas de flores.',
        rarity: 'rare',
        statBonus: { beauty: 15, agility: 3 },
        combatBonus: { dodge: 5 }
      },
      {
        id: 'nectar_collector',
        name: 'Expert Nectar Collector',
        namePt: 'Coletor de Néctar Expert',
        description: 'Exceptionally skilled at gathering nectar.',
        descriptionPt: 'Excepcionalmente habilidoso em coletar néctar.',
        rarity: 'common',
        statBonus: { stamina: 5 }
      }
    ],
    
    seeds: [
      {
        id: 'rosa',
        name: 'Rose',
        namePt: 'Rosa',
        icon: '🌹',
        growthTime: 100,
        nectarType: 'Rosa',
        nectarAmount: 3,
        cost: 15,
        rarity: 'common'
      },
      {
        id: 'girassol',
        name: 'Sunflower',
        namePt: 'Girassol',
        icon: '🌻',
        growthTime: 80,
        nectarType: 'Girassol',
        nectarAmount: 4,
        cost: 20,
        rarity: 'common'
      },
      {
        id: 'margarida',
        name: 'Daisy',
        namePt: 'Margarida',
        icon: '🌼',
        growthTime: 60,
        nectarType: 'basic',
        nectarAmount: 2,
        cost: 10,
        rarity: 'common'
      }
    ],
    
    enemies: [
      {
        id: 'bee',
        name: 'Worker Bee',
        emoji: '🐝',
        hp: 30,
        attack: 8,
        defense: 3,
        speed: 4,
        abilities: ['sting', 'buzz'],
        dropChance: 0.3
      },
      {
        id: 'ladybug',
        name: 'Angry Ladybug',
        emoji: '🐞',
        hp: 25,
        attack: 6,
        defense: 5,
        speed: 3,
        abilities: ['shell_defense'],
        dropChance: 0.2
      },
      {
        id: 'caterpillar',
        name: 'Hungry Caterpillar',
        emoji: '🐛',
        hp: 40,
        attack: 5,
        defense: 2,
        speed: 2,
        abilities: ['munch', 'curl'],
        dropChance: 0.25
      }
    ],
    
    boss: {
      id: 'queen_bee',
      name: 'Queen Bee',
      namePt: 'Abelha Rainha',
      emoji: '👑🐝',
      title: 'Ruler of the Garden',
      titlePt: 'Governante do Jardim',
      hp: 200,
      attack: 15,
      defense: 8,
      speed: 3,
      phases: [
        {
          hpPercent: 75,
          message: 'You dare challenge the Queen?!',
          messagePt: 'Você ousa desafiar a Rainha?!',
          attackBonus: 1.2,
          newAbility: 'summon_swarm'
        },
        {
          hpPercent: 40,
          message: 'My subjects will destroy you!',
          messagePt: 'Meus súditos irão destruí-lo!',
          attackBonus: 1.5,
          newAbility: 'royal_fury'
        }
      ],
      abilities: [
        {
          name: 'Royal Sting',
          namePt: 'Ferrão Real',
          damage: 25,
          range: 2,
          cooldown: 2,
          effect: 'poison',
          description: 'A devastating poison sting',
          descriptionPt: 'Um ferrão venenoso devastador'
        },
        {
          name: 'Summon Swarm',
          namePt: 'Invocar Enxame',
          damage: 10,
          range: 5,
          cooldown: 4,
          aoe: 3,
          description: 'Summons worker bees to attack',
          descriptionPt: 'Invoca abelhas operárias para atacar'
        },
        {
          name: 'Honey Trap',
          namePt: 'Armadilha de Mel',
          damage: 5,
          range: 3,
          cooldown: 3,
          effect: 'slow',
          aoe: 2,
          description: 'Covers area in sticky honey',
          descriptionPt: 'Cobre a área em mel pegajoso'
        }
      ],
      dialogue: {
        intro: 'Intruders in MY garden?! You will become food for my larvae!',
        introPt: 'Invasores no MEU jardim?! Vocês se tornarão comida para minhas larvas!',
        phase2: 'ENOUGH! Feel the wrath of the hive!',
        phase2Pt: 'CHEGA! Sintam a fúria da colmeia!',
        death: 'The garden... will remember... my reign...',
        deathPt: 'O jardim... lembrará... do meu reinado...'
      },
      loot: {
        nectar: { min: 50, max: 100, type: 'basic' },
        seedChance: 0.8,
        butterflyChance: 0.5,
        exclusiveTraitChance: 0.3
      }
    },
    
    exclusiveColors: ['#FFB6C1', '#FFC0CB', '#FF69B4', '#FFD700', '#98FB98'],
    exclusivePatterns: ['spotted_pink', 'striped_gold', 'gradient_spring'],
    
    unlockRequirement: undefined // Starting region
  },

  floresta_sombria: {
    id: 'floresta_sombria',
    name: 'Shadow Forest',
    namePt: 'Floresta Sombria',
    desc: 'A dark forest where light barely penetrates the canopy.',
    descPt: 'Uma floresta escura onde a luz mal penetra o dossel.',
    icon: '🌲',
    iconImg: '/images/regions/forest.png',
    
    duration: 60000,
    nectarCost: 25,
    dangerLevel: 2,
    deathChance: 0.08,
    butterflyChance: 0.25,
    seedChance: 0.3,
    
    floors: 4,
    roomsPerFloor: 6,
    
    backgroundColor: '#1b2a1b',
    ambientColor: '#2e4a2e',
    particleEmoji: ['🍂', '🌲', '🦉', '🕸️', '✨', '🍃'],
    
    tiles: [
      {
        id: 'dark_grass',
        name: 'Dark Grass',
        emoji: '🌑',
        color: '#2d3a2d',
        walkable: true,
        spawnWeight: 45
      },
      {
        id: 'dead_leaves',
        name: 'Dead Leaves',
        emoji: '🍂',
        color: '#5d4037',
        walkable: true,
        spawnWeight: 20
      },
      {
        id: 'mushroom_glow',
        name: 'Glowing Mushroom',
        emoji: '🍄',
        color: '#7c4dff',
        walkable: true,
        effect: { type: 'buff', value: 2, message: 'Mystical energy flows through you!' },
        spawnWeight: 8
      },
      {
        id: 'spider_web',
        name: 'Spider Web',
        emoji: '🕸️',
        color: '#e0e0e0',
        walkable: true,
        effect: { type: 'debuff', value: 2, message: 'Stuck in web! Speed reduced!' },
        spawnWeight: 10
      },
      {
        id: 'tree_trunk',
        name: 'Tree Trunk',
        emoji: '🌲',
        color: '#3e2723',
        walkable: false,
        spawnWeight: 12
      },
      {
        id: 'hollow_log',
        name: 'Hollow Log',
        emoji: '🪵',
        color: '#4e342e',
        walkable: true,
        effect: { type: 'heal', value: 8, message: 'Rest in the hollow log...' },
        spawnWeight: 5
      }
    ],
    
    exclusiveTraits: [
      {
        id: 'shadow_cloak',
        name: 'Shadow Cloak',
        namePt: 'Manto das Sombras',
        description: 'Can blend into darkness for protection.',
        descriptionPt: 'Pode se misturar às sombras para proteção.',
        rarity: 'rare',
        statBonus: { stamina: 8 },
        combatBonus: { dodge: 15, stealth: 20 }
      },
      {
        id: 'night_vision',
        name: 'Night Vision',
        namePt: 'Visão Noturna',
        description: 'Can see perfectly in darkness.',
        descriptionPt: 'Pode ver perfeitamente no escuro.',
        rarity: 'uncommon',
        statBonus: { agility: 5 },
        combatBonus: { accuracy: 10 }
      },
      {
        id: 'forest_whisper',
        name: 'Forest Whisper',
        namePt: 'Sussurro da Floresta',
        description: 'Can communicate with forest creatures.',
        descriptionPt: 'Pode se comunicar com criaturas da floresta.',
        rarity: 'legendary',
        statBonus: { beauty: 10, stamina: 10 },
        combatBonus: { charm: 25 }
      }
    ],
    
    seeds: [
      {
        id: 'cogumelo_lunar',
        name: 'Moon Mushroom',
        namePt: 'Cogumelo Lunar',
        icon: '🍄',
        growthTime: 150,
        nectarType: 'FlordaLua',
        nectarAmount: 5,
        cost: 40,
        rarity: 'rare'
      },
      {
        id: 'erva_sombria',
        name: 'Shadow Herb',
        namePt: 'Erva Sombria',
        icon: '🌿',
        growthTime: 120,
        nectarType: 'basic',
        nectarAmount: 6,
        cost: 30,
        rarity: 'uncommon'
      }
    ],
    
    enemies: [
      {
        id: 'shadow_spider',
        name: 'Shadow Spider',
        emoji: '🕷️',
        hp: 35,
        attack: 12,
        defense: 4,
        speed: 5,
        abilities: ['web_shot', 'poison_bite', 'ambush'],
        dropChance: 0.3
      },
      {
        id: 'dark_moth',
        name: 'Dark Moth',
        emoji: '🦋',
        hp: 28,
        attack: 10,
        defense: 3,
        speed: 6,
        abilities: ['dust_cloud', 'drain_life'],
        dropChance: 0.25
      },
      {
        id: 'forest_spirit',
        name: 'Forest Spirit',
        emoji: '👻',
        hp: 45,
        attack: 14,
        defense: 6,
        speed: 3,
        abilities: ['haunt', 'curse', 'phase'],
        dropChance: 0.35
      }
    ],
    
    boss: {
      id: 'spider_queen',
      name: 'Arachne the Weaver',
      namePt: 'Arachne a Tecelã',
      emoji: '🕷️👑',
      title: 'Queen of Webs',
      titlePt: 'Rainha das Teias',
      hp: 350,
      attack: 22,
      defense: 12,
      speed: 5,
      phases: [
        {
          hpPercent: 70,
          message: 'My children, come feast!',
          messagePt: 'Meus filhos, venham festejar!',
          attackBonus: 1.3,
          newAbility: 'spawn_spiderlings'
        },
        {
          hpPercent: 35,
          message: 'I will wrap you in eternal darkness!',
          messagePt: 'Eu irei envolvê-los em escuridão eterna!',
          attackBonus: 1.8,
          newAbility: 'cocoon_prison'
        }
      ],
      abilities: [
        {
          name: 'Venomous Fangs',
          namePt: 'Presas Venenosas',
          damage: 30,
          range: 2,
          cooldown: 2,
          effect: 'poison',
          description: 'Deadly venomous bite',
          descriptionPt: 'Mordida venenosa mortal'
        },
        {
          name: 'Web Prison',
          namePt: 'Prisão de Teia',
          damage: 15,
          range: 4,
          cooldown: 3,
          effect: 'stun',
          aoe: 2,
          description: 'Traps enemies in sticky web',
          descriptionPt: 'Prende inimigos em teia pegajosa'
        },
        {
          name: 'Shadow Step',
          namePt: 'Passo das Sombras',
          damage: 20,
          range: 6,
          cooldown: 4,
          description: 'Teleports behind prey',
          descriptionPt: 'Teleporta atrás da presa'
        }
      ],
      dialogue: {
        intro: 'Welcome to my parlor, little butterflies... You shall never leave!',
        introPt: 'Bem-vindos ao meu lar, pequenas borboletas... Vocês nunca sairão!',
        phase2: 'Struggle all you want! My web is unbreakable!',
        phase2Pt: 'Lutem o quanto quiserem! Minha teia é inquebrável!',
        death: 'My web... unravels... but darkness... remains...',
        deathPt: 'Minha teia... se desfaz... mas a escuridão... permanece...'
      },
      loot: {
        nectar: { min: 80, max: 150, type: 'FlordaLua' },
        seedChance: 0.7,
        butterflyChance: 0.4,
        exclusiveTraitChance: 0.4
      }
    },
    
    exclusiveColors: ['#2c2c2c', '#4a4a4a', '#6b4c9a', '#1a1a2e', '#483d8b'],
    exclusivePatterns: ['shadow_swirl', 'night_spots', 'web_pattern'],
    
    unlockRequirement: {
      type: 'boss',
      value: 'queen_bee',
      description: 'Defeat the Queen Bee',
      descriptionPt: 'Derrote a Abelha Rainha'
    }
  },

  caverna_cristalina: {
    id: 'caverna_cristalina',
    name: 'Crystal Cavern',
    namePt: 'Caverna Cristalina',
    desc: 'Sparkling caves filled with magical crystals.',
    descPt: 'Cavernas cintilantes cheias de cristais mágicos.',
    icon: '💎',
    iconImg: '/images/regions/crystal.png',
    
    duration: 90000,
    nectarCost: 40,
    dangerLevel: 3,
    deathChance: 0.12,
    butterflyChance: 0.2,
    seedChance: 0.25,
    
    floors: 5,
    roomsPerFloor: 7,
    
    backgroundColor: '#1a1a2e',
    ambientColor: '#4a4e69',
    particleEmoji: ['💎', '✨', '💠', '🔮', '⚡', '🌟'],
    
    tiles: [
      {
        id: 'cave_floor',
        name: 'Cave Floor',
        emoji: '🪨',
        color: '#37474f',
        walkable: true,
        spawnWeight: 40
      },
      {
        id: 'crystal_blue',
        name: 'Blue Crystal',
        emoji: '💎',
        color: '#00bcd4',
        walkable: true,
        effect: { type: 'buff', value: 3, message: 'Crystal energy empowers you!' },
        spawnWeight: 12
      },
      {
        id: 'crystal_purple',
        name: 'Purple Crystal',
        emoji: '🔮',
        color: '#9c27b0',
        walkable: true,
        effect: { type: 'heal', value: 15, message: 'Magical healing!' },
        spawnWeight: 8
      },
      {
        id: 'crystal_spike',
        name: 'Crystal Spike',
        emoji: '🗡️',
        color: '#b388ff',
        walkable: true,
        effect: { type: 'damage', value: 10, message: 'Sharp crystal cuts you!' },
        spawnWeight: 10
      },
      {
        id: 'stalagmite',
        name: 'Stalagmite',
        emoji: '🗿',
        color: '#455a64',
        walkable: false,
        spawnWeight: 15
      },
      {
        id: 'crystal_pool',
        name: 'Crystal Pool',
        emoji: '💠',
        color: '#4dd0e1',
        walkable: true,
        effect: { type: 'heal', value: 20, message: 'The pool restores your energy!' },
        spawnWeight: 5
      },
      {
        id: 'gem_deposit',
        name: 'Gem Deposit',
        emoji: '💰',
        color: '#ffd700',
        walkable: true,
        effect: { type: 'nectar', value: 5, message: '+5 Crystal nectar!' },
        spawnWeight: 3
      }
    ],
    
    exclusiveTraits: [
      {
        id: 'crystal_wings',
        name: 'Crystal Wings',
        namePt: 'Asas de Cristal',
        description: 'Wings made of pure crystal that reflect light.',
        descriptionPt: 'Asas feitas de cristal puro que refletem luz.',
        rarity: 'legendary',
        statBonus: { beauty: 25, stamina: 5 },
        combatBonus: { defense: 10, reflect: 15 }
      },
      {
        id: 'gem_sense',
        name: 'Gem Sense',
        namePt: 'Sentido de Gemas',
        description: 'Can detect valuable gems and treasures.',
        descriptionPt: 'Pode detectar gemas e tesouros valiosos.',
        rarity: 'rare',
        statBonus: { agility: 8 }
      },
      {
        id: 'resonance',
        name: 'Crystal Resonance',
        namePt: 'Ressonância Cristalina',
        description: 'Harmonizes with crystal energy.',
        descriptionPt: 'Harmoniza com energia cristalina.',
        rarity: 'uncommon',
        statBonus: { stamina: 10 },
        combatBonus: { magicPower: 15 }
      }
    ],
    
    seeds: [
      {
        id: 'flor_cristal',
        name: 'Crystal Flower',
        namePt: 'Flor de Cristal',
        icon: '💠',
        growthTime: 200,
        nectarType: 'Cristal',
        nectarAmount: 8,
        cost: 60,
        rarity: 'rare'
      },
      {
        id: 'musgo_brilhante',
        name: 'Glowing Moss',
        namePt: 'Musgo Brilhante',
        icon: '✨',
        growthTime: 100,
        nectarType: 'basic',
        nectarAmount: 4,
        cost: 25,
        rarity: 'uncommon'
      }
    ],
    
    enemies: [
      {
        id: 'crystal_golem',
        name: 'Crystal Golem',
        emoji: '🗿',
        hp: 60,
        attack: 18,
        defense: 15,
        speed: 2,
        abilities: ['crystal_smash', 'harden', 'reflect'],
        dropChance: 0.35
      },
      {
        id: 'gem_beetle',
        name: 'Gem Beetle',
        emoji: '🪲',
        hp: 35,
        attack: 14,
        defense: 10,
        speed: 4,
        abilities: ['gem_spit', 'burrow'],
        dropChance: 0.3
      },
      {
        id: 'cave_bat',
        name: 'Crystal Bat',
        emoji: '🦇',
        hp: 25,
        attack: 12,
        defense: 5,
        speed: 7,
        abilities: ['sonic_screech', 'drain'],
        dropChance: 0.25
      }
    ],
    
    boss: {
      id: 'crystal_guardian',
      name: 'Prismatic Guardian',
      namePt: 'Guardião Prismático',
      emoji: '💎🗿',
      title: 'Keeper of the Crystals',
      titlePt: 'Guardião dos Cristais',
      hp: 500,
      attack: 28,
      defense: 20,
      speed: 3,
      phases: [
        {
          hpPercent: 65,
          message: 'The crystals... they sing... of your destruction!',
          messagePt: 'Os cristais... eles cantam... sobre sua destruição!',
          attackBonus: 1.4,
          newAbility: 'crystal_rain'
        },
        {
          hpPercent: 30,
          message: 'I AM the mountain! I AM eternal!',
          messagePt: 'EU SOU a montanha! EU SOU eterno!',
          attackBonus: 2.0,
          newAbility: 'prismatic_explosion'
        }
      ],
      abilities: [
        {
          name: 'Crystal Slam',
          namePt: 'Pancada de Cristal',
          damage: 35,
          range: 2,
          cooldown: 2,
          aoe: 2,
          description: 'Massive crystal fist slam',
          descriptionPt: 'Pancada massiva com punho de cristal'
        },
        {
          name: 'Gem Barrage',
          namePt: 'Barragem de Gemas',
          damage: 20,
          range: 5,
          cooldown: 3,
          aoe: 3,
          description: 'Launches sharp gem projectiles',
          descriptionPt: 'Lança projéteis de gemas afiadas'
        },
        {
          name: 'Crystallize',
          namePt: 'Cristalizar',
          damage: 0,
          range: 4,
          cooldown: 5,
          effect: 'stun',
          aoe: 2,
          description: 'Encases enemies in crystal',
          descriptionPt: 'Encapsula inimigos em cristal'
        }
      ],
      dialogue: {
        intro: 'FOR MILLENNIA I HAVE GUARDED THESE HALLS. YOU SHALL NOT PASS!',
        introPt: 'POR MILÊNIOS EU GUARDEI ESTES SALÕES. VOCÊS NÃO PASSARÃO!',
        phase2: 'THE VERY STONES BEND TO MY WILL!',
        phase2Pt: 'AS PRÓPRIAS PEDRAS SE DOBRAM À MINHA VONTADE!',
        death: 'The crystals... will... remember...',
        deathPt: 'Os cristais... irão... lembrar...'
      },
      loot: {
        nectar: { min: 120, max: 200, type: 'Cristal' },
        seedChance: 0.6,
        butterflyChance: 0.35,
        exclusiveTraitChance: 0.5
      }
    },
    
    exclusiveColors: ['#00bcd4', '#9c27b0', '#e91e63', '#3f51b5', '#00e5ff'],
    exclusivePatterns: ['crystal_facets', 'gem_sparkle', 'prismatic_gradient'],
    
    unlockRequirement: {
      type: 'boss',
      value: 'spider_queen',
      description: 'Defeat Arachne the Weaver',
      descriptionPt: 'Derrote Arachne a Tecelã'
    }
  },

  pantano_misterioso: {
    id: 'pantano_misterioso',
    name: 'Mysterious Swamp',
    namePt: 'Pântano Misterioso',
    desc: 'A toxic swamp filled with strange creatures and poisonous plants.',
    descPt: 'Um pântano tóxico cheio de criaturas estranhas e plantas venenosas.',
    icon: '🐸',
    iconImg: '/images/regions/swamp.png',
    
    duration: 120000,
    nectarCost: 60,
    dangerLevel: 4,
    deathChance: 0.18,
    butterflyChance: 0.18,
    seedChance: 0.35,
    
    floors: 5,
    roomsPerFloor: 8,
    
    backgroundColor: '#1a3a1a',
    ambientColor: '#4a6a4a',
    particleEmoji: ['🐸', '🦎', '💀', '🌿', '💧', '🦟'],
    
    tiles: [
      {
        id: 'swamp_mud',
        name: 'Swamp Mud',
        emoji: '🟤',
        color: '#5d4037',
        walkable: true,
        effect: { type: 'debuff', value: 1, message: 'Mud slows you down!' },
        spawnWeight: 35
      },
      {
        id: 'toxic_water',
        name: 'Toxic Water',
        emoji: '💚',
        color: '#7cb342',
        walkable: true,
        effect: { type: 'damage', value: 8, message: 'Toxic water burns!' },
        spawnWeight: 20
      },
      {
        id: 'lily_pad',
        name: 'Lily Pad',
        emoji: '🌸',
        color: '#66bb6a',
        walkable: true,
        effect: { type: 'heal', value: 5, message: 'Safe on the lily pad!' },
        spawnWeight: 15
      },
      {
        id: 'dead_tree',
        name: 'Dead Tree',
        emoji: '🌳',
        color: '#3e2723',
        walkable: false,
        spawnWeight: 10
      },
      {
        id: 'poison_mushroom',
        name: 'Poison Mushroom',
        emoji: '🍄',
        color: '#7b1fa2',
        walkable: true,
        effect: { type: 'damage', value: 15, message: 'Poisonous spores!' },
        spawnWeight: 8
      },
      {
        id: 'healing_moss',
        name: 'Healing Moss',
        emoji: '🌿',
        color: '#4caf50',
        walkable: true,
        effect: { type: 'heal', value: 12, message: 'Medicinal moss heals you!' },
        spawnWeight: 7
      },
      {
        id: 'quicksand',
        name: 'Quicksand',
        emoji: '⚠️',
        color: '#795548',
        walkable: true,
        effect: { type: 'trap', value: 2, message: 'Stuck in quicksand!' },
        spawnWeight: 5
      }
    ],
    
    exclusiveTraits: [
      {
        id: 'poison_immunity',
        name: 'Poison Immunity',
        namePt: 'Imunidade a Veneno',
        description: 'Completely immune to poison effects.',
        descriptionPt: 'Completamente imune a efeitos de veneno.',
        rarity: 'rare',
        statBonus: { stamina: 15 },
        combatBonus: { poisonImmune: 100 }
      },
      {
        id: 'toxic_wings',
        name: 'Toxic Wings',
        namePt: 'Asas Tóxicas',
        description: 'Wings coated in natural toxins.',
        descriptionPt: 'Asas cobertas com toxinas naturais.',
        rarity: 'legendary',
        statBonus: { beauty: -5, stamina: 20 },
        combatBonus: { poisonDamage: 25, counterPoison: 15 }
      },
      {
        id: 'swamp_camouflage',
        name: 'Swamp Camouflage',
        namePt: 'Camuflagem do Pântano',
        description: 'Blends perfectly with swamp environment.',
        descriptionPt: 'Se mistura perfeitamente com o ambiente do pântano.',
        rarity: 'uncommon',
        statBonus: { agility: 10 },
        combatBonus: { dodge: 20 }
      }
    ],
    
    seeds: [
      {
        id: 'lirio_venenoso',
        name: 'Poison Lily',
        namePt: 'Lírio Venenoso',
        icon: '☠️',
        growthTime: 180,
        nectarType: 'Veneno',
        nectarAmount: 6,
        cost: 50,
        rarity: 'rare'
      },
      {
        id: 'erva_pantano',
        name: 'Swamp Herb',
        namePt: 'Erva do Pântano',
        icon: '🌿',
        growthTime: 90,
        nectarType: 'basic',
        nectarAmount: 5,
        cost: 30,
        rarity: 'uncommon'
      },
      {
        id: 'flor_sapo',
        name: 'Frog Flower',
        namePt: 'Flor de Sapo',
        icon: '🐸',
        growthTime: 120,
        nectarType: 'Sapo',
        nectarAmount: 4,
        cost: 35,
        rarity: 'uncommon'
      }
    ],
    
    enemies: [
      {
        id: 'poison_frog',
        name: 'Poison Dart Frog',
        emoji: '🐸',
        hp: 30,
        attack: 20,
        defense: 5,
        speed: 6,
        abilities: ['poison_spit', 'tongue_lash', 'toxic_hop'],
        dropChance: 0.3
      },
      {
        id: 'swamp_snake',
        name: 'Swamp Serpent',
        emoji: '🐍',
        hp: 45,
        attack: 22,
        defense: 8,
        speed: 5,
        abilities: ['constrict', 'venom_bite', 'ambush'],
        dropChance: 0.35
      },
      {
        id: 'bog_monster',
        name: 'Bog Monster',
        emoji: '👹',
        hp: 70,
        attack: 18,
        defense: 12,
        speed: 2,
        abilities: ['mud_throw', 'swallow', 'regenerate'],
        dropChance: 0.4
      }
    ],
    
    boss: {
      id: 'swamp_witch',
      name: 'Murkmire the Swamp Witch',
      namePt: 'Murkmire a Bruxa do Pântano',
      emoji: '🧙‍♀️🐸',
      title: 'Mistress of Poisons',
      titlePt: 'Mestra dos Venenos',
      hp: 450,
      attack: 32,
      defense: 15,
      speed: 4,
      phases: [
        {
          hpPercent: 60,
          message: 'Bubble, bubble, toil and trouble!',
          messagePt: 'Borbulha, borbulha, trabalho e confusão!',
          attackBonus: 1.5,
          newAbility: 'summon_familiars'
        },
        {
          hpPercent: 25,
          message: 'YOU WILL JOIN MY COLLECTION OF SPECIMENS!',
          messagePt: 'VOCÊS SE JUNTARÃO À MINHA COLEÇÃO DE ESPÉCIMES!',
          attackBonus: 2.2,
          newAbility: 'toxic_transformation'
        }
      ],
      abilities: [
        {
          name: 'Poison Brew',
          namePt: 'Poção Venenosa',
          damage: 25,
          range: 4,
          cooldown: 2,
          effect: 'poison',
          aoe: 2,
          description: 'Throws a bottle of toxic brew',
          descriptionPt: 'Lança uma garrafa de poção tóxica'
        },
        {
          name: 'Frog Curse',
          namePt: 'Maldição do Sapo',
          damage: 15,
          range: 5,
          cooldown: 4,
          effect: 'curse',
          description: 'Curses enemy, reducing all stats',
          descriptionPt: 'Amaldiçoa inimigo, reduzindo todos os atributos'
        },
        {
          name: 'Summon Familiars',
          namePt: 'Invocar Familiares',
          damage: 0,
          range: 6,
          cooldown: 5,
          description: 'Summons poison frogs to fight',
          descriptionPt: 'Invoca sapos venenosos para lutar'
        }
      ],
      dialogue: {
        intro: 'Ohohoho! More ingredients for my cauldron! How delightful!',
        introPt: 'Ohohoho! Mais ingredientes para meu caldeirão! Que delícia!',
        phase2: 'Now you see my TRUE POWER! CROOOOAK!',
        phase2Pt: 'Agora vocês verão meu VERDADEIRO PODER! CROOOOAK!',
        death: 'My potions... my precious potions... *ribbit*',
        deathPt: 'Minhas poções... minhas preciosas poções... *coaxar*'
      },
      loot: {
        nectar: { min: 150, max: 250, type: 'Veneno' },
        seedChance: 0.75,
        butterflyChance: 0.3,
        exclusiveTraitChance: 0.55
      }
    },
    
    exclusiveColors: ['#7cb342', '#558b2f', '#33691e', '#827717', '#9e9d24'],
    exclusivePatterns: ['toxic_spots', 'swamp_camo', 'poison_gradient'],
    
    unlockRequirement: {
      type: 'boss',
      value: 'crystal_guardian',
      description: 'Defeat the Prismatic Guardian',
      descriptionPt: 'Derrote o Guardião Prismático'
    }
  },

  vulcao_ardente: {
    id: 'vulcao_ardente',
    name: 'Burning Volcano',
    namePt: 'Vulcão Ardente',
    desc: 'A dangerous volcanic region with rivers of lava.',
    descPt: 'Uma região vulcânica perigosa com rios de lava.',
    icon: '🌋',
    iconImg: '/images/regions/volcano.png',
    
    duration: 150000,
    nectarCost: 80,
    dangerLevel: 5,
    deathChance: 0.25,
    butterflyChance: 0.15,
    seedChance: 0.2,
    
    floors: 6,
    roomsPerFloor: 8,
    
    backgroundColor: '#2a0a0a',
    ambientColor: '#4a1a1a',
    particleEmoji: ['🔥', '🌋', '💨', '✨', '☄️', '💀'],
    
    tiles: [
      {
        id: 'volcanic_rock',
        name: 'Volcanic Rock',
        emoji: '🪨',
        color: '#424242',
        walkable: true,
        spawnWeight: 35
      },
      {
        id: 'lava',
        name: 'Lava',
        emoji: '🔥',
        color: '#ff5722',
        walkable: true,
        effect: { type: 'damage', value: 25, message: 'BURNING in lava!' },
        spawnWeight: 20
      },
      {
        id: 'cooled_lava',
        name: 'Cooled Lava',
        emoji: '⬛',
        color: '#212121',
        walkable: true,
        spawnWeight: 15
      },
      {
        id: 'fire_vent',
        name: 'Fire Vent',
        emoji: '💨',
        color: '#ff9800',
        walkable: true,
        effect: { type: 'damage', value: 15, message: 'Hot steam burns!' },
        spawnWeight: 10
      },
      {
        id: 'obsidian',
        name: 'Obsidian',
        emoji: '🖤',
        color: '#1a1a1a',
        walkable: false,
        spawnWeight: 10
      },
      {
        id: 'fire_flower',
        name: 'Fire Flower',
        emoji: '🌺',
        color: '#ff4081',
        walkable: true,
        effect: { type: 'buff', value: 5, message: 'Fire energy empowers you!' },
        spawnWeight: 5
      },
      {
        id: 'ash_pile',
        name: 'Ash Pile',
        emoji: '⚫',
        color: '#616161',
        walkable: true,
        effect: { type: 'nectar', value: 3, message: '+3 Fire nectar!' },
        spawnWeight: 5
      }
    ],
    
    exclusiveTraits: [
      {
        id: 'flame_wings',
        name: 'Flame Wings',
        namePt: 'Asas de Chama',
        description: 'Wings made of living fire.',
        descriptionPt: 'Asas feitas de fogo vivo.',
        rarity: 'legendary',
        statBonus: { beauty: 20, stamina: -5 },
        combatBonus: { fireDamage: 30, burnImmune: 100 }
      },
      {
        id: 'heat_resistance',
        name: 'Heat Resistance',
        namePt: 'Resistência ao Calor',
        description: 'Can withstand extreme temperatures.',
        descriptionPt: 'Pode suportar temperaturas extremas.',
        rarity: 'rare',
        statBonus: { stamina: 20 },
        combatBonus: { fireResist: 50 }
      },
      {
        id: 'phoenix_blood',
        name: 'Phoenix Blood',
        namePt: 'Sangue de Fênix',
        description: 'Can revive once per battle.',
        descriptionPt: 'Pode reviver uma vez por batalha.',
        rarity: 'legendary',
        statBonus: { stamina: 10, agility: 5 },
        combatBonus: { revive: 1 }
      }
    ],
    
    seeds: [
      {
        id: 'flor_fogo',
        name: 'Fire Blossom',
        namePt: 'Flor de Fogo',
        icon: '🔥',
        growthTime: 250,
        nectarType: 'Fogo',
        nectarAmount: 10,
        cost: 80,
        rarity: 'rare'
      },
      {
        id: 'cinza_viva',
        name: 'Living Ash',
        namePt: 'Cinza Viva',
        icon: '⚫',
        growthTime: 150,
        nectarType: 'basic',
        nectarAmount: 7,
        cost: 45,
        rarity: 'uncommon'
      }
    ],
    
    enemies: [
      {
        id: 'fire_elemental',
        name: 'Fire Elemental',
        emoji: '🔥',
        hp: 50,
        attack: 28,
        defense: 10,
        speed: 5,
        abilities: ['fireball', 'flame_aura', 'eruption'],
        dropChance: 0.35
      },
      {
        id: 'lava_slug',
        name: 'Lava Slug',
        emoji: '🐌',
        hp: 80,
        attack: 20,
        defense: 18,
        speed: 1,
        abilities: ['lava_trail', 'melt', 'harden'],
        dropChance: 0.3
      },
      {
        id: 'ash_phoenix',
        name: 'Ash Phoenix',
        emoji: '🐦‍🔥',
        hp: 40,
        attack: 25,
        defense: 8,
        speed: 7,
        abilities: ['phoenix_dive', 'rebirth', 'fire_breath'],
        dropChance: 0.4
      }
    ],
    
    boss: {
      id: 'volcano_lord',
      name: 'Ignius the Volcano Lord',
      namePt: 'Ignius o Senhor do Vulcão',
      emoji: '🌋👑',
      title: 'Master of Flames',
      titlePt: 'Mestre das Chamas',
      hp: 600,
      attack: 40,
      defense: 22,
      speed: 4,
      phases: [
        {
          hpPercent: 70,
          message: 'FEEL THE HEAT OF A THOUSAND SUNS!',
          messagePt: 'SINTAM O CALOR DE MIL SÓIS!',
          attackBonus: 1.5,
          newAbility: 'magma_eruption'
        },
        {
          hpPercent: 35,
          message: 'THIS MOUNTAIN IS MY BODY! I AM ETERNAL!',
          messagePt: 'ESTA MONTANHA É MEU CORPO! EU SOU ETERNO!',
          attackBonus: 2.5,
          newAbility: 'volcanic_apocalypse'
        }
      ],
      abilities: [
        {
          name: 'Magma Blast',
          namePt: 'Explosão de Magma',
          damage: 45,
          range: 3,
          cooldown: 2,
          effect: 'burn',
          aoe: 2,
          description: 'Blasts enemies with molten rock',
          descriptionPt: 'Explode inimigos com rocha derretida'
        },
        {
          name: 'Lava Wave',
          namePt: 'Onda de Lava',
          damage: 35,
          range: 5,
          cooldown: 4,
          effect: 'burn',
          aoe: 4,
          description: 'Sends a wave of lava across the field',
          descriptionPt: 'Envia uma onda de lava pelo campo'
        },
        {
          name: 'Volcanic Rage',
          namePt: 'Fúria Vulcânica',
          damage: 0,
          range: 0,
          cooldown: 6,
          description: 'Doubles attack for 3 turns',
          descriptionPt: 'Dobra o ataque por 3 turnos'
        }
      ],
      dialogue: {
        intro: 'MORTALS DARE ENTER MY DOMAIN?! YOU WILL BE REDUCED TO ASH!',
        introPt: 'MORTAIS OUSAM ENTRAR NO MEU DOMÍNIO?! VOCÊS SERÃO REDUZIDOS A CINZAS!',
        phase2: 'NOW WITNESS THE FULL FURY OF THE VOLCANO!',
        phase2Pt: 'AGORA TESTEMUNHEM A FÚRIA TOTAL DO VULCÃO!',
        death: 'The mountain... sleeps... but will... awaken...',
        deathPt: 'A montanha... dorme... mas irá... despertar...'
      },
      loot: {
        nectar: { min: 200, max: 350, type: 'Fogo' },
        seedChance: 0.5,
        butterflyChance: 0.25,
        exclusiveTraitChance: 0.6
      }
    },
    
    exclusiveColors: ['#ff5722', '#ff9800', '#ffc107', '#f44336', '#e91e63'],
    exclusivePatterns: ['flame_pattern', 'ember_spots', 'lava_flow'],
    
    unlockRequirement: {
      type: 'boss',
      value: 'swamp_witch',
      description: 'Defeat Murkmire the Swamp Witch',
      descriptionPt: 'Derrote Murkmire a Bruxa do Pântano'
    }
  },

  templo_celestial: {
    id: 'templo_celestial',
    name: 'Celestial Temple',
    namePt: 'Templo Celestial',
    desc: 'An ancient temple floating among the clouds, home to divine butterflies.',
    descPt: 'Um templo antigo flutuando entre as nuvens, lar das borboletas divinas.',
    icon: '🏛️',
    iconImg: '/images/regions/temple.png',
    
    duration: 200000,
    nectarCost: 120,
    dangerLevel: 6,
    deathChance: 0.3,
    butterflyChance: 0.12,
    seedChance: 0.15,
    
    floors: 7,
    roomsPerFloor: 10,
    
    backgroundColor: '#e8f4f8',
    ambientColor: '#b3e5fc',
    particleEmoji: ['✨', '⭐', '🌟', '💫', '☁️', '🦋'],
    
    tiles: [
      {
        id: 'cloud',
        name: 'Cloud',
        emoji: '☁️',
        color: '#e3f2fd',
        walkable: true,
        spawnWeight: 35
      },
      {
        id: 'marble',
        name: 'Marble Floor',
        emoji: '⬜',
        color: '#fafafa',
        walkable: true,
        spawnWeight: 25
      },
      {
        id: 'starlight',
        name: 'Starlight',
        emoji: '⭐',
        color: '#fff9c4',
        walkable: true,
        effect: { type: 'buff', value: 5, message: 'Blessed by starlight!' },
        spawnWeight: 10
      },
      {
        id: 'divine_pool',
        name: 'Divine Pool',
        emoji: '💠',
        color: '#80deea',
        walkable: true,
        effect: { type: 'heal', value: 30, message: 'Divine healing!' },
        spawnWeight: 5
      },
      {
        id: 'pillar',
        name: 'Temple Pillar',
        emoji: '🏛️',
        color: '#d7ccc8',
        walkable: false,
        spawnWeight: 10
      },
      {
        id: 'void',
        name: 'Void',
        emoji: '🕳️',
        color: '#1a1a2e',
        walkable: true,
        effect: { type: 'damage', value: 50, message: 'Falling into the void!' },
        spawnWeight: 8
      },
      {
        id: 'celestial_flower',
        name: 'Celestial Flower',
        emoji: '🌸',
        color: '#f8bbd9',
        walkable: true,
        effect: { type: 'nectar', value: 10, message: '+10 Celestial nectar!' },
        spawnWeight: 2
      }
    ],
    
    exclusiveTraits: [
      {
        id: 'divine_wings',
        name: 'Divine Wings',
        namePt: 'Asas Divinas',
        description: 'Wings blessed by the celestial gods.',
        descriptionPt: 'Asas abençoadas pelos deuses celestiais.',
        rarity: 'legendary',
        statBonus: { beauty: 30, stamina: 15, agility: 10 },
        combatBonus: { allStats: 10, holyDamage: 25 }
      },
      {
        id: 'celestial_blessing',
        name: 'Celestial Blessing',
        namePt: 'Bênção Celestial',
        description: 'Permanently blessed by divine light.',
        descriptionPt: 'Permanentemente abençoado pela luz divina.',
        rarity: 'legendary',
        statBonus: { fertility: 0.2, beauty: 20 },
        combatBonus: { healingReceived: 50, regeneration: 5 }
      },
      {
        id: 'starborn',
        name: 'Starborn',
        namePt: 'Nascido das Estrelas',
        description: 'Born from starlight itself.',
        descriptionPt: 'Nascido da própria luz das estrelas.',
        rarity: 'legendary',
        statBonus: { beauty: 25, agility: 15, stamina: 10 },
        combatBonus: { critChance: 20, critDamage: 50 }
      }
    ],
    
    seeds: [
      {
        id: 'flor_celestial',
        name: 'Celestial Bloom',
        namePt: 'Flor Celestial',
        icon: '✨',
        growthTime: 300,
        nectarType: 'Celestial',
        nectarAmount: 15,
        cost: 150,
        rarity: 'rare'
      },
      {
        id: 'orvalho_estrelar',
        name: 'Star Dew',
        namePt: 'Orvalho Estrelar',
        icon: '⭐',
        growthTime: 200,
        nectarType: 'basic',
        nectarAmount: 10,
        cost: 80,
        rarity: 'rare'
      }
    ],
    
    enemies: [
      {
        id: 'celestial_guardian',
        name: 'Celestial Guardian',
        emoji: '👼',
        hp: 80,
        attack: 30,
        defense: 20,
        speed: 5,
        abilities: ['holy_smite', 'divine_shield', 'judgment'],
        dropChance: 0.4
      },
      {
        id: 'star_sprite',
        name: 'Star Sprite',
        emoji: '⭐',
        hp: 40,
        attack: 35,
        defense: 10,
        speed: 8,
        abilities: ['star_bolt', 'blink', 'nova'],
        dropChance: 0.35
      },
      {
        id: 'cloud_serpent',
        name: 'Cloud Serpent',
        emoji: '🐉',
        hp: 100,
        attack: 35,
        defense: 25,
        speed: 4,
        abilities: ['lightning_breath', 'coil', 'storm_call'],
        dropChance: 0.45
      }
    ],
    
    boss: {
      id: 'moth_emperor',
      name: 'Lunaris the Moth Emperor',
      namePt: 'Lunaris o Imperador Mariposa',
      emoji: '🦋👑✨',
      title: 'Divine Ruler of All Butterflies',
      titlePt: 'Governante Divino de Todas as Borboletas',
      hp: 800,
      attack: 50,
      defense: 30,
      speed: 6,
      phases: [
        {
          hpPercent: 75,
          message: 'You have come far, little ones. But this is where your journey ends.',
          messagePt: 'Vocês vieram de longe, pequenos. Mas é aqui que sua jornada termina.',
          attackBonus: 1.3,
          newAbility: 'celestial_judgment'
        },
        {
          hpPercent: 50,
          message: 'Impressive... you force me to reveal my true form!',
          messagePt: 'Impressionante... vocês me forçam a revelar minha verdadeira forma!',
          attackBonus: 1.8,
          newAbility: 'divine_transformation'
        },
        {
          hpPercent: 25,
          message: 'WITNESS THE POWER OF THE CELESTIAL THRONE!',
          messagePt: 'TESTEMUNHEM O PODER DO TRONO CELESTIAL!',
          attackBonus: 3.0,
          newAbility: 'ultimate_nova'
        }
      ],
      abilities: [
        {
          name: 'Divine Light',
          namePt: 'Luz Divina',
          damage: 50,
          range: 5,
          cooldown: 2,
          effect: 'bless',
          aoe: 3,
          description: 'Blinding divine light that damages and blesses',
          descriptionPt: 'Luz divina cegante que causa dano e abençoa'
        },
        {
          name: 'Star Storm',
          namePt: 'Tempestade de Estrelas',
          damage: 35,
          range: 8,
          cooldown: 4,
          aoe: 5,
          description: 'Rains stars down on all enemies',
          descriptionPt: 'Chove estrelas sobre todos os inimigos'
        },
        {
          name: 'Lunar Eclipse',
          namePt: 'Eclipse Lunar',
          damage: 0,
          range: 10,
          cooldown: 6,
          effect: 'curse',
          description: 'Covers field in darkness, cursing all',
          descriptionPt: 'Cobre o campo em escuridão, amaldiçoando todos'
        },
        {
          name: 'Rebirth',
          namePt: 'Renascimento',
          damage: -100,
          range: 0,
          cooldown: 10,
          description: 'Heals self for 100 HP',
          descriptionPt: 'Cura a si mesmo em 100 HP'
        }
      ],
      dialogue: {
        intro: 'So, you have ascended to my realm... Few mortals have ever reached the Celestial Temple. Prove yourselves worthy!',
        introPt: 'Então, vocês ascenderam ao meu reino... Poucos mortais já alcançaram o Templo Celestial. Provem ser dignos!',
        phase2: 'You fight with courage! But I have ruled for a thousand years! THIS WILL NOT END HERE!',
        phase2Pt: 'Vocês lutam com coragem! Mas eu governei por mil anos! ISTO NÃO VAI TERMINAR AQUI!',
        death: 'At last... worthy successors... The celestial realm... is yours now... Rule it... with wisdom...',
        deathPt: 'Finalmente... sucessores dignos... O reino celestial... é de vocês agora... Governem-no... com sabedoria...'
      },
      loot: {
        nectar: { min: 300, max: 500, type: 'Celestial' },
        seedChance: 0.9,
        butterflyChance: 0.6,
        exclusiveTraitChance: 0.8
      }
    },
    
    exclusiveColors: ['#ffffff', '#e1f5fe', '#b3e5fc', '#fce4ec', '#f3e5f5'],
    exclusivePatterns: ['divine_glow', 'star_pattern', 'celestial_gradient', 'holy_wings'],
    
    unlockRequirement: {
      type: 'boss',
      value: 'volcano_lord',
      description: 'Defeat Ignius the Volcano Lord',
      descriptionPt: 'Derrote Ignius o Senhor do Vulcão'
    }
  }
};

// ════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ════════════════════════════════════════════════════════════════

export function getRegionById(id: string): Region | undefined {
  return REGIONS[id];
}

export function getUnlockedRegions(defeatedBosses: string[]): Region[] {
  return Object.values(REGIONS).filter(r => {
    if (!r.unlockRequirement) return true;
    if (r.unlockRequirement.type === 'boss') {
      return defeatedBosses.includes(r.unlockRequirement.value as string);
    }
    return true;
  });
}

export function generateRegionTileGrid(region: Region, width: number = 10, height: number = 10): RegionTile[][] {
  const grid: RegionTile[][] = [];
  const totalWeight = region.tiles.reduce((sum, t) => sum + t.spawnWeight, 0);
  
  for (let y = 0; y < height; y++) {
    const row: RegionTile[] = [];
    for (let x = 0; x < width; x++) {
      // Weighted random selection
      let random = Math.random() * totalWeight;
      let selectedTile = region.tiles[0];
      
      for (const tile of region.tiles) {
        random -= tile.spawnWeight;
        if (random <= 0) {
          selectedTile = tile;
          break;
        }
      }
      
      row.push({ ...selectedTile });
    }
    grid.push(row);
  }
  
  // Ensure walkable paths exist
  ensureWalkablePath(grid, region.tiles);
  
  return grid;
}

function ensureWalkablePath(grid: RegionTile[][], tiles: RegionTile[]): void {
  const walkableTile = tiles.find(t => t.walkable && !t.effect) || tiles.find(t => t.walkable)!;
  
  // Create a path from top-left to bottom-right
  const height = grid.length;
  const width = grid[0].length;
  
  let x = 0, y = 0;
  while (x < width - 1 || y < height - 1) {
    grid[y][x] = { ...walkableTile };
    
    if (x < width - 1 && y < height - 1) {
      if (Math.random() < 0.5) x++;
      else y++;
    } else if (x < width - 1) {
      x++;
    } else {
      y++;
    }
  }
  grid[height - 1][width - 1] = { ...walkableTile };
}

// Export for vanilla JS compatibility
if (typeof window !== 'undefined') {
  (window as any).REGIONS_CONFIG = REGIONS;
  (window as any).getRegionById = getRegionById;
  (window as any).getUnlockedRegions = getUnlockedRegions;
  (window as any).generateRegionTileGrid = generateRegionTileGrid;
}
