// ════════════════════════════════════════════════════════════════
// CONFIG TYPES - Type definitions for all configuration
// ════════════════════════════════════════════════════════════════

// Boss ability configuration
export interface BossAbility {
  name: string;
  description: string;
  damage: number;
  healing?: number;
  type: 'attack' | 'heal' | 'buff' | 'debuff' | 'summon' | 'control' | 'area_denial' | 'passive' | 'ultimate';
  cooldown: number;
  effect?: string;
  effectDuration?: number;
  targetType: 'single' | 'area' | 'all_enemies' | 'all' | 'self' | 'self_and_allies' | 'cone' | 'line' | 'none';
  areaSize?: number;
  coneAngle?: number;
  range?: number;
  summonCount?: number;
  summonType?: string;
  knockbackDistance?: number;
  uses?: number;
  bonuses?: {
    evasion?: number;
    attackBonus?: number;
    defenseBonus?: number;
  };
}

// Boss phase configuration
export interface BossPhase {
  hpPercent: number;
  behavior: string;
  message: string;
  attackBonus?: number;
  defenseBonus?: number;
  speedBonus?: number;
  magicBonus?: number;
  trigger?: string;
}

// Boss loot configuration
export interface BossLoot {
  gold: { min: number; max: number };
  nectar: { min: number; max: number };
  guaranteedItems: string[];
  possibleButterfly?: {
    chance: number;
    traits: string[];
  };
  seeds: { type: string; chance: number }[];
}

// Boss dialogue configuration
export interface BossDialogue {
  intro: string;
  phase2?: string;
  phase3?: string;
  phase4?: string;
  defeat: string;
  victory: string;
}

// Full boss configuration
export interface BossConfig {
  id: string;
  name: string;
  emoji: string;
  description: string;
  region: string;
  
  baseHp: number;
  hpPerFloor: number;
  attack: number;
  defense: number;
  speed: number;
  
  color: string;
  size: 'small' | 'medium' | 'large' | 'huge';
  
  abilities: BossAbility[];
  phases: BossPhase[];
  loot: BossLoot;
  dialogue: BossDialogue;
}

// Enemy configuration
export interface EnemyConfig {
  id: string;
  name: string;
  emoji: string;
  description: string;
  regions: string[]; // Which regions this enemy appears in
  
  baseHp: number;
  hpPerFloor: number;
  attack: number;
  defense: number;
  speed: number;
  
  color: string;
  isElite?: boolean;
  
  abilities: {
    name: string;
    damage: number;
    effect?: string;
    effectDuration?: number;
    cooldown: number;
  }[];
  
  loot: {
    gold: { min: number; max: number };
    nectar?: { min: number; max: number };
    itemChance?: number;
    items?: string[];
  };
  
  behavior: 'aggressive' | 'defensive' | 'ranged' | 'support' | 'random';
}

// Tile configuration for regions
export interface TileConfig {
  id: string;
  name: string;
  emoji: string;
  color: string;
  walkable: boolean;
  effect?: {
    type: 'damage' | 'heal' | 'buff' | 'debuff' | 'teleport' | 'spawn';
    value?: number;
    duration?: number;
    message?: string;
  };
  spawnChance: number; // 0-1, chance this tile appears
}

// Region configuration
export interface RegionConfig {
  id: string;
  name: string;
  description: string;
  icon: string;
  iconImg?: string;
  
  // Visual theme
  theme: {
    backgroundColor: string;
    gridColor: string;
    accentColor: string;
    ambientParticles?: string[];
  };
  
  // Tiles specific to this region
  tiles: TileConfig[];
  
  // Enemies that appear here
  enemyPool: string[];
  elitePool: string[];
  bossId: string;
  
  // Difficulty
  dangerLevel: number;
  minFloors: number;
  maxFloors: number;
  
  // Requirements to unlock
  unlockRequirement?: {
    type: 'defeat_boss' | 'butterfly_count' | 'generation' | 'none';
    value?: string | number;
  };
  
  // Rewards
  nectarMultiplier: number;
  goldMultiplier: number;
  
  // Exclusive content
  exclusiveTraits: string[];
  exclusiveSeeds: string[];
  exclusiveButterflies: {
    chance: number;
    traits: string[];
    colorPool: string[];
  };
  
  // Events
  mysteryEvents: string[];
}

// Plant/Seed configuration
export interface PlantConfig {
  id: string;
  name: string;
  emoji: string;
  description: string;
  
  growthTime: number; // in game ticks
  stages: string[]; // emojis for each growth stage
  
  harvestYield: {
    nectar?: { min: number; max: number };
    items?: { id: string; chance: number }[];
    seeds?: { type: string; chance: number }[];
  };
  
  region: string; // Which region this seed comes from
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  
  // Special effects when butterfly interacts
  butterflyEffects?: {
    type: 'buff' | 'heal' | 'exp' | 'trait';
    value: number | string;
  };
}

// Item configuration
export interface ItemConfig {
  id: string;
  name: string;
  emoji: string;
  description: string;
  
  type: 'consumable' | 'equipment' | 'material' | 'key' | 'special';
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  
  // For consumables
  effect?: {
    type: 'heal' | 'buff' | 'revive' | 'damage' | 'cleanse';
    value: number;
    duration?: number;
    target: 'self' | 'ally' | 'enemy' | 'all_allies' | 'all_enemies';
  };
  
  // For equipment
  stats?: {
    hp?: number;
    attack?: number;
    defense?: number;
    speed?: number;
    critChance?: number;
    critDamage?: number;
  };
  
  // Sell value
  sellValue: number;
  
  // Stack
  stackable: boolean;
  maxStack?: number;
  
  // Source
  sources: string[]; // Where this item can be found
}

// Class ability configuration
export interface ClassAbilityConfig {
  id: string;
  name: string;
  description: string;
  
  type: 'damage' | 'heal' | 'buff' | 'debuff' | 'summon' | 'utility';
  targetType: 'self' | 'single_ally' | 'single_enemy' | 'all_allies' | 'all_enemies' | 'area';
  
  baseDamage?: number;
  baseHealing?: number;
  
  range: number;
  areaSize?: number;
  
  cooldown: number;
  manaCost?: number;
  
  effects?: {
    type: string;
    duration: number;
    value?: number;
  }[];
  
  scaling?: {
    stat: 'attack' | 'magic' | 'level';
    ratio: number;
  };
}

// Butterfly class configuration
export interface ButterflyClassConfig {
  id: string;
  name: string;
  emoji: string;
  description: string;
  
  // Base stats
  baseStats: {
    hp: number;
    attack: number;
    defense: number;
    magic: number;
    speed: number;
    range: number;
  };
  
  // Stat growth per level
  statGrowth: {
    hp: number;
    attack: number;
    defense: number;
    magic: number;
    speed: number;
  };
  
  // Abilities
  abilities: ClassAbilityConfig[];
  
  // Passive
  passive?: {
    name: string;
    description: string;
    effect: string;
    value: number;
  };
  
  // Visual
  color: string;
  
  // Playstyle hints
  role: 'tank' | 'damage' | 'healer' | 'support' | 'control';
  difficulty: 'easy' | 'medium' | 'hard';
}

// Mystery event configuration
export interface MysteryEventConfig {
  id: string;
  title: string;
  description: string;
  region?: string; // If region-specific
  
  choices: {
    text: string;
    outcomes: {
      chance: number;
      type: 'reward' | 'penalty' | 'neutral' | 'butterfly' | 'combat';
      message: string;
      effects: {
        type: string;
        value: number | string;
      }[];
    }[];
    requirements?: {
      type: 'item' | 'butterfly_trait' | 'class';
      value: string;
    };
  }[];
  
  requirements?: {
    type: 'item' | 'butterfly_trait' | 'class';
    value: string;
  };
}
