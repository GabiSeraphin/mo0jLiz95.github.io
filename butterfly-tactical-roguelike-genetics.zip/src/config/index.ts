// ════════════════════════════════════════════════════════════════
// CONFIG INDEX - Import all configs from here
// ════════════════════════════════════════════════════════════════

// Types
export * from './types.config';

// Configurations
export * from './bosses.config';
export * from './enemies.config';
export * from './regions.config';
export * from './plants.config';
export * from './events.config';

// Re-export commonly used items
export { BOSSES_CONFIG, getBossForRegion, getAllBosses } from './bosses.config';
export { ENEMIES_CONFIG, getEnemy, getEnemiesForRegion, getElitesForRegion } from './enemies.config';
export { REGIONS, getRegionById, getUnlockedRegions, generateRegionTileGrid } from './regions.config';
export { PLANTS_CONFIG, getPlant, getPlantsForRegion } from './plants.config';
export { EVENTS_CONFIG, getEvent, getEventsForRegion, getRandomEventForRegion } from './events.config';
