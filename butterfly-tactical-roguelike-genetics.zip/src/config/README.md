# 🦋 Chrysalis Tactics - Configuration Guide

## 📁 File Structure

```
src/config/
├── README.md           # This file
├── index.ts            # Re-exports all configs
├── types.config.ts     # TypeScript types for configs
├── bosses.config.ts    # Boss definitions
├── enemies.config.ts   # Enemy definitions
├── regions.config.ts   # Region & tile definitions
├── plants.config.ts    # Plant/seed definitions
├── events.config.ts    # Mystery event definitions
```

---

## 🎯 How to Add/Edit Bosses

Open `bosses.config.ts` and add a new boss:

```typescript
my_new_boss: {
  id: 'my_new_boss',
  name: 'Nome do Boss',
  emoji: '🐲',
  description: 'Description of the boss',
  region: 'region_key',  // Which region this boss appears in
  
  // Stats
  baseHp: 200,
  hpPerFloor: 30,
  attack: 25,
  defense: 15,
  speed: 5,
  
  // Visual
  color: '#FF0000',
  size: 'huge',  // small, medium, large, huge
  
  // Abilities - the boss's attacks
  abilities: [
    {
      name: 'Attack Name',
      description: 'What it does',
      damage: 30,
      type: 'attack',  // attack, heal, buff, debuff, summon
      cooldown: 2,
      effect: 'burn',  // poison, burn, freeze, stun, etc.
      effectDuration: 3,
      targetType: 'single'  // single, area, all_enemies, self
    }
  ],
  
  // Phases - boss behavior changes at HP thresholds
  phases: [
    { hpPercent: 100, behavior: 'normal', message: 'Boss dialogue' },
    { hpPercent: 50, behavior: 'enraged', message: 'Rage dialogue!', attackBonus: 1.5 }
  ],
  
  // Loot when defeated
  loot: {
    gold: { min: 100, max: 200 },
    nectar: { min: 50, max: 100 },
    guaranteedItems: ['item_id'],
    possibleButterfly: { chance: 0.3, traits: ['trait_id'] },
    seeds: [{ type: 'seed_type', chance: 0.5 }]
  },
  
  // Boss dialogue
  dialogue: {
    intro: 'When fight starts',
    phase2: 'At 50% HP',
    defeat: 'When defeated',
    victory: 'When player loses'
  }
}
```

---

## 👾 How to Add/Edit Enemies

Open `enemies.config.ts`:

```typescript
my_enemy: {
  id: 'my_enemy',
  name: 'Enemy Name',
  emoji: '👾',
  description: 'Enemy description',
  regions: ['jardim_encantado', 'floresta_sombria'],  // Appears in these regions
  
  baseHp: 30,
  hpPerFloor: 5,
  attack: 10,
  defense: 5,
  speed: 5,
  
  color: '#FF0000',
  isElite: false,  // true for elite enemies
  
  abilities: [
    { name: 'Basic Attack', damage: 10, cooldown: 0 },
    { name: 'Special', damage: 15, effect: 'poison', effectDuration: 2, cooldown: 3 }
  ],
  
  loot: {
    gold: { min: 10, max: 25 },
    nectar: { min: 5, max: 15 },
    itemChance: 0.2,
    items: ['drop_item_id']
  },
  
  behavior: 'aggressive'  // aggressive, defensive, ranged, support, random
}
```

---

## 🗺️ How to Add/Edit Regions

Open `regions.config.ts`:

### Adding Tiles

```typescript
// In TILES object
my_tile: {
  id: 'my_tile',
  name: 'Tile Name',
  emoji: '🌸',
  color: '#FFB6C1',
  walkable: true,  // Can units stand on this?
  effect: {
    type: 'heal',  // damage, heal, buff, debuff
    value: 5,
    message: 'The tile heals you!'
  },
  spawnChance: 0.1  // How often this tile appears
}
```

### Adding Regions

```typescript
my_region: {
  id: 'my_region',
  name: 'Region Name',
  description: 'Region description',
  icon: '🏔️',
  
  // Visual theme
  theme: {
    backgroundColor: '#1a1a2e',
    gridColor: '#2d2d44',
    accentColor: '#6b5b95',
    ambientParticles: ['✨', '🌸']  // Floating particles
  },
  
  // Tiles specific to this region
  tiles: [TILES.grass, TILES.my_tile, TILES.rock],
  
  // Enemies
  enemyPool: ['enemy_id1', 'enemy_id2'],
  elitePool: ['elite_enemy_id'],
  bossId: 'boss_id',
  
  // Difficulty
  dangerLevel: 3,
  minFloors: 4,
  maxFloors: 6,
  
  // Unlock requirements
  unlockRequirement: {
    type: 'defeat_boss',  // defeat_boss, butterfly_count, generation, none
    value: 'previous_boss_id'
  },
  
  // Reward multipliers
  nectarMultiplier: 1.5,
  goldMultiplier: 1.5,
  
  // Exclusive content!
  exclusiveTraits: ['trait1', 'trait2'],
  exclusiveSeeds: ['seed1', 'seed2'],
  exclusiveButterflies: {
    chance: 0.1,
    traits: ['exclusive_trait'],
    colorPool: ['Color1', 'Color2']
  },
  
  // Events that can happen here
  mysteryEvents: ['event_id1', 'event_id2']
}
```

---

## 🌱 How to Add/Edit Plants

Open `plants.config.ts`:

```typescript
my_plant: {
  id: 'my_plant',
  name: 'Plant Name',
  emoji: '🌸',
  description: 'Description',
  
  growthTime: 200,  // Game ticks to grow
  stages: ['🌱', '🌿', '🌸', '🌸✨'],  // Visual stages
  
  harvestYield: {
    nectar: { min: 20, max: 40 },
    items: [{ id: 'item_id', chance: 0.5 }],
    seeds: [{ type: 'seed_type', chance: 0.2 }]
  },
  
  region: 'region_id',  // Where this seed is found
  rarity: 'rare',  // common, uncommon, rare, legendary
  
  // When butterfly interacts with grown plant
  butterflyEffects: {
    type: 'heal',  // buff, heal, exp, trait
    value: 20
  }
}
```

---

## ❓ How to Add/Edit Mystery Events

Open `events.config.ts`:

```typescript
my_event: {
  id: 'my_event',
  title: 'Event Title',
  description: 'What the player sees when event triggers',
  region: 'region_id',  // Optional, region-specific
  
  choices: [
    {
      text: 'Choice button text',
      outcomes: [
        {
          chance: 0.5,  // 50% chance for this outcome
          type: 'reward',  // reward, penalty, neutral, butterfly, combat
          message: 'What happens',
          effects: [
            { type: 'gold', value: 50 },
            { type: 'heal_all', value: 30 },
            { type: 'buff_all', value: 'attack_up' },
            { type: 'seed', value: 'seed_type' },
            { type: 'butterfly', value: 'region_id' },
            { type: 'combat', value: 'enemy_id,enemy_id' },
            { type: 'exp', value: 100 },
            { type: 'trait_random', value: 'trait_id' }
          ]
        },
        {
          chance: 0.5,
          type: 'penalty',
          message: 'Bad outcome',
          effects: [{ type: 'damage_all', value: 20 }]
        }
      ]
    },
    {
      text: 'Another choice',
      // This choice requires a specific trait
      requirements: {
        type: 'butterfly_trait',
        value: 'imunidade_toxinas'
      },
      outcomes: [...]
    }
  ]
}
```

---

## 🔗 Effect Types Reference

### Combat Effects
- `poison` - Damage over time (green)
- `burn` - Fire damage over time (red)
- `freeze` - Skip turns (blue)
- `stun` - Skip 1 turn
- `blind` - Reduced accuracy
- `confuse` - Random targeting
- `curse` - Reduced stats
- `bleed` - HP loss on movement

### Buff Effects
- `attack_up` - Increased damage
- `defense_up` - Increased defense
- `haste` - Extra movement
- `regen` - Heal over time
- `bless` - All stats up
- `invulnerable` - Cannot take damage

### Event Effect Types
- `gold` - Give gold
- `nectar` - Give nectar
- `heal_all` - Heal all party
- `damage_all` - Damage all party
- `buff_all` - Apply buff to party
- `debuff_all` - Apply debuff to party
- `exp` - Give experience
- `seed` - Give a seed
- `item` - Give an item
- `butterfly` - Spawn a butterfly
- `combat` - Start combat (comma-separated enemy IDs)
- `trait_random` - Give trait to random butterfly
- `reveal_map` - Reveal dungeon rooms

---

## 🎨 How to Use This in Your Project

### 1. Import configs in your code:

```typescript
import { 
  REGIONS_CONFIG, 
  BOSSES_CONFIG, 
  ENEMIES_CONFIG,
  getRegion,
  getBossForRegion,
  getEnemiesForRegion
} from './config';
```

### 2. Get data:

```typescript
// Get a specific region
const garden = getRegion('jardim_encantado');

// Get boss for a region
const boss = getBossForRegion('jardim_encantado');

// Get all enemies for a region
const enemies = getEnemiesForRegion('jardim_encantado');

// Generate tile grid for combat
import { generateTileGrid } from './config';
const tiles = generateTileGrid('jardim_encantado', 10, 10);
```

### 3. Pass to CombatGrid:

```typescript
<CombatGrid
  state={combatState}
  validMoves={moves}
  validTargets={targets}
  onTileClick={handleClick}
  onUnitClick={handleUnit}
  regionId="jardim_encantado"
  tileGrid={tiles}
/>
```

---

## 📝 Quick Tips

1. **Region-exclusive traits** automatically have higher chance to appear on butterflies found in that region
2. **Seeds can only be found** in their designated region
3. **Bosses scale** with floor number using `hpPerFloor`
4. **Events with requirements** only show that choice if requirement is met
5. **Tile effects trigger** when a unit moves onto that tile
6. **Ambient particles** are purely visual, floating in the background

Happy breeding! 🦋
