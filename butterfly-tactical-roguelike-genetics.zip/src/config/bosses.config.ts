// ════════════════════════════════════════════════════════════════
// BOSSES CONFIGURATION - Easy to edit!
// ════════════════════════════════════════════════════════════════
// Add, remove, or modify bosses here. Each boss needs:
// - id: unique identifier
// - name: display name
// - emoji: visual representation
// - region: which region this boss appears in
// - hp, attack, defense: base stats
// - abilities: special attacks the boss can use
// - loot: what the boss drops when defeated
// - dialogue: what the boss says during battle

import { BossConfig } from './types.config';

export const BOSSES_CONFIG: Record<string, BossConfig> = {
  // ═══════════════════════════════════════════════════════════
  // JARDIM ENCANTADO BOSS
  // ═══════════════════════════════════════════════════════════
  rainha_abelha: {
    id: 'rainha_abelha',
    name: 'Rainha das Abelhas',
    emoji: '👑🐝',
    description: 'A fearsome queen who commands swarms of loyal bee soldiers.',
    region: 'jardim_encantado',
    
    // Stats - Scale with floor level
    baseHp: 150,
    hpPerFloor: 25,
    attack: 18,
    defense: 8,
    speed: 5,
    
    // Visual
    color: '#FFD700',
    size: 'large', // small, medium, large, huge
    
    // Abilities
    abilities: [
      {
        name: 'Enxame Real',
        description: 'Summons bee swarms to attack all enemies',
        damage: 12,
        type: 'summon',
        cooldown: 3,
        effect: 'summon_bees',
        targetType: 'all_enemies'
      },
      {
        name: 'Ferrão Venenoso',
        description: 'Powerful sting that poisons the target',
        damage: 20,
        type: 'attack',
        cooldown: 2,
        effect: 'poison',
        effectDuration: 3,
        targetType: 'single'
      },
      {
        name: 'Mel Curativo',
        description: 'Heals self and all allies',
        damage: 0,
        healing: 30,
        type: 'heal',
        cooldown: 4,
        targetType: 'self_and_allies'
      }
    ],
    
    // Battle phases - boss behavior changes at HP thresholds
    phases: [
      { hpPercent: 100, behavior: 'normal', message: 'Vocês ousam invadir meu jardim?!' },
      { hpPercent: 50, behavior: 'enraged', message: 'Sintam a fúria do enxame!', attackBonus: 1.5 },
      { hpPercent: 25, behavior: 'desperate', message: 'Nunca cairei!', speedBonus: 2 }
    ],
    
    // Loot drops
    loot: {
      gold: { min: 100, max: 200 },
      nectar: { min: 50, max: 100 },
      guaranteedItems: ['mel_real', 'coroa_abelha'],
      possibleButterfly: {
        chance: 0.3,
        traits: ['asas_douradas', 'aura_real']
      },
      seeds: [
        { type: 'girassol', chance: 0.5 },
        { type: 'lavanda', chance: 0.3 }
      ]
    },
    
    // Dialogue
    dialogue: {
      intro: 'Borboletas insignificantes! Este jardim pertence às abelhas!',
      phase2: 'Vocês me irritaram... ENXAME, ATAQUEM!',
      phase3: 'Não... não posso perder...',
      defeat: 'O jardim... é de vocês agora...',
      victory: 'Hahaha! Borboletas fracas!'
    }
  },

  // ═══════════════════════════════════════════════════════════
  // FLORESTA SOMBRIA BOSS
  // ═══════════════════════════════════════════════════════════
  aranha_matriarca: {
    id: 'aranha_matriarca',
    name: 'Aranha Matriarca',
    emoji: '🕷️👁️',
    description: 'Ancient spider queen who has lived for centuries in the dark forest.',
    region: 'floresta_sombria',
    
    baseHp: 200,
    hpPerFloor: 30,
    attack: 22,
    defense: 12,
    speed: 7,
    
    color: '#4A0080',
    size: 'huge',
    
    abilities: [
      {
        name: 'Teia Paralisante',
        description: 'Traps enemies in sticky webs',
        damage: 8,
        type: 'control',
        cooldown: 2,
        effect: 'stun',
        effectDuration: 2,
        targetType: 'area',
        areaSize: 3
      },
      {
        name: 'Mordida Venenosa',
        description: 'Deadly venomous bite',
        damage: 25,
        type: 'attack',
        cooldown: 1,
        effect: 'poison',
        effectDuration: 4,
        targetType: 'single'
      },
      {
        name: 'Invocar Aranhas',
        description: 'Summons spider minions',
        damage: 0,
        type: 'summon',
        cooldown: 4,
        effect: 'summon_spiders',
        summonCount: 3,
        targetType: 'none'
      },
      {
        name: 'Escuridão Total',
        description: 'Blinds all enemies',
        damage: 5,
        type: 'debuff',
        cooldown: 5,
        effect: 'blind',
        effectDuration: 2,
        targetType: 'all_enemies'
      }
    ],
    
    phases: [
      { hpPercent: 100, behavior: 'normal', message: 'Mais presas para minha teia...' },
      { hpPercent: 60, behavior: 'tactical', message: 'Vocês são mais fortes do que pensei.', defenseBonus: 1.3 },
      { hpPercent: 30, behavior: 'enraged', message: 'MINHAS FILHAS, VENHAM!', attackBonus: 1.8 }
    ],
    
    loot: {
      gold: { min: 150, max: 300 },
      nectar: { min: 30, max: 80 },
      guaranteedItems: ['seda_sombria', 'olho_aranha'],
      possibleButterfly: {
        chance: 0.25,
        traits: ['asas_sombrias', 'visao_noturna']
      },
      seeds: [
        { type: 'cogumelo_lunar', chance: 0.4 },
        { type: 'orquidea_negra', chance: 0.2 }
      ]
    },
    
    dialogue: {
      intro: 'Hmm... borboletas deliciosas entraram na minha floresta.',
      phase2: 'Interessante... vocês têm força.',
      phase3: 'BASTA! Vocês morrerão aqui!',
      defeat: 'A escuridão... me consome...',
      victory: 'Suas asas farão uma bela decoração.'
    }
  },

  // ═══════════════════════════════════════════════════════════
  // CAVERNA CRISTALINA BOSS
  // ═══════════════════════════════════════════════════════════
  golem_cristal: {
    id: 'golem_cristal',
    name: 'Golem de Cristal',
    emoji: '💎🗿',
    description: 'An ancient construct made of living crystals, guardian of the caves.',
    region: 'caverna_cristalina',
    
    baseHp: 300,
    hpPerFloor: 40,
    attack: 15,
    defense: 25,
    speed: 2,
    
    color: '#00FFFF',
    size: 'huge',
    
    abilities: [
      {
        name: 'Explosão Cristalina',
        description: 'Shatters crystals in a massive explosion',
        damage: 35,
        type: 'attack',
        cooldown: 4,
        effect: 'none',
        targetType: 'area',
        areaSize: 4
      },
      {
        name: 'Escudo de Diamante',
        description: 'Creates an impenetrable shield',
        damage: 0,
        type: 'buff',
        cooldown: 5,
        effect: 'invulnerable',
        effectDuration: 1,
        targetType: 'self'
      },
      {
        name: 'Prisma Refletor',
        description: 'Reflects next attack back at attacker',
        damage: 0,
        type: 'buff',
        cooldown: 3,
        effect: 'reflect',
        effectDuration: 1,
        targetType: 'self'
      },
      {
        name: 'Terremoto',
        description: 'Shakes the ground, damaging and slowing all enemies',
        damage: 18,
        type: 'attack',
        cooldown: 3,
        effect: 'slow',
        effectDuration: 2,
        targetType: 'all_enemies'
      }
    ],
    
    phases: [
      { hpPercent: 100, behavior: 'defensive', message: '...INTRUSOS DETECTADOS...' },
      { hpPercent: 50, behavior: 'normal', message: '...MODO DE DEFESA ATIVADO...', defenseBonus: 2 },
      { hpPercent: 20, behavior: 'berserk', message: '...PROTOCOLO DE DESTRUIÇÃO...', attackBonus: 2.5, defenseBonus: 0.5 }
    ],
    
    loot: {
      gold: { min: 200, max: 400 },
      nectar: { min: 40, max: 90 },
      guaranteedItems: ['cristal_puro', 'nucleo_golem'],
      possibleButterfly: {
        chance: 0.35,
        traits: ['asas_cristalinas', 'corpo_prismatico']
      },
      seeds: [
        { type: 'cristal_semente', chance: 0.6 },
        { type: 'flor_gelo', chance: 0.3 }
      ]
    },
    
    dialogue: {
      intro: '...BORBOLETAS... NÃO AUTORIZADAS... ELIMINAR...',
      phase2: '...DANO DETECTADO... AUMENTANDO DEFESAS...',
      phase3: '...NÚCLEO EXPOSTO... DESTRUIÇÃO TOTAL INICIADA...',
      defeat: '...SISTEMA... DESLIGANDO...',
      victory: '...INTRUSOS... ELIMINADOS...'
    }
  },

  // ═══════════════════════════════════════════════════════════
  // PÂNTANO MISTERIOSO BOSS
  // ═══════════════════════════════════════════════════════════
  sapo_anciao: {
    id: 'sapo_anciao',
    name: 'Sapo Ancião',
    emoji: '🐸👴',
    description: 'A mystical toad who has absorbed centuries of swamp magic.',
    region: 'pantano_misterioso',
    
    baseHp: 180,
    hpPerFloor: 28,
    attack: 20,
    defense: 10,
    speed: 4,
    
    color: '#228B22',
    size: 'large',
    
    abilities: [
      {
        name: 'Língua Venenosa',
        description: 'Lashes out with toxic tongue',
        damage: 22,
        type: 'attack',
        cooldown: 1,
        effect: 'poison',
        effectDuration: 3,
        range: 5,
        targetType: 'single'
      },
      {
        name: 'Chuva Ácida',
        description: 'Summons corrosive rain',
        damage: 15,
        type: 'attack',
        cooldown: 3,
        effect: 'defense_down',
        effectDuration: 2,
        targetType: 'all_enemies'
      },
      {
        name: 'Engolir',
        description: 'Swallows a small enemy whole',
        damage: 50,
        type: 'attack',
        cooldown: 5,
        effect: 'instant_kill_small',
        targetType: 'single'
      },
      {
        name: 'Neblina Tóxica',
        description: 'Creates a poisonous fog',
        damage: 8,
        type: 'area_denial',
        cooldown: 4,
        effect: 'create_poison_zone',
        areaSize: 5,
        effectDuration: 3,
        targetType: 'area'
      }
    ],
    
    phases: [
      { hpPercent: 100, behavior: 'normal', message: 'Croak... mais borboletas para o pântano...' },
      { hpPercent: 50, behavior: 'magical', message: 'Vocês perturbaram meu descanso!', magicBonus: 1.5 },
      { hpPercent: 25, behavior: 'desperate', message: 'O PÂNTANO CONSUMIRÁ VOCÊS!', speedBonus: 3 }
    ],
    
    loot: {
      gold: { min: 120, max: 250 },
      nectar: { min: 60, max: 120 },
      guaranteedItems: ['gosma_anciã', 'pedra_pantano'],
      possibleButterfly: {
        chance: 0.28,
        traits: ['asas_venenosas', 'imunidade_toxinas']
      },
      seeds: [
        { type: 'vitoria_regia', chance: 0.5 },
        { type: 'erva_pantano', chance: 0.4 }
      ]
    },
    
    dialogue: {
      intro: 'Croooak... pequenas borboletas, grandes erros...',
      phase2: 'O pântano me dá poder! CROOOAK!',
      phase3: 'Não... não serei derrotado por INSETOS!',
      defeat: 'O pântano... sempre existirá... croak...',
      victory: 'Croak! Delicioso!'
    }
  },

  // ═══════════════════════════════════════════════════════════
  // VULCÃO ARDENTE BOSS
  // ═══════════════════════════════════════════════════════════
  fenix_corrompida: {
    id: 'fenix_corrompida',
    name: 'Fênix Corrompida',
    emoji: '🔥🦅',
    description: 'A phoenix corrupted by volcanic rage, burning with eternal fury.',
    region: 'vulcao_ardente',
    
    baseHp: 220,
    hpPerFloor: 35,
    attack: 28,
    defense: 6,
    speed: 10,
    
    color: '#FF4500',
    size: 'huge',
    
    abilities: [
      {
        name: 'Chamas do Inferno',
        description: 'Breathes devastating fire',
        damage: 30,
        type: 'attack',
        cooldown: 2,
        effect: 'burn',
        effectDuration: 3,
        targetType: 'cone',
        coneAngle: 90
      },
      {
        name: 'Renascimento',
        description: 'Rises from ashes with partial health',
        damage: 0,
        healing: 50,
        type: 'passive',
        cooldown: 0,
        effect: 'resurrect',
        uses: 1,
        targetType: 'self'
      },
      {
        name: 'Explosão Nova',
        description: 'Massive explosion damaging everything',
        damage: 40,
        type: 'attack',
        cooldown: 5,
        effect: 'burn',
        effectDuration: 2,
        targetType: 'all'
      },
      {
        name: 'Voo Flamejante',
        description: 'Dashes through enemies leaving fire trail',
        damage: 20,
        type: 'attack',
        cooldown: 2,
        effect: 'create_fire_trail',
        targetType: 'line'
      }
    ],
    
    phases: [
      { hpPercent: 100, behavior: 'aggressive', message: 'ARDAM! ARDAM TODOS!' },
      { hpPercent: 50, behavior: 'berserk', message: 'A FÚRIA DO VULCÃO!', attackBonus: 1.8 },
      { hpPercent: 1, behavior: 'resurrection', message: 'EU... RENASÇO!', trigger: 'resurrect' }
    ],
    
    loot: {
      gold: { min: 250, max: 500 },
      nectar: { min: 80, max: 150 },
      guaranteedItems: ['pena_fenix', 'essencia_vulcanica'],
      possibleButterfly: {
        chance: 0.2,
        traits: ['asas_flamejantes', 'imunidade_fogo', 'aura_calor']
      },
      seeds: [
        { type: 'flor_fogo', chance: 0.4 },
        { type: 'cacto_vulcanico', chance: 0.3 }
      ]
    },
    
    dialogue: {
      intro: 'FOGO! DESTRUIÇÃO! VOCÊS SERÃO CINZAS!',
      phase2: 'SINTAM A FÚRIA DE MIL SÓIS!',
      phase3: 'Vocês... acham que podem me matar? EU SOU ETERNA!',
      defeat: 'As chamas... se apagam... por agora...',
      victory: 'HAHAHA! MAIS COMBUSTÍVEL PARA O FOGO!'
    }
  },

  // ═══════════════════════════════════════════════════════════
  // TEMPLO CELESTIAL BOSS (Final Boss)
  // ═══════════════════════════════════════════════════════════
  imperador_mariposa: {
    id: 'imperador_mariposa',
    name: 'Imperador Mariposa',
    emoji: '🦋👑✨',
    description: 'The legendary Moth Emperor, ruler of all lepidoptera, corrupted by dark ambition.',
    region: 'templo_celestial',
    
    baseHp: 500,
    hpPerFloor: 50,
    attack: 35,
    defense: 20,
    speed: 8,
    
    color: '#9932CC',
    size: 'huge',
    
    abilities: [
      {
        name: 'Pó das Estrelas',
        description: 'Magical stardust that damages and confuses',
        damage: 25,
        type: 'attack',
        cooldown: 2,
        effect: 'confuse',
        effectDuration: 2,
        targetType: 'area',
        areaSize: 4
      },
      {
        name: 'Asas do Destino',
        description: 'Devastating wing attack',
        damage: 45,
        type: 'attack',
        cooldown: 3,
        effect: 'knockback',
        knockbackDistance: 3,
        targetType: 'cone',
        coneAngle: 120
      },
      {
        name: 'Metamorfose Sombria',
        description: 'Transforms into shadow form',
        damage: 0,
        type: 'buff',
        cooldown: 6,
        effect: 'shadow_form',
        effectDuration: 3,
        targetType: 'self',
        bonuses: { evasion: 0.5, attackBonus: 1.3 }
      },
      {
        name: 'Invocar Campeões',
        description: 'Summons elite moth guardians',
        damage: 0,
        type: 'summon',
        cooldown: 5,
        effect: 'summon_elite',
        summonCount: 2,
        summonType: 'moth_champion',
        targetType: 'none'
      },
      {
        name: 'Eclipse Total',
        description: 'Ultimate attack that damages all and heals self',
        damage: 50,
        healing: 100,
        type: 'ultimate',
        cooldown: 8,
        effect: 'eclipse',
        targetType: 'all_enemies'
      }
    ],
    
    phases: [
      { hpPercent: 100, behavior: 'regal', message: 'Então vocês chegaram... as lendárias borboletas rebeldes.' },
      { hpPercent: 75, behavior: 'tactical', message: 'Impressionante. Mas vocês são apenas insetos.', defenseBonus: 1.2 },
      { hpPercent: 50, behavior: 'aggressive', message: 'CHEGA DE JOGOS!', attackBonus: 1.5 },
      { hpPercent: 25, behavior: 'desperate', message: 'IMPOSSÍVEL! EU SOU O IMPERADOR!', attackBonus: 2, speedBonus: 1.5 },
      { hpPercent: 10, behavior: 'final', message: 'Se eu cair... LEVO TODOS COMIGO!', trigger: 'final_phase' }
    ],
    
    loot: {
      gold: { min: 500, max: 1000 },
      nectar: { min: 200, max: 300 },
      guaranteedItems: ['coroa_imperador', 'manto_celestial', 'essencia_divina'],
      possibleButterfly: {
        chance: 0.5,
        traits: ['asas_imperiais', 'aura_divina', 'imortalidade']
      },
      seeds: [
        { type: 'flor_celestial', chance: 0.8 },
        { type: 'arvore_mundo', chance: 0.2 }
      ]
    },
    
    dialogue: {
      intro: 'Borboletas... vocês ousam desafiar o Imperador de toda lepidoptera?',
      phase2: 'Vocês têm coragem. Mas coragem não é suficiente.',
      phase3: 'Meu poder é absoluto! CONTEMPLEM!',
      phase4: 'NÃO! ISSO NÃO PODE ESTAR ACONTECENDO!',
      defeat: 'Como... como insetos comuns... derrotaram... um deus...',
      victory: 'Patético. Voltem quando forem dignos.'
    }
  }
};

// Helper to get boss by region
export function getBossForRegion(regionId: string): BossConfig | null {
  return Object.values(BOSSES_CONFIG).find(b => b.region === regionId) || null;
}

// Helper to get all bosses
export function getAllBosses(): BossConfig[] {
  return Object.values(BOSSES_CONFIG);
}
