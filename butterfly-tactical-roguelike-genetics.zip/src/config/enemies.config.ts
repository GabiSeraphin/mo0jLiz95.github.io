// ════════════════════════════════════════════════════════════════
// ENEMIES CONFIGURATION - Easy to edit!
// ════════════════════════════════════════════════════════════════
// Add, remove, or modify enemies here.
// Each enemy can appear in multiple regions.

import { EnemyConfig } from './types.config';

export const ENEMIES_CONFIG: Record<string, EnemyConfig> = {
  // ═══════════════════════════════════════════════════════════
  // JARDIM ENCANTADO ENEMIES
  // ═══════════════════════════════════════════════════════════
  joaninha: {
    id: 'joaninha',
    name: 'Joaninha',
    emoji: '🐞',
    description: 'Uma joaninha territorial que defende seu jardim.',
    regions: ['jardim_encantado'],
    
    baseHp: 25,
    hpPerFloor: 5,
    attack: 8,
    defense: 4,
    speed: 5,
    
    color: '#FF0000',
    
    abilities: [
      { name: 'Mordida', damage: 8, cooldown: 0 },
      { name: 'Carapaça', damage: 0, effect: 'defense_up', effectDuration: 2, cooldown: 3 }
    ],
    
    loot: {
      gold: { min: 5, max: 15 },
      nectar: { min: 2, max: 8 },
      itemChance: 0.1,
      items: ['casca_joaninha']
    },
    
    behavior: 'defensive'
  },
  
  abelha: {
    id: 'abelha',
    name: 'Abelha Soldado',
    emoji: '🐝',
    description: 'Soldado da colmeia, ataca em grupos.',
    regions: ['jardim_encantado'],
    
    baseHp: 20,
    hpPerFloor: 4,
    attack: 10,
    defense: 2,
    speed: 7,
    
    color: '#FFD700',
    
    abilities: [
      { name: 'Ferroada', damage: 12, effect: 'poison', effectDuration: 2, cooldown: 0 }
    ],
    
    loot: {
      gold: { min: 3, max: 10 },
      nectar: { min: 5, max: 15 },
      itemChance: 0.15,
      items: ['mel', 'ferrao']
    },
    
    behavior: 'aggressive'
  },
  
  formiga: {
    id: 'formiga',
    name: 'Formiga Guerreira',
    emoji: '🐜',
    description: 'Pequena mas feroz, sempre em bandos.',
    regions: ['jardim_encantado', 'floresta_sombria'],
    
    baseHp: 15,
    hpPerFloor: 3,
    attack: 6,
    defense: 3,
    speed: 8,
    
    color: '#8B4513',
    
    abilities: [
      { name: 'Mordida Ácida', damage: 6, effect: 'defense_down', effectDuration: 1, cooldown: 0 }
    ],
    
    loot: {
      gold: { min: 2, max: 8 }
    },
    
    behavior: 'aggressive'
  },
  
  grilo: {
    id: 'grilo',
    name: 'Grilo Saltador',
    emoji: '🦗',
    description: 'Salta rapidamente pelo campo de batalha.',
    regions: ['jardim_encantado'],
    
    baseHp: 18,
    hpPerFloor: 3,
    attack: 7,
    defense: 2,
    speed: 10,
    
    color: '#228B22',
    
    abilities: [
      { name: 'Salto Atacante', damage: 9, cooldown: 0 },
      { name: 'Canto Irritante', damage: 0, effect: 'confuse', effectDuration: 1, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 4, max: 12 }
    },
    
    behavior: 'random'
  },
  
  // Jardim Elites
  vespa_rainha: {
    id: 'vespa_rainha',
    name: 'Vespa Rainha',
    emoji: '🐝👑',
    description: 'Uma vespa gigante que comanda suas súditas.',
    regions: ['jardim_encantado'],
    
    baseHp: 60,
    hpPerFloor: 12,
    attack: 18,
    defense: 8,
    speed: 6,
    
    color: '#FF8C00',
    isElite: true,
    
    abilities: [
      { name: 'Ferroada Real', damage: 20, effect: 'poison', effectDuration: 3, cooldown: 0 },
      { name: 'Invocar Vespas', damage: 0, effect: 'summon', cooldown: 4 },
      { name: 'Fúria da Colmeia', damage: 25, cooldown: 3 }
    ],
    
    loot: {
      gold: { min: 30, max: 60 },
      nectar: { min: 20, max: 40 },
      itemChance: 0.5,
      items: ['coroa_vespa', 'mel_real']
    },
    
    behavior: 'aggressive'
  },
  
  besouro_dourado: {
    id: 'besouro_dourado',
    name: 'Besouro Dourado',
    emoji: '🪲✨',
    description: 'Um besouro raro coberto de ouro.',
    regions: ['jardim_encantado'],
    
    baseHp: 80,
    hpPerFloor: 15,
    attack: 14,
    defense: 15,
    speed: 3,
    
    color: '#FFD700',
    isElite: true,
    
    abilities: [
      { name: 'Investida', damage: 16, cooldown: 0 },
      { name: 'Armadura Dourada', damage: 0, effect: 'invulnerable', effectDuration: 1, cooldown: 5 },
      { name: 'Brilho Cegante', damage: 10, effect: 'blind', effectDuration: 2, cooldown: 3 }
    ],
    
    loot: {
      gold: { min: 80, max: 150 },
      nectar: { min: 10, max: 25 },
      itemChance: 0.7,
      items: ['escama_dourada', 'pepita_ouro']
    },
    
    behavior: 'defensive'
  },

  // ═══════════════════════════════════════════════════════════
  // FLORESTA SOMBRIA ENEMIES
  // ═══════════════════════════════════════════════════════════
  aranha: {
    id: 'aranha',
    name: 'Aranha das Sombras',
    emoji: '🕷️',
    description: 'Tece teias mortais na escuridão.',
    regions: ['floresta_sombria'],
    
    baseHp: 30,
    hpPerFloor: 6,
    attack: 12,
    defense: 4,
    speed: 6,
    
    color: '#4A0080',
    
    abilities: [
      { name: 'Mordida Venenosa', damage: 10, effect: 'poison', effectDuration: 3, cooldown: 0 },
      { name: 'Teia', damage: 0, effect: 'stun', effectDuration: 1, cooldown: 3 }
    ],
    
    loot: {
      gold: { min: 8, max: 20 },
      itemChance: 0.2,
      items: ['seda_aranha', 'veneno_aranha']
    },
    
    behavior: 'ranged'
  },
  
  morcego: {
    id: 'morcego',
    name: 'Morcego Vampiro',
    emoji: '🦇',
    description: 'Drena a vida de suas vítimas.',
    regions: ['floresta_sombria', 'caverna_cristalina'],
    
    baseHp: 22,
    hpPerFloor: 4,
    attack: 11,
    defense: 3,
    speed: 9,
    
    color: '#2F2F2F',
    
    abilities: [
      { name: 'Drenar Vida', damage: 8, effect: 'lifesteal', cooldown: 0 }
    ],
    
    loot: {
      gold: { min: 6, max: 15 }
    },
    
    behavior: 'aggressive'
  },
  
  lobo_sombra: {
    id: 'lobo_sombra',
    name: 'Lobo das Sombras',
    emoji: '🐺',
    description: 'Predador silencioso da floresta escura.',
    regions: ['floresta_sombria'],
    
    baseHp: 45,
    hpPerFloor: 8,
    attack: 16,
    defense: 6,
    speed: 8,
    
    color: '#1a1a2e',
    
    abilities: [
      { name: 'Mordida Feroz', damage: 18, cooldown: 0 },
      { name: 'Uivo', damage: 0, effect: 'attack_up', effectDuration: 2, cooldown: 4 },
      { name: 'Ataque Furtivo', damage: 25, effect: 'ignore_defense', cooldown: 3 }
    ],
    
    loot: {
      gold: { min: 15, max: 35 },
      itemChance: 0.25,
      items: ['presa_lobo', 'pele_sombria']
    },
    
    behavior: 'aggressive'
  },
  
  corvo: {
    id: 'corvo',
    name: 'Corvo Maldito',
    emoji: '🐦‍⬛',
    description: 'Mensageiro de maus presságios.',
    regions: ['floresta_sombria'],
    
    baseHp: 18,
    hpPerFloor: 3,
    attack: 9,
    defense: 2,
    speed: 11,
    
    color: '#000000',
    
    abilities: [
      { name: 'Bicada', damage: 9, cooldown: 0 },
      { name: 'Maldição', damage: 0, effect: 'curse', effectDuration: 3, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 5, max: 12 }
    },
    
    behavior: 'ranged'
  },
  
  // Floresta Elites
  aranha_gigante: {
    id: 'aranha_gigante',
    name: 'Aranha Gigante',
    emoji: '🕷️🕸️',
    description: 'Uma aranha do tamanho de uma casa.',
    regions: ['floresta_sombria'],
    
    baseHp: 100,
    hpPerFloor: 18,
    attack: 22,
    defense: 10,
    speed: 4,
    
    color: '#2d0a4e',
    isElite: true,
    
    abilities: [
      { name: 'Mordida Colossal', damage: 28, effect: 'poison', effectDuration: 4, cooldown: 0 },
      { name: 'Rede de Teias', damage: 10, effect: 'stun', effectDuration: 2, cooldown: 3 },
      { name: 'Ovos de Aranha', damage: 0, effect: 'summon', cooldown: 5 }
    ],
    
    loot: {
      gold: { min: 50, max: 100 },
      itemChance: 0.6,
      items: ['seda_gigante', 'olho_aranha', 'quelicera']
    },
    
    behavior: 'defensive'
  },

  // ═══════════════════════════════════════════════════════════
  // CAVERNA CRISTALINA ENEMIES  
  // ═══════════════════════════════════════════════════════════
  morcego_cristal: {
    id: 'morcego_cristal',
    name: 'Morcego de Cristal',
    emoji: '🦇💎',
    description: 'Morcego com asas cristalinas cortantes.',
    regions: ['caverna_cristalina'],
    
    baseHp: 28,
    hpPerFloor: 5,
    attack: 14,
    defense: 8,
    speed: 8,
    
    color: '#00CED1',
    
    abilities: [
      { name: 'Corte Cristalino', damage: 14, effect: 'bleed', effectDuration: 2, cooldown: 0 },
      { name: 'Eco de Cristal', damage: 10, cooldown: 2 }
    ],
    
    loot: {
      gold: { min: 12, max: 25 },
      itemChance: 0.3,
      items: ['fragmento_cristal']
    },
    
    behavior: 'aggressive'
  },
  
  golem_pequeno: {
    id: 'golem_pequeno',
    name: 'Golem de Pedra',
    emoji: '🗿',
    description: 'Construto de pedra animado.',
    regions: ['caverna_cristalina'],
    
    baseHp: 60,
    hpPerFloor: 10,
    attack: 12,
    defense: 18,
    speed: 2,
    
    color: '#696969',
    
    abilities: [
      { name: 'Soco de Pedra', damage: 15, cooldown: 0 },
      { name: 'Endurecer', damage: 0, effect: 'defense_up', effectDuration: 3, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 15, max: 30 },
      itemChance: 0.2,
      items: ['pedra_animada', 'runa_golem']
    },
    
    behavior: 'defensive'
  },
  
  elemental_terra: {
    id: 'elemental_terra',
    name: 'Elemental de Terra',
    emoji: '🌍',
    description: 'Espírito da própria terra.',
    regions: ['caverna_cristalina'],
    
    baseHp: 50,
    hpPerFloor: 8,
    attack: 18,
    defense: 12,
    speed: 3,
    
    color: '#8B4513',
    
    abilities: [
      { name: 'Terremoto', damage: 20, cooldown: 0 },
      { name: 'Regeneração Terra', damage: 0, effect: 'regen', effectDuration: 3, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 20, max: 40 },
      itemChance: 0.35,
      items: ['essencia_terra', 'nucleo_elemental']
    },
    
    behavior: 'defensive'
  },

  // ═══════════════════════════════════════════════════════════
  // PÂNTANO MISTERIOSO ENEMIES
  // ═══════════════════════════════════════════════════════════
  sapo: {
    id: 'sapo',
    name: 'Sapo Tóxico',
    emoji: '🐸',
    description: 'Sapo que secreta veneno pela pele.',
    regions: ['pantano_misterioso'],
    
    baseHp: 35,
    hpPerFloor: 6,
    attack: 10,
    defense: 6,
    speed: 5,
    
    color: '#228B22',
    
    abilities: [
      { name: 'Língua Tóxica', damage: 12, effect: 'poison', effectDuration: 3, cooldown: 0 },
      { name: 'Salto', damage: 8, cooldown: 2 }
    ],
    
    loot: {
      gold: { min: 10, max: 22 },
      itemChance: 0.2,
      items: ['gosma_sapo', 'lingua_sapo']
    },
    
    behavior: 'random'
  },
  
  cobra_pantano: {
    id: 'cobra_pantano',
    name: 'Cobra do Pântano',
    emoji: '🐍',
    description: 'Serpente venenosa das águas turvas.',
    regions: ['pantano_misterioso'],
    
    baseHp: 32,
    hpPerFloor: 5,
    attack: 16,
    defense: 4,
    speed: 7,
    
    color: '#556B2F',
    
    abilities: [
      { name: 'Bote Venenoso', damage: 18, effect: 'poison', effectDuration: 4, cooldown: 0 },
      { name: 'Constrição', damage: 10, effect: 'stun', effectDuration: 1, cooldown: 3 }
    ],
    
    loot: {
      gold: { min: 12, max: 28 },
      itemChance: 0.25,
      items: ['veneno_cobra', 'escama_pantano']
    },
    
    behavior: 'aggressive'
  },
  
  planta_carnivora: {
    id: 'planta_carnivora',
    name: 'Planta Carnívora',
    emoji: '🌱👄',
    description: 'Planta que devora criaturas incautas.',
    regions: ['pantano_misterioso'],
    
    baseHp: 55,
    hpPerFloor: 9,
    attack: 20,
    defense: 8,
    speed: 1,
    
    color: '#32CD32',
    
    abilities: [
      { name: 'Morder', damage: 22, cooldown: 0 },
      { name: 'Engolir', damage: 35, cooldown: 4 },
      { name: 'Esporos', damage: 8, effect: 'poison', effectDuration: 2, cooldown: 2 }
    ],
    
    loot: {
      gold: { min: 18, max: 40 },
      itemChance: 0.3,
      items: ['semente_carnivora', 'seiva_toxica']
    },
    
    behavior: 'defensive'
  },

  // ═══════════════════════════════════════════════════════════
  // VULCÃO ARDENTE ENEMIES
  // ═══════════════════════════════════════════════════════════
  elemental_fogo: {
    id: 'elemental_fogo',
    name: 'Elemental de Fogo',
    emoji: '🔥',
    description: 'Espírito de puro fogo.',
    regions: ['vulcao_ardente'],
    
    baseHp: 40,
    hpPerFloor: 7,
    attack: 22,
    defense: 5,
    speed: 7,
    
    color: '#FF4500',
    
    abilities: [
      { name: 'Bola de Fogo', damage: 20, effect: 'burn', effectDuration: 2, cooldown: 0 },
      { name: 'Explosão', damage: 30, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 20, max: 45 },
      itemChance: 0.35,
      items: ['essencia_fogo', 'brasa_eterna']
    },
    
    behavior: 'aggressive'
  },
  
  salamandra: {
    id: 'salamandra',
    name: 'Salamandra de Lava',
    emoji: '🦎🔥',
    description: 'Lagarto que nada em lava.',
    regions: ['vulcao_ardente'],
    
    baseHp: 50,
    hpPerFloor: 8,
    attack: 18,
    defense: 10,
    speed: 5,
    
    color: '#FF6347',
    
    abilities: [
      { name: 'Mordida Ígnea', damage: 16, effect: 'burn', effectDuration: 2, cooldown: 0 },
      { name: 'Rastro de Fogo', damage: 12, cooldown: 2 },
      { name: 'Regeneração', damage: 0, effect: 'regen', effectDuration: 2, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 22, max: 50 },
      itemChance: 0.3,
      items: ['escama_salamandra', 'cauda_ardente']
    },
    
    behavior: 'defensive'
  },
  
  golem_lava: {
    id: 'golem_lava',
    name: 'Golem de Lava',
    emoji: '🗿🔥',
    description: 'Golem de rocha derretida.',
    regions: ['vulcao_ardente'],
    
    baseHp: 90,
    hpPerFloor: 15,
    attack: 25,
    defense: 18,
    speed: 2,
    
    color: '#8B0000',
    
    abilities: [
      { name: 'Punho de Lava', damage: 28, effect: 'burn', effectDuration: 3, cooldown: 0 },
      { name: 'Erupção', damage: 35, cooldown: 5 }
    ],
    
    loot: {
      gold: { min: 40, max: 80 },
      itemChance: 0.4,
      items: ['nucleo_lava', 'obsidiana']
    },
    
    behavior: 'aggressive'
  },

  // ═══════════════════════════════════════════════════════════
  // TEMPLO CELESTIAL ENEMIES
  // ═══════════════════════════════════════════════════════════
  guardiao_celestial: {
    id: 'guardiao_celestial',
    name: 'Guardião Celestial',
    emoji: '⚔️✨',
    description: 'Protetor eterno do templo.',
    regions: ['templo_celestial'],
    
    baseHp: 70,
    hpPerFloor: 12,
    attack: 24,
    defense: 16,
    speed: 6,
    
    color: '#FFD700',
    
    abilities: [
      { name: 'Lâmina Sagrada', damage: 26, cooldown: 0 },
      { name: 'Escudo Divino', damage: 0, effect: 'defense_up', effectDuration: 2, cooldown: 3 },
      { name: 'Julgamento', damage: 40, cooldown: 5 }
    ],
    
    loot: {
      gold: { min: 50, max: 100 },
      itemChance: 0.4,
      items: ['essencia_celestial', 'fragmento_aureola']
    },
    
    behavior: 'defensive'
  },
  
  mariposa_sombria: {
    id: 'mariposa_sombria',
    name: 'Mariposa Sombria',
    emoji: '🦋🌑',
    description: 'Borboleta corrompida pelo Imperador.',
    regions: ['templo_celestial'],
    
    baseHp: 55,
    hpPerFloor: 10,
    attack: 28,
    defense: 8,
    speed: 9,
    
    color: '#4B0082',
    
    abilities: [
      { name: 'Pó das Trevas', damage: 22, effect: 'blind', effectDuration: 2, cooldown: 0 },
      { name: 'Beijo da Morte', damage: 35, effect: 'lifesteal', cooldown: 3 },
      { name: 'Metamorfose', damage: 0, effect: 'attack_up', effectDuration: 3, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 45, max: 90 },
      itemChance: 0.5,
      items: ['po_sombrio', 'asa_corrompida']
    },
    
    behavior: 'aggressive'
  },
  
  anjo_caido: {
    id: 'anjo_caido',
    name: 'Anjo Caído',
    emoji: '😇➡️😈',
    description: 'Anjo que escolheu seguir o Imperador.',
    regions: ['templo_celestial'],
    
    baseHp: 85,
    hpPerFloor: 14,
    attack: 30,
    defense: 14,
    speed: 7,
    
    color: '#8B008B',
    
    abilities: [
      { name: 'Lâmina Decaída', damage: 32, cooldown: 0 },
      { name: 'Maldição Sagrada', damage: 20, effect: 'curse', effectDuration: 3, cooldown: 3 },
      { name: 'Asas Negras', damage: 0, effect: 'haste', effectDuration: 2, cooldown: 4 }
    ],
    
    loot: {
      gold: { min: 60, max: 120 },
      itemChance: 0.5,
      items: ['pena_negra', 'lagrima_celestial']
    },
    
    behavior: 'aggressive'
  },
  
  // Templo Elite
  serafim_corrompido: {
    id: 'serafim_corrompido',
    name: 'Serafim Corrompido',
    emoji: '👼🖤',
    description: 'O mais poderoso dos anjos caídos.',
    regions: ['templo_celestial'],
    
    baseHp: 150,
    hpPerFloor: 25,
    attack: 40,
    defense: 20,
    speed: 8,
    
    color: '#4B0082',
    isElite: true,
    
    abilities: [
      { name: 'Seis Asas da Destruição', damage: 45, cooldown: 0 },
      { name: 'Coro Sombrio', damage: 30, effect: 'confuse', effectDuration: 2, cooldown: 3 },
      { name: 'Luz Corrompida', damage: 0, effect: 'heal_enemy', cooldown: 5 },
      { name: 'Apocalipse', damage: 60, cooldown: 6 }
    ],
    
    loot: {
      gold: { min: 150, max: 300 },
      itemChance: 0.8,
      items: ['aureola_quebrada', 'essencia_serafim', 'asa_celestial']
    },
    
    behavior: 'aggressive'
  }
};

// Helper functions
export function getEnemy(id: string): EnemyConfig | null {
  return ENEMIES_CONFIG[id] || null;
}

export function getEnemiesForRegion(regionId: string): EnemyConfig[] {
  return Object.values(ENEMIES_CONFIG).filter(e => 
    e.regions.includes(regionId) && !e.isElite
  );
}

export function getElitesForRegion(regionId: string): EnemyConfig[] {
  return Object.values(ENEMIES_CONFIG).filter(e => 
    e.regions.includes(regionId) && e.isElite
  );
}

export function getAllEnemies(): EnemyConfig[] {
  return Object.values(ENEMIES_CONFIG);
}
