import { ButterflyClass, Ability, Stats } from './types';

export const CLASS_DATA: Record<ButterflyClass, {
  description: string;
  baseStats: Partial<Stats>;
  abilities: Ability[];
  icon: string;
  color: string;
}> = {
  Mage: {
    description: 'Masters of arcane butterfly magic, dealing devastating elemental damage.',
    baseStats: { magic: 15, hp: 60, attack: 5, defense: 4 },
    icon: '✨',
    color: '#9333ea',
    abilities: [
      { id: 'fireball', name: 'Fireball', description: 'Launch a ball of fire', damage: 25, range: 4, cooldown: 2, currentCooldown: 0, areaOfEffect: 1, icon: '🔥' },
      { id: 'icestorm', name: 'Ice Storm', description: 'Freeze enemies in area', damage: 15, range: 3, cooldown: 3, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'freeze', duration: 2, power: 1 }, icon: '❄️' },
      { id: 'arcane_bolt', name: 'Arcane Bolt', description: 'Pure magic damage', damage: 18, range: 5, cooldown: 0, currentCooldown: 0, icon: '💫' },
    ]
  },
  Cleric: {
    description: 'Divine healers who protect and restore their allies.',
    baseStats: { magic: 12, hp: 75, attack: 6, defense: 8 },
    icon: '✝️',
    color: '#fbbf24',
    abilities: [
      { id: 'heal', name: 'Divine Heal', description: 'Restore HP to ally', healing: 30, range: 4, cooldown: 2, currentCooldown: 0, icon: '💚' },
      { id: 'smite', name: 'Holy Smite', description: 'Smite with divine light', damage: 15, range: 3, cooldown: 1, currentCooldown: 0, icon: '⚡' },
      { id: 'bless', name: 'Blessing', description: 'Bless an ally with protection', range: 3, cooldown: 4, currentCooldown: 0, statusEffect: { type: 'bless', duration: 3, power: 5 }, icon: '🙏' },
    ]
  },
  Necromancer: {
    description: 'Dark sorcerers who drain life and curse their foes.',
    baseStats: { magic: 14, hp: 55, attack: 4, defense: 5 },
    icon: '💀',
    color: '#4b5563',
    abilities: [
      { id: 'drain_life', name: 'Drain Life', description: 'Steal HP from enemy', damage: 18, healing: 10, range: 3, cooldown: 2, currentCooldown: 0, icon: '🩸' },
      { id: 'curse', name: 'Dark Curse', description: 'Weaken an enemy', range: 4, cooldown: 3, currentCooldown: 0, statusEffect: { type: 'curse', duration: 3, power: 4 }, icon: '🌑' },
      { id: 'bone_spike', name: 'Bone Spike', description: 'Summon bone from ground', damage: 22, range: 4, cooldown: 1, currentCooldown: 0, icon: '🦴' },
    ]
  },
  Paladin: {
    description: 'Holy warriors combining martial prowess with divine magic.',
    baseStats: { attack: 12, hp: 100, defense: 12, magic: 8 },
    icon: '⚔️',
    color: '#f59e0b',
    abilities: [
      { id: 'holy_strike', name: 'Holy Strike', description: 'A divine melee attack', damage: 20, range: 1, cooldown: 0, currentCooldown: 0, icon: '🗡️' },
      { id: 'lay_hands', name: 'Lay on Hands', description: 'Touch heal an ally', healing: 25, range: 1, cooldown: 3, currentCooldown: 0, icon: '🤲' },
      { id: 'divine_shield', name: 'Divine Shield', description: 'Block all damage next turn', range: 0, cooldown: 5, currentCooldown: 0, statusEffect: { type: 'bless', duration: 1, power: 100 }, icon: '🛡️' },
    ]
  },
  Rogue: {
    description: 'Swift assassins who strike from shadows with deadly precision.',
    baseStats: { attack: 14, hp: 65, speed: 15, luck: 12 },
    icon: '🗡️',
    color: '#1f2937',
    abilities: [
      { id: 'backstab', name: 'Backstab', description: 'Critical hit from behind', damage: 35, range: 1, cooldown: 2, currentCooldown: 0, icon: '🔪' },
      { id: 'poison_blade', name: 'Poison Blade', description: 'Apply deadly poison', damage: 12, range: 1, cooldown: 3, currentCooldown: 0, statusEffect: { type: 'poison', duration: 4, power: 5 }, icon: '☠️' },
      { id: 'shadowstep', name: 'Shadowstep', description: 'Teleport behind enemy', damage: 15, range: 5, cooldown: 4, currentCooldown: 0, icon: '👤' },
    ]
  },
  Berserker: {
    description: 'Furious warriors who grow stronger as they take damage.',
    baseStats: { attack: 16, hp: 120, defense: 6, speed: 8 },
    icon: '🪓',
    color: '#dc2626',
    abilities: [
      { id: 'rage_strike', name: 'Rage Strike', description: 'Devastating melee attack', damage: 28, range: 1, cooldown: 0, currentCooldown: 0, icon: '💢' },
      { id: 'whirlwind', name: 'Whirlwind', description: 'Hit all adjacent enemies', damage: 18, range: 1, cooldown: 3, currentCooldown: 0, areaOfEffect: 1, icon: '🌀' },
      { id: 'blood_rage', name: 'Blood Rage', description: 'Sacrifice HP for power', range: 0, cooldown: 4, currentCooldown: 0, statusEffect: { type: 'haste', duration: 3, power: 10 }, icon: '🔴' },
    ]
  },
  Ranger: {
    description: 'Expert marksmen with unmatched range and tracking skills.',
    baseStats: { attack: 13, hp: 70, speed: 12, luck: 10 },
    icon: '🏹',
    color: '#16a34a',
    abilities: [
      { id: 'aimed_shot', name: 'Aimed Shot', description: 'Precise long-range shot', damage: 22, range: 6, cooldown: 1, currentCooldown: 0, icon: '🎯' },
      { id: 'multishot', name: 'Multishot', description: 'Hit multiple targets', damage: 14, range: 5, cooldown: 3, currentCooldown: 0, areaOfEffect: 2, icon: '🏹' },
      { id: 'trap', name: 'Lay Trap', description: 'Place a damaging trap', damage: 20, range: 3, cooldown: 4, currentCooldown: 0, statusEffect: { type: 'slow', duration: 2, power: 3 }, icon: '🪤' },
    ]
  },
  Summoner: {
    description: 'Mystics who call forth creatures to fight alongside them.',
    baseStats: { magic: 13, hp: 60, defense: 5, luck: 8 },
    icon: '🦋',
    color: '#a855f7',
    abilities: [
      { id: 'summon_sprite', name: 'Summon Sprite', description: 'Call a fighting sprite', damage: 15, range: 4, cooldown: 2, currentCooldown: 0, icon: '🧚' },
      { id: 'spirit_bomb', name: 'Spirit Bomb', description: 'Spirits explode on enemies', damage: 25, range: 4, cooldown: 3, currentCooldown: 0, areaOfEffect: 1, icon: '👻' },
      { id: 'protect_swarm', name: 'Protect Swarm', description: 'Summon protective butterflies', range: 2, cooldown: 5, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'regen', duration: 3, power: 8 }, icon: '🦋' },
    ]
  },
  Chronomancer: {
    description: 'Time-bending butterflies who manipulate the flow of battle.',
    baseStats: { magic: 14, hp: 55, speed: 14, luck: 10 },
    icon: '⏰',
    color: '#0ea5e9',
    abilities: [
      { id: 'time_bolt', name: 'Time Bolt', description: 'Temporal damage', damage: 18, range: 5, cooldown: 0, currentCooldown: 0, icon: '⌛' },
      { id: 'slow_time', name: 'Slow Time', description: 'Slow enemies in area', range: 4, cooldown: 4, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'slow', duration: 2, power: 5 }, icon: '🐌' },
      { id: 'haste', name: 'Accelerate', description: 'Speed up an ally', range: 3, cooldown: 3, currentCooldown: 0, statusEffect: { type: 'haste', duration: 3, power: 5 }, icon: '⚡' },
    ]
  },
  Druid: {
    description: 'Nature-attuned butterflies who command flora and fauna.',
    baseStats: { magic: 11, hp: 80, defense: 8, luck: 9 },
    icon: '🌿',
    color: '#22c55e',
    abilities: [
      { id: 'vine_whip', name: 'Vine Whip', description: 'Lash with thorny vines', damage: 16, range: 3, cooldown: 0, currentCooldown: 0, icon: '🌱' },
      { id: 'regenerate', name: 'Regenerate', description: 'Heal over time', range: 3, cooldown: 3, currentCooldown: 0, statusEffect: { type: 'regen', duration: 4, power: 8 }, icon: '💚' },
      { id: 'entangle', name: 'Entangle', description: 'Root enemies in place', damage: 10, range: 4, cooldown: 4, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'stun', duration: 1, power: 1 }, icon: '🌳' },
    ]
  },
  Alchemist: {
    description: 'Masters of potions and explosives with versatile abilities.',
    baseStats: { magic: 10, hp: 65, attack: 8, luck: 12 },
    icon: '⚗️',
    color: '#84cc16',
    abilities: [
      { id: 'acid_bomb', name: 'Acid Bomb', description: 'Throw corrosive acid', damage: 18, range: 4, cooldown: 1, currentCooldown: 0, statusEffect: { type: 'poison', duration: 3, power: 4 }, icon: '🧪' },
      { id: 'healing_potion', name: 'Healing Potion', description: 'Throw a healing potion', healing: 25, range: 4, cooldown: 3, currentCooldown: 0, icon: '🧴' },
      { id: 'explosion', name: 'Volatile Mix', description: 'Massive explosion', damage: 30, range: 3, cooldown: 4, currentCooldown: 0, areaOfEffect: 2, icon: '💥' },
    ]
  },
  Bard: {
    description: 'Musical butterflies whose songs inspire allies and demoralize foes.',
    baseStats: { magic: 9, hp: 70, speed: 11, luck: 14 },
    icon: '🎵',
    color: '#ec4899',
    abilities: [
      { id: 'inspiring_song', name: 'Inspiring Song', description: 'Boost ally stats', range: 4, cooldown: 3, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'bless', duration: 3, power: 4 }, icon: '🎶' },
      { id: 'discordant_note', name: 'Discordant Note', description: 'Damage and confuse', damage: 14, range: 4, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'curse', duration: 2, power: 3 }, icon: '🎸' },
      { id: 'lullaby', name: 'Lullaby', description: 'Put enemies to sleep', range: 3, cooldown: 5, currentCooldown: 0, areaOfEffect: 1, statusEffect: { type: 'stun', duration: 2, power: 1 }, icon: '😴' },
    ]
  },
  Monk: {
    description: 'Disciplined martial artists with powerful combo attacks.',
    baseStats: { attack: 12, hp: 85, speed: 13, defense: 9 },
    icon: '👊',
    color: '#f97316',
    abilities: [
      { id: 'flurry', name: 'Flurry of Blows', description: 'Rapid strikes', damage: 24, range: 1, cooldown: 1, currentCooldown: 0, icon: '👊' },
      { id: 'ki_blast', name: 'Ki Blast', description: 'Ranged energy attack', damage: 16, range: 4, cooldown: 2, currentCooldown: 0, icon: '🔮' },
      { id: 'meditation', name: 'Meditation', description: 'Restore HP and cleanse', healing: 20, range: 0, cooldown: 4, currentCooldown: 0, icon: '🧘' },
    ]
  },
  Warlock: {
    description: 'Dark pact-makers with devastating but risky powers.',
    baseStats: { magic: 16, hp: 50, attack: 6, luck: 8 },
    icon: '😈',
    color: '#7c3aed',
    abilities: [
      { id: 'eldritch_blast', name: 'Eldritch Blast', description: 'Pure dark energy', damage: 24, range: 5, cooldown: 0, currentCooldown: 0, icon: '🌀' },
      { id: 'hex', name: 'Hex', description: 'Curse that amplifies damage', range: 5, cooldown: 3, currentCooldown: 0, statusEffect: { type: 'curse', duration: 4, power: 6 }, icon: '🔮' },
      { id: 'soul_burn', name: 'Soul Burn', description: 'Sacrifice HP for massive damage', damage: 40, range: 4, cooldown: 4, currentCooldown: 0, icon: '🔥' },
    ]
  },
};

export function getClassAbilities(butterflyClass: ButterflyClass): Ability[] {
  return CLASS_DATA[butterflyClass].abilities.map(a => ({ ...a, currentCooldown: 0 }));
}

export function getClassStats(butterflyClass: ButterflyClass): Partial<Stats> {
  return CLASS_DATA[butterflyClass].baseStats;
}
