import { Region, Plant, PlantType, RegionKey } from './types';

// ════════════════════════════════════════════════════════════════
// REGIONS - Each with unique seeds, butterflies, and traits
// ════════════════════════════════════════════════════════════════

export const REGIONS: Record<RegionKey, Region> = {
  jardim_encantado: {
    key: 'jardim_encantado',
    name: 'Jardim Encantado',
    desc: 'Um jardim mágico repleto de flores luminosas e borboletas encantadas. Perfeito para iniciantes.',
    icon: '🌸',
    duration: 30000,
    nectarCost: 10,
    dangerLevel: 1,
    deathChance: 0.02,
    butterflyChance: 0.35,
    seedChance: 0.5,
    seeds: ['rosa_mistica', 'lirio_lunar'],
    exclusiveTraits: ['pétalas_brilhantes', 'aura_floral', 'asas_perfumadas'],
    exclusiveColors: ['rosa_encantado', 'lavanda_magica', 'verde_primavera'],
    enemyTypes: ['pulgao_comum', 'abelha_agressiva', 'vespa_jardim'],
    bossName: 'Rainha das Abelhas',
    bossIcon: '🐝',
    floorCount: 3,
    background: 'linear-gradient(135deg, #fce4ec 0%, #f8bbd9 50%, #e1bee7 100%)'
  },
  
  floresta_sombria: {
    key: 'floresta_sombria',
    name: 'Floresta Sombria',
    desc: 'Uma floresta densa e misteriosa onde a luz mal penetra. Criaturas das sombras espreitam.',
    icon: '🌲',
    duration: 45000,
    nectarCost: 25,
    dangerLevel: 3,
    deathChance: 0.08,
    butterflyChance: 0.25,
    seedChance: 0.4,
    seeds: ['orquidea_sombria', 'cogumelo_brilhante'],
    exclusiveTraits: ['visao_noturna', 'camuflagem_sombria', 'asas_silenciosas'],
    exclusiveColors: ['negro_profundo', 'roxo_noturno', 'verde_musgo'],
    enemyTypes: ['aranha_sombria', 'morcego_faminto', 'fungo_ambulante'],
    bossName: 'Aranha Matriarca',
    bossIcon: '🕷️',
    floorCount: 4,
    background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)'
  },
  
  caverna_cristalina: {
    key: 'caverna_cristalina',
    name: 'Caverna Cristalina',
    desc: 'Cavernas profundas repletas de cristais mágicos que brilham com luz própria.',
    icon: '💎',
    duration: 60000,
    nectarCost: 40,
    dangerLevel: 4,
    deathChance: 0.12,
    butterflyChance: 0.2,
    seedChance: 0.35,
    seeds: ['flor_cristal'],
    exclusiveTraits: ['corpo_cristalino', 'reflexo_prismatico', 'asas_diamante'],
    exclusiveColors: ['cristal_puro', 'ametista', 'safira', 'rubi'],
    enemyTypes: ['golem_cristal', 'morcego_gem', 'serpente_mineral'],
    bossName: 'Guardião de Cristal',
    bossIcon: '💠',
    floorCount: 5,
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #6B8DD6 100%)'
  },
  
  pantano_mistico: {
    key: 'pantano_mistico',
    name: 'Pântano Místico',
    desc: 'Um pântano envolto em névoa mística onde criaturas ancestrais habitam.',
    icon: '🌿',
    duration: 50000,
    nectarCost: 30,
    dangerLevel: 3,
    deathChance: 0.1,
    butterflyChance: 0.3,
    seedChance: 0.45,
    seeds: ['lotus_pantano', 'cogumelo_brilhante'],
    exclusiveTraits: ['resistencia_toxinas', 'guelras_asas', 'bioluminescencia'],
    exclusiveColors: ['verde_toxico', 'azul_pantano', 'marrom_lama'],
    enemyTypes: ['sapo_venenoso', 'sanguessuga_gigante', 'planta_carnivora'],
    bossName: 'Hidra do Pântano',
    bossIcon: '🐉',
    floorCount: 4,
    background: 'linear-gradient(135deg, #134e5e 0%, #2d5016 50%, #1a4314 100%)'
  },
  
  montanha_celeste: {
    key: 'montanha_celeste',
    name: 'Montanha Celeste',
    desc: 'Picos altíssimos que tocam as nuvens, lar de criaturas divinas e ventos poderosos.',
    icon: '⛰️',
    duration: 75000,
    nectarCost: 60,
    dangerLevel: 5,
    deathChance: 0.15,
    butterflyChance: 0.15,
    seedChance: 0.3,
    seeds: ['flor_celestial'],
    exclusiveTraits: ['asas_celestiais', 'resistencia_altitude', 'bencao_divina'],
    exclusiveColors: ['branco_celestial', 'dourado_divino', 'azul_celeste'],
    enemyTypes: ['aguia_tempestade', 'elemental_ar', 'grifo_jovem'],
    bossName: 'Fênix Ancestral',
    bossIcon: '🔥',
    floorCount: 5,
    background: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 50%, #ffecd2 100%)'
  },
  
  ruinas_antigas: {
    key: 'ruinas_antigas',
    name: 'Ruínas Antigas',
    desc: 'Ruínas de uma civilização perdida, repletas de armadilhas e tesouros esquecidos.',
    icon: '🏛️',
    duration: 90000,
    nectarCost: 80,
    dangerLevel: 6,
    deathChance: 0.2,
    butterflyChance: 0.4,
    seedChance: 0.5,
    seeds: ['hera_antiga', 'rosa_mistica', 'orquidea_sombria'],
    exclusiveTraits: ['conhecimento_ancestral', 'resistencia_magica', 'longevidade'],
    exclusiveColors: ['dourado_antigo', 'bronze_patina', 'jade_imperial'],
    enemyTypes: ['esqueleto_guardiao', 'armadilha_animada', 'fantasma_guardiao'],
    bossName: 'Imperador Lich',
    bossIcon: '💀',
    floorCount: 6,
    background: 'linear-gradient(135deg, #3c1053 0%, #ad5389 50%, #d4a373 100%)'
  }
};

// ════════════════════════════════════════════════════════════════
// PLANTS - Grown from seeds found in regions
// ════════════════════════════════════════════════════════════════

export const PLANTS: Record<PlantType, Plant> = {
  rosa_mistica: {
    type: 'rosa_mistica',
    name: 'Rosa Mística',
    icon: '🌹',
    growTime: 60000,
    nectarYield: 15,
    nectarType: 'basic',
    region: 'jardim_encantado',
    description: 'Uma rosa encantada que produz néctar doce e perfumado.'
  },
  
  lirio_lunar: {
    type: 'lirio_lunar',
    name: 'Lírio Lunar',
    icon: '🌷',
    growTime: 90000,
    nectarYield: 25,
    nectarType: 'premium',
    region: 'jardim_encantado',
    description: 'Floresce apenas sob a luz da lua, produzindo néctar prateado.'
  },
  
  orquidea_sombria: {
    type: 'orquidea_sombria',
    name: 'Orquídea Sombria',
    icon: '🌺',
    growTime: 120000,
    nectarYield: 30,
    nectarType: 'premium',
    region: 'floresta_sombria',
    description: 'Uma orquídea negra que brilha fracamente no escuro.'
  },
  
  flor_cristal: {
    type: 'flor_cristal',
    name: 'Flor de Cristal',
    icon: '💎',
    growTime: 180000,
    nectarYield: 50,
    nectarType: 'mythic',
    region: 'caverna_cristalina',
    description: 'Uma flor feita de cristal puro que produz néctar raro.'
  },
  
  lotus_pantano: {
    type: 'lotus_pantano',
    name: 'Lótus do Pântano',
    icon: '🪷',
    growTime: 100000,
    nectarYield: 20,
    nectarType: 'basic',
    region: 'pantano_mistico',
    description: 'Cresce nas águas escuras do pântano, resistente a toxinas.'
  },
  
  flor_celestial: {
    type: 'flor_celestial',
    name: 'Flor Celestial',
    icon: '✨',
    growTime: 240000,
    nectarYield: 75,
    nectarType: 'mythic',
    region: 'montanha_celeste',
    description: 'Uma flor divina que só cresce nos picos mais altos.'
  },
  
  hera_antiga: {
    type: 'hera_antiga',
    name: 'Hera Antiga',
    icon: '🌿',
    growTime: 150000,
    nectarYield: 35,
    nectarType: 'premium',
    region: 'ruinas_antigas',
    description: 'Uma planta milenar que absorveu a magia das ruínas.'
  },
  
  cogumelo_brilhante: {
    type: 'cogumelo_brilhante',
    name: 'Cogumelo Brilhante',
    icon: '🍄',
    growTime: 45000,
    nectarYield: 10,
    nectarType: 'basic',
    region: 'floresta_sombria',
    description: 'Um cogumelo fosforescente que ilumina a escuridão.'
  }
};

// ════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ════════════════════════════════════════════════════════════════

export function getRegionExclusiveTraits(regionKey: RegionKey): string[] {
  return REGIONS[regionKey].exclusiveTraits;
}

export function getRegionExclusiveColors(regionKey: RegionKey): string[] {
  return REGIONS[regionKey].exclusiveColors;
}

export function getRandomSeedFromRegion(regionKey: RegionKey): PlantType | null {
  const region = REGIONS[regionKey];
  if (region.seeds.length === 0) return null;
  return region.seeds[Math.floor(Math.random() * region.seeds.length)];
}

export function getRegionColor(regionKey: RegionKey): string {
  const colors: Record<RegionKey, string> = {
    jardim_encantado: '#fce4ec',
    floresta_sombria: '#1a1a2e',
    caverna_cristalina: '#667eea',
    pantano_mistico: '#134e5e',
    montanha_celeste: '#a8edea',
    ruinas_antigas: '#3c1053'
  };
  return colors[regionKey];
}

export function getRegionTextColor(regionKey: RegionKey): string {
  const darkRegions: RegionKey[] = ['floresta_sombria', 'pantano_mistico', 'ruinas_antigas'];
  return darkRegions.includes(regionKey) ? '#ffffff' : '#1a1a1a';
}

export function isRegionUnlocked(regionKey: RegionKey, completedRegions: RegionKey[]): boolean {
  const unlockRequirements: Record<RegionKey, RegionKey | null> = {
    jardim_encantado: null, // Always unlocked
    floresta_sombria: 'jardim_encantado',
    caverna_cristalina: 'floresta_sombria',
    pantano_mistico: 'floresta_sombria',
    montanha_celeste: 'caverna_cristalina',
    ruinas_antigas: 'montanha_celeste'
  };
  
  const required = unlockRequirements[regionKey];
  if (!required) return true;
  return completedRegions.includes(required);
}
