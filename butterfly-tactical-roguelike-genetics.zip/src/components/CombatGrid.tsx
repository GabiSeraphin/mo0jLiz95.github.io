import { CombatState, CombatUnit, Position, Ability } from '../types';
import { CLASS_DATA } from '../classes';
import { REGIONS, RegionTile } from '../config/regions.config';

// ════════════════════════════════════════════════════════════════
// ABILITY BAR COMPONENT
// ════════════════════════════════════════════════════════════════
interface AbilityBarProps {
  abilities: Ability[];
  onSelect: (ability: Ability) => void;
  selectedAbility: Ability | null;
  unit: CombatUnit | null;
}

export function AbilityBar({ abilities, onSelect, selectedAbility, unit }: AbilityBarProps) {
  if (!unit || !abilities.length) return null;
  
  return (
    <div className="flex flex-wrap gap-2 p-3 bg-gray-800/80 rounded-lg">
      <div className="w-full text-sm text-gray-400 mb-1">Habilidades:</div>
      {abilities.map((ability, i) => {
        const onCooldown = unit.cooldowns[ability.name] > 0;
        const isSelected = selectedAbility?.name === ability.name;
        
        return (
          <button
            key={i}
            onClick={() => !onCooldown && onSelect(ability)}
            disabled={onCooldown}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              isSelected 
                ? 'bg-yellow-600 text-white ring-2 ring-yellow-400' 
                : onCooldown
                  ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                  : 'bg-indigo-600 text-white hover:bg-indigo-500'
            }`}
            title={`${ability.description}\nDano: ${ability.damage || 0} | Alcance: ${ability.range} | Cooldown: ${ability.cooldown}`}
          >
            <div className="flex items-center gap-1">
              <span>{ability.name}</span>
              {onCooldown && (
                <span className="text-xs bg-gray-600 px-1 rounded">
                  {unit.cooldowns[ability.name]}🔄
                </span>
              )}
            </div>
            <div className="text-xs opacity-75 mt-0.5">
              {ability.damage ? `⚔️${ability.damage}` : '✨'} | 📏{ability.range}
            </div>
          </button>
        );
      })}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// COMBAT LOG COMPONENT
// ════════════════════════════════════════════════════════════════
interface CombatLogProps {
  messages: string[];
}

export function CombatLog({ messages }: CombatLogProps) {
  return (
    <div className="bg-gray-900/80 rounded-lg p-3 max-h-48 overflow-y-auto">
      <div className="text-sm text-gray-400 mb-2">📜 Log de Combate:</div>
      <div className="space-y-1">
        {messages.slice(-10).map((msg, i) => (
          <div key={i} className="text-xs text-gray-300 border-l-2 border-indigo-500 pl-2">
            {msg}
          </div>
        ))}
        {messages.length === 0 && (
          <div className="text-xs text-gray-500 italic">Nenhuma ação ainda...</div>
        )}
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// COMBAT GRID COMPONENT
// ════════════════════════════════════════════════════════════════

interface Props {
  state: CombatState;
  validMoves: Position[];
  validTargets: Position[];
  onTileClick: (pos: Position) => void;
  onUnitClick: (unit: CombatUnit) => void;
  regionId?: string;
  tileGrid?: RegionTile[][];
}

export function CombatGrid({ state, validMoves, validTargets, onTileClick, onUnitClick, regionId = 'jardim_encantado', tileGrid }: Props) {
  const region = REGIONS[regionId];
  
  const getTileContent = (x: number, y: number): RegionTile => {
    // Use provided tile grid if available
    if (tileGrid && tileGrid[y] && tileGrid[y][x]) {
      return tileGrid[y][x];
    }
    
    // Fallback - find from region tiles based on position seed
    if (region && region.tiles) {
      const seed = (x * 17 + y * 31) % 100;
      const totalWeight = region.tiles.reduce((sum, t) => sum + t.spawnWeight, 0);
      let threshold = (seed / 100) * totalWeight;
      
      for (const tile of region.tiles) {
        threshold -= tile.spawnWeight;
        if (threshold <= 0) {
          return tile;
        }
      }
      return region.tiles[0];
    }
    
    // Ultimate fallback
    return {
      id: 'empty',
      name: 'Vazio',
      emoji: '',
      color: '#2d2d44',
      walkable: true,
      spawnWeight: 100
    };
  };
  
  const getTileStyle = (x: number, y: number) => {
    const tile = state.grid[y][x];
    const tileContent = getTileContent(x, y);
    
    const isValidMove = validMoves.some(m => m.x === x && m.y === y);
    const isValidTarget = validTargets.some(t => t.x === x && t.y === y);
    const isSelected = state.selectedUnit?.position.x === x && state.selectedUnit?.position.y === y;
    
    let baseStyle: React.CSSProperties = {
      backgroundColor: tileContent.color || '#2d2d44',
      transition: 'all 0.2s',
    };
    
    if (isSelected) {
      baseStyle.boxShadow = '0 0 0 3px #facc15';
    } else if (isValidTarget) {
      baseStyle.boxShadow = '0 0 0 2px #ef4444';
      baseStyle.backgroundColor = 'rgba(127, 29, 29, 0.5)';
    } else if (isValidMove) {
      baseStyle.boxShadow = '0 0 0 2px #22c55e';
      baseStyle.backgroundColor = 'rgba(20, 83, 45, 0.5)';
    }
    
    if (tile) {
      baseStyle.borderBottom = tile.isPlayer ? '3px solid #60a5fa' : '3px solid #f87171';
    }
    
    return baseStyle;
  };
  
  const renderUnit = (unit: CombatUnit) => {
    const stats = unit.butterfly?.stats || unit.enemy?.stats;
    if (!stats || stats.hp <= 0) return null;
    
    const hpPercent = (stats.hp / stats.maxHp) * 100;
    const isPlayer = unit.isPlayer;
    
    return (
      <div 
        className={`absolute inset-1 flex flex-col items-center justify-center cursor-pointer transition-transform hover:scale-110 ${
          unit.hasActed ? 'opacity-60' : ''
        }`}
        onClick={(e) => {
          e.stopPropagation();
          onUnitClick(unit);
        }}
      >
        {/* Unit icon */}
        <div className={`text-2xl ${isPlayer ? '' : 'grayscale-0'}`} style={{ filter: isPlayer ? 'none' : 'drop-shadow(0 0 3px #ff0000)' }}>
          {unit.butterfly ? CLASS_DATA[unit.butterfly.class].icon : unit.enemy?.icon}
        </div>
        
        {/* HP bar */}
        <div className="absolute -bottom-0 left-0 right-0 h-1 bg-gray-800 rounded">
          <div 
            className="h-full rounded transition-all"
            style={{ 
              width: `${hpPercent}%`,
              backgroundColor: isPlayer ? '#22c55e' : '#ef4444'
            }}
          />
        </div>
        
        {/* Status effects */}
        {unit.activeEffects.length > 0 && (
          <div className="absolute -top-2 left-0 right-0 flex justify-center gap-0.5">
            {unit.activeEffects.slice(0, 3).map((ae, i) => {
              const icons: Record<string, string> = {
                poison: '☠️', burn: '🔥', freeze: '❄️', stun: '💫',
                bless: '✨', curse: '🌑', regen: '💚', haste: '⚡', slow: '🐌'
              };
              return <span key={i} className="text-xs">{icons[ae.type]}</span>;
            })}
          </div>
        )}
        
        {/* Player indicator */}
        {isPlayer && (
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-2 h-2 rounded-full bg-blue-400" />
        )}
      </div>
    );
  };
  
  return (
    <div 
      className="inline-block p-3 rounded-lg shadow-2xl"
      style={{ 
        backgroundColor: region?.backgroundColor || '#1a1a2e',
        border: `2px solid ${region?.ambientColor || '#6b5b95'}`
      }}
    >
      {/* Region name header */}
      <div className="text-center mb-2 pb-2 border-b border-white/20">
        <span className="text-lg mr-2">{region?.icon || '🗺️'}</span>
        <span className="font-bold text-white">{region?.namePt || region?.name || 'Região Desconhecida'}</span>
      </div>
      
      {/* Ambient particles */}
      <div className="relative">
        {region?.particleEmoji && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
            {region.particleEmoji.map((particle: string, i: number) => (
              <span 
                key={i}
                className="absolute animate-bounce opacity-50"
                style={{
                  left: `${(i * 27) % 100}%`,
                  top: `${(i * 17) % 100}%`,
                  animationDelay: `${i * 0.5}s`,
                  animationDuration: `${2 + i * 0.3}s`
                }}
              >
                {particle}
              </span>
            ))}
          </div>
        )}
        
        <div 
          className="grid gap-0.5 relative z-0"
          style={{ gridTemplateColumns: `repeat(10, 1fr)` }}
        >
          {state.grid.map((row, y) => 
            row.map((tile, x) => {
              const tileContent = getTileContent(x, y);
              return (
                <div
                  key={`${x}-${y}`}
                  className="relative w-12 h-12 rounded cursor-pointer flex items-center justify-center"
                  style={getTileStyle(x, y)}
                  onClick={() => onTileClick({ x, y })}
                  title={`${tileContent.name}${tileContent.effect ? ` - ${tileContent.effect.message}` : ''}`}
                >
                  {/* Tile decoration */}
                  {!tile && tileContent.emoji && (
                    <span className="text-lg opacity-60">{tileContent.emoji}</span>
                  )}
                  
                  {/* Unit */}
                  {tile && renderUnit(tile)}
                </div>
              );
            })
          )}
        </div>
      </div>
      
      {/* Turn indicator */}
      <div className="mt-2 pt-2 border-t border-white/20 text-center text-sm">
        <span className="text-gray-400">Turno {state.turn} • </span>
        <span className={state.phase === 'player' ? 'text-blue-400' : 'text-red-400'}>
          {state.phase === 'player' ? '🦋 Sua vez' : '👹 Turno inimigo'}
        </span>
      </div>
      
      {/* Tile legend */}
      {region && (
        <div className="mt-2 pt-2 border-t border-white/20">
          <div className="text-xs text-gray-400 mb-1">Terrenos:</div>
          <div className="flex flex-wrap gap-1">
            {region.tiles.filter(t => t.effect).slice(0, 5).map(t => (
              <span 
                key={t.id} 
                className="text-xs px-1 py-0.5 rounded"
                style={{ backgroundColor: t.color, color: '#fff' }}
                title={t.effect?.message}
              >
                {t.emoji} {t.name}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
