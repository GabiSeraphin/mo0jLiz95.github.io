import { DungeonRoom } from '../types';
import { getRoomIcon } from '../dungeon';

interface Props {
  rooms: DungeonRoom[];
  currentRoomId: string;
  onRoomSelect: (room: DungeonRoom) => void;
}

export function DungeonMap({ rooms, currentRoomId, onRoomSelect }: Props) {
  const currentRoom = rooms.find(r => r.id === currentRoomId);
  const accessibleRooms = currentRoom?.connections || [];
  
  // Calculate positions for visual layout
  const getLayerForRoom = (roomId: string): number => {
    if (roomId === 'start') return 0;
    if (roomId === 'boss') return 4;
    const idx = parseInt(roomId.split('-')[1]) || 0;
    return Math.floor((idx - 1) / 2) + 1;
  };
  
  return (
    <div className="relative bg-stone-900/50 rounded-xl p-6 min-h-[400px]">
      <h3 className="text-xl font-bold mb-4">🗺️ Mapa da Dungeon</h3>
      
      {/* Room nodes */}
      <div className="flex justify-between items-center gap-4">
        {[0, 1, 2, 3, 4].map(layer => {
          const layerRooms = rooms.filter(r => getLayerForRoom(r.id) === layer);
          
          return (
            <div key={layer} className="flex flex-col gap-4 items-center">
              {layerRooms.map(room => {
                const isCurrent = room.id === currentRoomId;
                const isAccessible = accessibleRooms.includes(room.id);
                const isCompleted = room.completed;
                
                return (
                  <button
                    key={room.id}
                    onClick={() => isAccessible && !room.completed && onRoomSelect(room)}
                    disabled={!isAccessible || room.completed}
                    className={`relative w-16 h-16 rounded-lg flex items-center justify-center text-2xl transition-all
                      ${isCurrent 
                        ? 'bg-yellow-600 ring-4 ring-yellow-400 animate-pulse' 
                        : isCompleted
                          ? 'bg-green-800 opacity-60'
                          : isAccessible
                            ? 'bg-purple-700 hover:bg-purple-600 cursor-pointer hover:scale-110'
                            : 'bg-gray-800 opacity-40 cursor-not-allowed'
                      }
                    `}
                  >
                    {getRoomIcon(room.type)}
                    
                    {/* Completed checkmark */}
                    {isCompleted && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-xs">
                        ✓
                      </div>
                    )}
                    
                    {/* Current marker */}
                    {isCurrent && (
                      <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-xs">
                        📍
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>
      
      {/* Connection lines - simplified visual */}
      <div className="mt-4 flex justify-center">
        <div className="text-purple-400 text-sm">
          → Selecione uma sala acessível para continuar →
        </div>
      </div>
      
      {/* Legend */}
      <div className="mt-6 flex flex-wrap gap-4 text-sm">
        <span>⚔️ Combate</span>
        <span>💀 Elite</span>
        <span>👑 Chefe</span>
        <span>🏕️ Descanso</span>
        <span>🛒 Loja</span>
        <span>❓ Mistério</span>
        <span>💰 Tesouro</span>
      </div>
    </div>
  );
}
