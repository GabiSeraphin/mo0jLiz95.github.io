import { Butterfly } from '../types';
import { CLASS_DATA } from '../classes';

interface Props {
  butterfly: Butterfly;
  selected?: boolean;
  onClick?: () => void;
  compact?: boolean;
  showDetails?: boolean;
}

const PERSONALITY_COLORS: Record<string, string> = {
  curioso: 'bg-blue-600',
  corajoso: 'bg-red-600',
  brincalhao: 'bg-yellow-600',
  sabio: 'bg-purple-600',
  timido: 'bg-gray-600',
  agressivo: 'bg-orange-600'
};

export function ButterflyCard({ butterfly, selected, onClick, compact, showDetails }: Props) {
  const classData = CLASS_DATA[butterfly.class];
  const hpPercent = (butterfly.stats.hp / butterfly.stats.maxHp) * 100;
  
  if (compact) {
    return (
      <div
        onClick={onClick}
        className={`p-2 rounded-lg cursor-pointer transition-all ${
          selected ? 'ring-2 ring-yellow-400 bg-purple-900' : 'bg-purple-800 hover:bg-purple-700'
        }`}
      >
        <div className="flex items-center gap-2">
          <span className="text-2xl">{classData.icon}</span>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm truncate">{butterfly.name}</div>
            <div className="text-xs text-purple-300">Lv.{butterfly.level} {butterfly.class}</div>
            <div className="flex gap-1 mt-1">
              <span className="text-xs">{butterfly.gender === 'macho' ? '♂' : '♀'}</span>
              <span className={`text-xs px-1 rounded ${PERSONALITY_COLORS[butterfly.personality]}`}>
                {butterfly.personality.slice(0, 3)}
              </span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs">❤️ {butterfly.stats.hp}/{butterfly.stats.maxHp}</div>
            {butterfly.isInbred && <span className="text-xs text-red-400">⚠️</span>}
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      onClick={onClick}
      className={`relative p-4 rounded-xl cursor-pointer transition-all transform hover:scale-105 ${
        selected ? 'ring-4 ring-yellow-400 shadow-lg shadow-yellow-400/30' : 'hover:ring-2 hover:ring-purple-400'
      } ${butterfly.onAdventure ? 'opacity-50' : ''}`}
      style={{
        background: `linear-gradient(135deg, ${butterfly.appearance.primaryColor}40, ${butterfly.appearance.secondaryColor}40)`,
        borderColor: butterfly.appearance.primaryColor
      }}
    >
      {/* On Adventure Badge */}
      {butterfly.onAdventure && (
        <div className="absolute top-2 right-2 px-2 py-1 bg-blue-600 rounded text-xs">
          🗺️ Em Aventura
        </div>
      )}
      
      {/* Glow effect for special butterflies */}
      {butterfly.appearance.glow && (
        <div 
          className="absolute inset-0 rounded-xl opacity-30 animate-pulse"
          style={{ boxShadow: `0 0 20px ${butterfly.appearance.glow}` }}
        />
      )}
      
      {/* Generation & Gender Badge */}
      <div className="absolute top-2 left-2 flex gap-1">
        <span className="px-2 py-0.5 bg-purple-700/80 rounded text-xs">G{butterfly.generation}</span>
        <span className={`px-2 py-0.5 rounded text-xs ${butterfly.gender === 'macho' ? 'bg-blue-700' : 'bg-pink-700'}`}>
          {butterfly.gender === 'macho' ? '♂' : '♀'}
        </span>
      </div>
      
      {/* Butterfly Visual */}
      <div className="flex justify-center mb-3 mt-6">
        <div 
          className="relative text-5xl transform hover:scale-110 transition-transform"
          style={{ 
            filter: butterfly.appearance.glow ? `drop-shadow(0 0 10px ${butterfly.appearance.glow})` : undefined,
            textShadow: `0 0 20px ${butterfly.appearance.primaryColor}`
          }}
        >
          🦋
          <div 
            className="absolute inset-0 opacity-50 mix-blend-overlay"
            style={{ backgroundColor: butterfly.appearance.primaryColor }}
          />
        </div>
      </div>
      
      {/* Header */}
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-bold text-lg">{butterfly.name}</h3>
          <div className="flex items-center gap-1 text-sm">
            <span style={{ color: classData.color }}>{classData.icon}</span>
            <span className="text-purple-300">{butterfly.class}</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-yellow-400 font-bold">Lv.{butterfly.level}</div>
          <span className={`text-xs px-1 rounded ${PERSONALITY_COLORS[butterfly.personality]}`}>
            {butterfly.personality}
          </span>
        </div>
      </div>
      
      {/* HP Bar */}
      <div className="mb-3">
        <div className="flex justify-between text-xs mb-1">
          <span>HP</span>
          <span>{butterfly.stats.hp}/{butterfly.stats.maxHp}</span>
        </div>
        <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full transition-all"
            style={{ 
              width: `${hpPercent}%`,
              backgroundColor: hpPercent > 50 ? '#22c55e' : hpPercent > 25 ? '#eab308' : '#ef4444'
            }}
          />
        </div>
      </div>
      
      {/* Stats Grid */}
      {showDetails && (
        <div className="grid grid-cols-3 gap-1 text-xs text-center mb-2">
          <div className="bg-black/20 rounded p-1">
            <div className="text-red-400">⚔️</div>
            <div>{butterfly.stats.attack}</div>
          </div>
          <div className="bg-black/20 rounded p-1">
            <div className="text-blue-400">🛡️</div>
            <div>{butterfly.stats.defense}</div>
          </div>
          <div className="bg-black/20 rounded p-1">
            <div className="text-purple-400">✨</div>
            <div>{butterfly.stats.magic}</div>
          </div>
        </div>
      )}
      
      {/* Mutations */}
      {butterfly.mutations.length > 0 && (
        <div className="flex gap-1 flex-wrap mt-2">
          {butterfly.mutations.slice(0, 3).map(m => (
            <span 
              key={m.id} 
              className="text-xs px-1 rounded bg-purple-700/50" 
              title={`${m.name}: ${m.description}`}
            >
              {m.icon}
            </span>
          ))}
          {butterfly.mutations.length > 3 && (
            <span className="text-xs text-purple-400">+{butterfly.mutations.length - 3}</span>
          )}
        </div>
      )}
      
      {/* Inbreeding Warning */}
      {butterfly.isInbred && (
        <div className="mt-2 text-xs text-red-400 flex items-center gap-1">
          <span>⚠️</span>
          <span>{butterfly.negativeTraits.length} defeito{butterfly.negativeTraits.length !== 1 ? 's' : ''}</span>
        </div>
      )}
    </div>
  );
}
