import { DungeonRoom, DungeonRun, Butterfly, RegionKey, PlantType } from './types';
import { REGIONS, PLANTS, getRandomSeedFromRegion } from './regions';
import { createButterfly } from './genetics';

const ROOM_TYPES: Array<{ type: DungeonRoom['type']; weight: number; minFloor: number }> = [
  { type: 'combat', weight: 35, minFloor: 1 },
  { type: 'elite', weight: 12, minFloor: 1 },
  { type: 'rest', weight: 12, minFloor: 1 },
  { type: 'shop', weight: 10, minFloor: 1 },
  { type: 'mystery', weight: 12, minFloor: 1 },
  { type: 'treasure', weight: 10, minFloor: 1 },
  { type: 'butterfly_encounter', weight: 9, minFloor: 1 }, // New room type for finding region butterflies
];

function weightedRandom<T extends { weight: number }>(items: T[]): T {
  const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
  let random = Math.random() * totalWeight;
  
  for (const item of items) {
    random -= item.weight;
    if (random <= 0) return item;
  }
  
  return items[items.length - 1];
}

export function getRoomIcon(type: DungeonRoom['type'], region?: RegionKey): string {
  const icons: Record<DungeonRoom['type'], string> = {
    combat: '⚔️',
    elite: '💀',
    boss: region ? REGIONS[region].bossIcon : '👑',
    rest: '🏕️',
    shop: '🛒',
    mystery: '❓',
    treasure: '💰',
    butterfly_encounter: '🦋'
  };
  return icons[type];
}

export function generateDungeon(floor: number, region: RegionKey): DungeonRoom[] {
  const rooms: DungeonRoom[] = [];
  const regionData = REGIONS[region];
  const roomCount = 6 + Math.min(floor, 5) + Math.floor(regionData.floorCount / 2);
  
  // Starting room
  rooms.push({
    id: 'start',
    type: 'combat',
    completed: true,
    available: true,
    icon: getRoomIcon('combat', region),
    connections: ['room-1'],
    position: { x: 0, y: 2 }
  });
  
  // Generate middle rooms in a branching pattern
  const layers = 3;
  const roomsPerLayer = Math.floor((roomCount - 2) / layers);
  let currentY = 0;
  
  for (let layer = 0; layer < layers; layer++) {
    const layerRooms = layer === layers - 1 ? roomCount - 2 - (roomsPerLayer * (layers - 1)) : roomsPerLayer;
    
    for (let r = 0; r < layerRooms; r++) {
      const roomId = `room-${rooms.length}`;
      const availableTypes = ROOM_TYPES.filter(t => t.minFloor <= floor && t.type !== 'boss');
      const roomType = weightedRandom(availableTypes).type;
      
      const connections: string[] = [];
      
      // Connect to next layer or boss
      if (layer < layers - 1) {
        const nextLayerStart = rooms.length + layerRooms - r;
        const nextLayerRooms = layer === layers - 2 ? roomCount - 2 - (roomsPerLayer * (layers - 1)) : roomsPerLayer;
        const connectTo = Math.min(2, nextLayerRooms);
        for (let c = 0; c < connectTo; c++) {
          const nextRoomIndex = nextLayerStart + (r + c) % nextLayerRooms;
          connections.push(`room-${nextRoomIndex}`);
        }
      } else {
        connections.push('boss');
      }
      
      rooms.push({
        id: roomId,
        type: roomType,
        completed: false,
        available: layer === 0, // First layer available from start
        icon: getRoomIcon(roomType, region),
        connections,
        position: { x: (layer + 1) * 2, y: r * 2 }
      });
      currentY++;
    }
  }
  
  // Boss room
  rooms.push({
    id: 'boss',
    type: 'boss',
    completed: false,
    available: false,
    icon: getRoomIcon('boss', region),
    connections: [],
    position: { x: (layers + 1) * 2, y: Math.floor(currentY / 2) }
  });
  
  // Fix connections for start room
  rooms[0].connections = rooms.slice(1, Math.min(3, rooms.length)).map(r => r.id);
  
  return rooms;
}

export function createDungeonRun(party: Butterfly[], floor: number = 1, region: RegionKey = 'jardim_encantado'): DungeonRun {
  return {
    floor,
    rooms: generateDungeon(floor, region),
    currentRoomId: 'start',
    party: party.map(b => ({ ...b, stats: { ...b.stats, hp: b.stats.maxHp } })),
    gold: 0,
    completedRooms: ['start'],
    region,
    foundSeeds: [],
    foundButterflies: []
  };
}

export function getRoomDescription(type: DungeonRoom['type'], region: RegionKey): string {
  const regionName = REGIONS[region].name;
  const descriptions: Record<DungeonRoom['type'], string> = {
    combat: `Criaturas hostis de ${regionName} bloqueiam seu caminho.`,
    elite: `Um inimigo poderoso de ${regionName} aguarda. Prepare-se para uma luta difícil!`,
    boss: `${REGIONS[region].bossName} guarda o coração de ${regionName}.`,
    rest: `Uma clareira pacífica em ${regionName} onde você pode curar suas feridas.`,
    shop: `Um mercador misterioso de ${regionName} oferece suas mercadorias.`,
    mystery: `Uma presença estranha paira no ar de ${regionName}...`,
    treasure: `Um baú antigo de ${regionName} brilha com promessas de riqueza.`,
    butterfly_encounter: `Uma borboleta rara nativa de ${regionName} aparece diante de você!`
  };
  return descriptions[type];
}

// ════════════════════════════════════════════════════════════════
// BUTTERFLY ENCOUNTER - Chance to capture region-exclusive butterflies
// ════════════════════════════════════════════════════════════════

export interface ButterflyEncounter {
  butterfly: Butterfly;
  captureChance: number;
  fleeChance: number;
}

export function generateButterflyEncounter(region: RegionKey): ButterflyEncounter {
  const regionButterfly = createButterfly({ region });
  const regionData = REGIONS[region];
  
  // Higher danger = harder to catch, but rarer traits
  const captureChance = Math.max(0.2, 0.6 - (regionData.dangerLevel * 0.08));
  const fleeChance = Math.min(0.5, 0.1 + (regionData.dangerLevel * 0.05));
  
  return {
    butterfly: regionButterfly,
    captureChance,
    fleeChance
  };
}

// ════════════════════════════════════════════════════════════════
// SEED REWARDS - Region-specific seeds from treasures
// ════════════════════════════════════════════════════════════════

export interface TreasureReward {
  gold: number;
  seeds: PlantType[];
  seedDescriptions: string[];
}

export function generateTreasureReward(region: RegionKey, floor: number): TreasureReward {
  const regionData = REGIONS[region];
  const baseGold = 30 + (floor * 10) + (regionData.dangerLevel * 15);
  const gold = baseGold + Math.floor(Math.random() * baseGold * 0.5);
  
  const seeds: PlantType[] = [];
  const seedDescriptions: string[] = [];
  
  // Chance to find seeds based on region
  if (Math.random() < regionData.seedChance) {
    const seed = getRandomSeedFromRegion(region);
    if (seed) {
      seeds.push(seed);
      const plantData = PLANTS[seed];
      seedDescriptions.push(`${plantData.icon} ${plantData.name}`);
    }
  }
  
  // Higher floors have chance for bonus seed
  if (floor > 2 && Math.random() < 0.3) {
    const seed = getRandomSeedFromRegion(region);
    if (seed && !seeds.includes(seed)) {
      seeds.push(seed);
      const plantData = PLANTS[seed];
      seedDescriptions.push(`${plantData.icon} ${plantData.name}`);
    }
  }
  
  return { gold, seeds, seedDescriptions };
}

// ════════════════════════════════════════════════════════════════
// MYSTERY EVENTS - Region-themed random events
// ════════════════════════════════════════════════════════════════

export interface MysteryEvent {
  title: string;
  description: string;
  choices: {
    text: string;
    effect: (run: DungeonRun) => { run: DungeonRun; message: string };
  }[];
}

const REGION_MYSTERY_EVENTS: Record<RegionKey, MysteryEvent[]> = {
  jardim_encantado: [
    {
      title: 'A Fonte das Flores',
      description: 'Uma fonte cercada de pétalas mágicas brilha com energia restauradora.',
      choices: [
        {
          text: 'Beber da fonte (cura total do grupo)',
          effect: (run) => {
            const healedParty = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: b.stats.maxHp } }));
            return { run: { ...run, party: healedParty }, message: '🌸 A água das flores restaura todo o grupo!' };
          }
        },
        {
          text: 'Coletar pétalas (+1 semente aleatória)',
          effect: (run) => {
            const seed = getRandomSeedFromRegion('jardim_encantado');
            if (seed) {
              return { run: { ...run, foundSeeds: [...run.foundSeeds, seed] }, message: `🌷 Você coletou sementes de ${PLANTS[seed].name}!` };
            }
            return { run, message: 'Não havia sementes para coletar.' };
          }
        }
      ]
    },
    {
      title: 'A Fada do Jardim',
      description: 'Uma pequena fada aparece entre as flores, oferecendo ajuda.',
      choices: [
        {
          text: 'Pedir bênção (+5 Sorte para todos)',
          effect: (run) => {
            const blessed = run.party.map(b => ({ ...b, stats: { ...b.stats, luck: b.stats.luck + 5 } }));
            return { run: { ...run, party: blessed }, message: '✨ A fada abençoa o grupo com sorte!' };
          }
        },
        {
          text: 'Pedir ajuda para encontrar borboletas',
          effect: (run) => {
            const butterfly = createButterfly({ region: 'jardim_encantado' });
            return { run: { ...run, foundButterflies: [...run.foundButterflies, butterfly] }, message: `🦋 A fada guia você até ${butterfly.name}!` };
          }
        }
      ]
    }
  ],
  
  floresta_sombria: [
    {
      title: 'O Cogumelo Brilhante',
      description: 'Um cogumelo gigante pulsa com luz misteriosa na escuridão.',
      choices: [
        {
          text: 'Comer o cogumelo (efeito aleatório)',
          effect: (run) => {
            if (Math.random() < 0.6) {
              const boosted = run.party.map(b => ({ ...b, stats: { ...b.stats, magic: b.stats.magic + 10 } }));
              return { run: { ...run, party: boosted }, message: '🍄 O cogumelo expande a mente! +10 Magia para todos!' };
            } else {
              const confused = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: Math.max(1, b.stats.hp - 15) } }));
              return { run: { ...run, party: confused }, message: '☠️ O cogumelo era venenoso! -15 HP para todos.' };
            }
          }
        },
        {
          text: 'Coletar esporos (+1 semente de cogumelo)',
          effect: (run) => {
            return { run: { ...run, foundSeeds: [...run.foundSeeds, 'cogumelo_brilhante'] }, message: '🍄 Você coletou esporos de Cogumelo Brilhante!' };
          }
        }
      ]
    },
    {
      title: 'A Aranha Tecelã',
      description: 'Uma aranha anciã oferece tecer proteção em troca de ouro.',
      choices: [
        {
          text: 'Pagar 40 de ouro (+10 Defesa para todos)',
          effect: (run) => {
            if (run.gold >= 40) {
              const protected_ = run.party.map(b => ({ ...b, stats: { ...b.stats, defense: b.stats.defense + 10 } }));
              return { run: { ...run, party: protected_, gold: run.gold - 40 }, message: '🕸️ A teia mágica protege o grupo!' };
            }
            return { run, message: 'Você não tem ouro suficiente!' };
          }
        },
        {
          text: 'Atacar a aranha (50% chance de 80 ouro)',
          effect: (run) => {
            if (Math.random() < 0.5) {
              return { run: { ...run, gold: run.gold + 80 }, message: '💰 Você derrotou a aranha e pegou seu tesouro!' };
            } else {
              const damaged = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: Math.max(1, b.stats.hp - 25) } }));
              return { run: { ...run, party: damaged }, message: '🕷️ A aranha contra-ataca! -25 HP para todos.' };
            }
          }
        }
      ]
    }
  ],
  
  caverna_cristalina: [
    {
      title: 'O Veio de Cristal',
      description: 'Cristais preciosos brilham nas paredes da caverna.',
      choices: [
        {
          text: 'Minerar cristais (+60 ouro)',
          effect: (run) => {
            return { run: { ...run, gold: run.gold + 60 }, message: '💎 Você extraiu cristais valiosos! +60 ouro!' };
          }
        },
        {
          text: 'Meditar entre os cristais (+8 Magia para todos)',
          effect: (run) => {
            const enlightened = run.party.map(b => ({ ...b, stats: { ...b.stats, magic: b.stats.magic + 8 } }));
            return { run: { ...run, party: enlightened }, message: '✨ A energia dos cristais flui através do grupo!' };
          }
        },
        {
          text: 'Procurar sementes raras',
          effect: (run) => {
            if (Math.random() < 0.7) {
              return { run: { ...run, foundSeeds: [...run.foundSeeds, 'flor_cristal'] }, message: '💎 Você encontrou uma semente de Flor de Cristal!' };
            }
            return { run: { ...run, gold: run.gold + 20 }, message: 'Não encontrou sementes, mas achou 20 de ouro.' };
          }
        }
      ]
    }
  ],
  
  pantano_mistico: [
    {
      title: 'O Lótus Flutuante',
      description: 'Uma flor de lótus gigante flutua nas águas escuras do pântano.',
      choices: [
        {
          text: 'Descansar na flor (cura 50% HP)',
          effect: (run) => {
            const healed = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: Math.min(b.stats.maxHp, b.stats.hp + Math.floor(b.stats.maxHp / 2)) } }));
            return { run: { ...run, party: healed }, message: '🪷 O lótus restaura parte da vida do grupo!' };
          }
        },
        {
          text: 'Coletar sementes de lótus',
          effect: (run) => {
            return { run: { ...run, foundSeeds: [...run.foundSeeds, 'lotus_pantano'] }, message: '🪷 Você coletou sementes de Lótus do Pântano!' };
          }
        },
        {
          text: 'Mergulhar nas águas (risco/recompensa)',
          effect: (run) => {
            if (Math.random() < 0.5) {
              const butterfly = createButterfly({ region: 'pantano_mistico' });
              return { run: { ...run, foundButterflies: [...run.foundButterflies, butterfly], gold: run.gold + 40 }, message: `🦋 Você encontrou ${butterfly.name} e 40 de ouro!` };
            } else {
              const damaged = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: Math.max(1, b.stats.hp - 20) } }));
              return { run: { ...run, party: damaged }, message: '🐊 Algo mordeu você! -20 HP para todos.' };
            }
          }
        }
      ]
    }
  ],
  
  montanha_celeste: [
    {
      title: 'O Santuário Celestial',
      description: 'Um pequeno santuário brilha no topo de um pico.',
      choices: [
        {
          text: 'Orar no santuário (bênção divina)',
          effect: (run) => {
            const blessed = run.party.map(b => ({ 
              ...b, 
              stats: { 
                ...b.stats, 
                hp: b.stats.maxHp,
                magic: b.stats.magic + 5,
                luck: b.stats.luck + 5
              } 
            }));
            return { run: { ...run, party: blessed }, message: '🙏 O santuário abençoa e cura todo o grupo!' };
          }
        },
        {
          text: 'Procurar flores celestiais',
          effect: (run) => {
            if (Math.random() < 0.5) {
              return { run: { ...run, foundSeeds: [...run.foundSeeds, 'flor_celestial'] }, message: '✨ Você encontrou uma rara semente de Flor Celestial!' };
            }
            return { run, message: 'As flores celestiais são muito raras para encontrar agora.' };
          }
        }
      ]
    },
    {
      title: 'O Ninho da Fênix',
      description: 'Você encontra um ninho com uma pena de fênix brilhante.',
      choices: [
        {
          text: 'Pegar a pena (+15% HP máximo para todos)',
          effect: (run) => {
            const empowered = run.party.map(b => ({ 
              ...b, 
              stats: { 
                ...b.stats, 
                maxHp: Math.floor(b.stats.maxHp * 1.15),
                hp: Math.floor(b.stats.hp * 1.15)
              } 
            }));
            return { run: { ...run, party: empowered }, message: '🔥 A essência da fênix fortalece o grupo!' };
          }
        },
        {
          text: 'Deixar a pena e pedir passagem segura',
          effect: (run) => {
            return { run: { ...run, gold: run.gold + 50 }, message: '🕊️ A fênix agradeça seu respeito e lhe dá 50 de ouro.' };
          }
        }
      ]
    }
  ],
  
  ruinas_antigas: [
    {
      title: 'A Biblioteca Perdida',
      description: 'Tomos antigos e pergaminhos mágicos preenchem esta sala esquecida.',
      choices: [
        {
          text: 'Estudar os tomos (+50 EXP para todos)',
          effect: (run) => {
            const learned = run.party.map(b => ({ ...b, exp: b.exp + 50 }));
            return { run: { ...run, party: learned }, message: '📚 Conhecimento ancestral flui para o grupo! +50 EXP!' };
          }
        },
        {
          text: 'Procurar tesouros escondidos (+80 ouro)',
          effect: (run) => {
            return { run: { ...run, gold: run.gold + 80 }, message: '💰 Você encontrou tesouros esquecidos! +80 ouro!' };
          }
        },
        {
          text: 'Procurar sementes antigas',
          effect: (run) => {
            const possibleSeeds: PlantType[] = ['hera_antiga', 'rosa_mistica', 'orquidea_sombria'];
            const seed = possibleSeeds[Math.floor(Math.random() * possibleSeeds.length)];
            return { run: { ...run, foundSeeds: [...run.foundSeeds, seed] }, message: `🌿 Você encontrou sementes de ${PLANTS[seed].name}!` };
          }
        }
      ]
    },
    {
      title: 'O Fantasma do Imperador',
      description: 'O espectro de um antigo governante aparece diante de você.',
      choices: [
        {
          text: 'Mostrar respeito (bênção ancestral)',
          effect: (run) => {
            const blessed = run.party.map(b => ({ 
              ...b, 
              stats: { 
                ...b.stats, 
                attack: b.stats.attack + 8,
                defense: b.stats.defense + 8
              } 
            }));
            return { run: { ...run, party: blessed }, message: '👻 O imperador abençoa seu grupo! +8 Ataque e Defesa!' };
          }
        },
        {
          text: 'Desafiá-lo para um teste',
          effect: (run) => {
            if (Math.random() < 0.6) {
              const butterfly = createButterfly({ region: 'ruinas_antigas' });
              return { 
                run: { ...run, foundButterflies: [...run.foundButterflies, butterfly], gold: run.gold + 100 }, 
                message: `👑 Você passou no teste! O imperador lhe dá ${butterfly.name} e 100 de ouro!` 
              };
            } else {
              const damaged = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: Math.max(1, b.stats.hp - 30) } }));
              return { run: { ...run, party: damaged }, message: '💀 Você falhou no teste! -30 HP para todos.' };
            }
          }
        }
      ]
    }
  ]
};

// Generic mystery events that can appear in any region
const GENERIC_MYSTERY_EVENTS: MysteryEvent[] = [
  {
    title: 'O Comerciante Errante',
    description: 'Um estranho comerciante oferece um negócio...',
    choices: [
      {
        text: 'Trocar 30 de ouro por cura total',
        effect: (run) => {
          if (run.gold >= 30) {
            const healedParty = run.party.map(b => ({ ...b, stats: { ...b.stats, hp: b.stats.maxHp } }));
            return { run: { ...run, party: healedParty, gold: run.gold - 30 }, message: '💚 O grupo foi completamente curado!' };
          }
          return { run, message: 'Você não tem ouro suficiente!' };
        }
      },
      {
        text: 'Apostar 50 de ouro (dobro ou nada)',
        effect: (run) => {
          if (run.gold >= 50) {
            if (Math.random() < 0.5) {
              return { run: { ...run, gold: run.gold + 50 }, message: '🎰 Você ganhou! +50 de ouro!' };
            } else {
              return { run: { ...run, gold: run.gold - 50 }, message: '💸 Você perdeu a aposta...' };
            }
          }
          return { run, message: 'Você não tem ouro suficiente para apostar!' };
        }
      },
      {
        text: 'Recusar e seguir em frente',
        effect: (run) => ({ run, message: 'O comerciante desaparece nas sombras.' })
      }
    ]
  },
  {
    title: 'O Espírito da Borboleta',
    description: 'Um espírito etéreo de borboleta aparece diante de você...',
    choices: [
      {
        text: 'Pedir sabedoria',
        effect: (run) => {
          const expBoost = run.party.map(b => ({ ...b, exp: b.exp + 30 }));
          return { run: { ...run, party: expBoost }, message: '📚 O espírito compartilha conhecimento antigo! +30 EXP para todos!' };
        }
      },
      {
        text: 'Pedir proteção',
        effect: (run) => {
          const protectedParty = run.party.map(b => ({ 
            ...b, 
            stats: { ...b.stats, defense: b.stats.defense + 8, maxHp: b.stats.maxHp + 15, hp: b.stats.hp + 15 } 
          }));
          return { run: { ...run, party: protectedParty }, message: '🛡️ Uma aura protetora envolve o grupo! +8 Defesa, +15 HP para todos!' };
        }
      },
      {
        text: 'Agradecer e partir',
        effect: (run) => {
          return { run: { ...run, gold: run.gold + 20 }, message: '✨ O espírito sorri e lhe dá 20 de ouro como lembrança.' };
        }
      }
    ]
  }
];

export function generateMysteryEvent(region: RegionKey): MysteryEvent {
  // 70% chance for region-specific event, 30% for generic
  const regionEvents = REGION_MYSTERY_EVENTS[region] || [];
  const useRegionEvent = regionEvents.length > 0 && Math.random() < 0.7;
  
  if (useRegionEvent) {
    return regionEvents[Math.floor(Math.random() * regionEvents.length)];
  }
  
  return GENERIC_MYSTERY_EVENTS[Math.floor(Math.random() * GENERIC_MYSTERY_EVENTS.length)];
}

// ════════════════════════════════════════════════════════════════
// BOSS REWARDS - Special rewards for defeating region bosses
// ════════════════════════════════════════════════════════════════

export interface BossReward {
  gold: number;
  exp: number;
  seeds: PlantType[];
  guaranteedButterfly: Butterfly;
  message: string;
}

export function generateBossReward(region: RegionKey, floor: number): BossReward {
  const regionData = REGIONS[region];
  
  // Boss always drops a region-exclusive butterfly
  const guaranteedButterfly = createButterfly({ region });
  
  // Gold and exp scale with danger level
  const gold = 100 + (floor * 30) + (regionData.dangerLevel * 40);
  const exp = 50 + (floor * 20) + (regionData.dangerLevel * 25);
  
  // Seeds from region
  const seeds: PlantType[] = [];
  regionData.seeds.forEach(seed => {
    if (Math.random() < 0.5) {
      seeds.push(seed);
    }
  });
  // Guarantee at least one seed
  if (seeds.length === 0 && regionData.seeds.length > 0) {
    seeds.push(regionData.seeds[0]);
  }
  
  return {
    gold,
    exp,
    seeds,
    guaranteedButterfly,
    message: `🏆 Você derrotou ${regionData.bossName}! Ganhou ${guaranteedButterfly.name} com traços exclusivos de ${regionData.name}!`
  };
}
