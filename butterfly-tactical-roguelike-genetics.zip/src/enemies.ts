import { Enemy, Ability, RegionKey, PlantType } from './types';
import { REGIONS } from './regions';

// ════════════════════════════════════════════════════════════════
// ENEMY TEMPLATES - Region-specific enemies
// ════════════════════════════════════════════════════════════════

interface EnemyTemplate {
  name: string;
  type: Enemy['type'];
  baseStats: { hp: number; attack: number; defense: number; magic: number; speed: number };
  abilities: Ability[];
  icon: string;
  description: string;
  expReward: number;
  regions: RegionKey[]; // Which regions this enemy can appear in
  seedDrop?: PlantType; // Chance to drop a seed
}

const ENEMY_TEMPLATES: EnemyTemplate[] = [
  // ═══════════════════════════════════
  // JARDIM ENCANTADO ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Abelha Agressiva',
    type: 'normal',
    baseStats: { hp: 35, attack: 10, defense: 5, magic: 3, speed: 10 },
    abilities: [
      { id: 'sting', name: 'Ferrão', description: 'Ferrão venenoso', damage: 12, range: 1, cooldown: 1, currentCooldown: 0, statusEffect: { type: 'poison', duration: 2, power: 3 }, icon: '🐝' }
    ],
    icon: '🐝',
    description: 'Uma abelha protetora do jardim.',
    expReward: 15,
    regions: ['jardim_encantado'],
    seedDrop: 'rosa_mistica'
  },
  {
    name: 'Pulgão Gigante',
    type: 'normal',
    baseStats: { hp: 50, attack: 6, defense: 8, magic: 2, speed: 5 },
    abilities: [
      { id: 'sap_drain', name: 'Drenar Seiva', description: 'Rouba vida', damage: 8, healing: 5, range: 1, cooldown: 0, currentCooldown: 0, icon: '🐛' }
    ],
    icon: '🐛',
    description: 'Um pulgão inchado que drena plantas.',
    expReward: 12,
    regions: ['jardim_encantado']
  },
  {
    name: 'Vespa do Jardim',
    type: 'normal',
    baseStats: { hp: 40, attack: 14, defense: 4, magic: 2, speed: 12 },
    abilities: [
      { id: 'dive_attack', name: 'Ataque de Mergulho', description: 'Ataque rápido', damage: 16, range: 2, cooldown: 1, currentCooldown: 0, icon: '🪰' }
    ],
    icon: '🪰',
    description: 'Uma vespa territorial e agressiva.',
    expReward: 18,
    regions: ['jardim_encantado']
  },
  
  // ═══════════════════════════════════
  // FLORESTA SOMBRIA ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Aranha Sombria',
    type: 'normal',
    baseStats: { hp: 45, attack: 14, defense: 4, magic: 5, speed: 11 },
    abilities: [
      { id: 'web_strike', name: 'Golpe de Teia', description: 'Ataque que desacelera', damage: 12, range: 2, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'slow', duration: 2, power: 3 }, icon: '🕷️' }
    ],
    icon: '🕷️',
    description: 'Predador silencioso das sombras.',
    expReward: 22,
    regions: ['floresta_sombria'],
    seedDrop: 'cogumelo_brilhante'
  },
  {
    name: 'Morcego Faminto',
    type: 'normal',
    baseStats: { hp: 35, attack: 12, defense: 3, magic: 4, speed: 14 },
    abilities: [
      { id: 'blood_drain', name: 'Drenar Sangue', description: 'Roubo de vida', damage: 10, healing: 8, range: 1, cooldown: 1, currentCooldown: 0, icon: '🦇' }
    ],
    icon: '🦇',
    description: 'Um morcego que caça na escuridão.',
    expReward: 18,
    regions: ['floresta_sombria']
  },
  {
    name: 'Fungo Ambulante',
    type: 'normal',
    baseStats: { hp: 60, attack: 8, defense: 10, magic: 8, speed: 3 },
    abilities: [
      { id: 'spore_cloud', name: 'Nuvem de Esporos', description: 'Envenena área', damage: 8, range: 2, cooldown: 2, currentCooldown: 0, areaOfEffect: 1, statusEffect: { type: 'poison', duration: 3, power: 4 }, icon: '🍄' }
    ],
    icon: '🍄',
    description: 'Um cogumelo vivo e tóxico.',
    expReward: 20,
    regions: ['floresta_sombria'],
    seedDrop: 'orquidea_sombria'
  },
  
  // ═══════════════════════════════════
  // CAVERNA CRISTALINA ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Golem de Cristal',
    type: 'normal',
    baseStats: { hp: 80, attack: 10, defense: 16, magic: 6, speed: 3 },
    abilities: [
      { id: 'crystal_slam', name: 'Pancada de Cristal', description: 'Golpe pesado', damage: 16, range: 1, cooldown: 0, currentCooldown: 0, icon: '💎' }
    ],
    icon: '💎',
    description: 'Uma construção de cristal animado.',
    expReward: 25,
    regions: ['caverna_cristalina'],
    seedDrop: 'flor_cristal'
  },
  {
    name: 'Morcego de Gema',
    type: 'normal',
    baseStats: { hp: 40, attack: 12, defense: 8, magic: 10, speed: 12 },
    abilities: [
      { id: 'gem_shard', name: 'Fragmento de Gema', description: 'Projétil de cristal', damage: 14, range: 3, cooldown: 1, currentCooldown: 0, icon: '💠' }
    ],
    icon: '🦇',
    description: 'Morcego com corpo cristalizado.',
    expReward: 22,
    regions: ['caverna_cristalina']
  },
  {
    name: 'Serpente Mineral',
    type: 'normal',
    baseStats: { hp: 55, attack: 14, defense: 12, magic: 4, speed: 8 },
    abilities: [
      { id: 'constrict', name: 'Constringir', description: 'Aperta e atordoa', damage: 12, range: 1, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'stun', duration: 1, power: 1 }, icon: '🐍' }
    ],
    icon: '🐍',
    description: 'Serpente feita de minerais vivos.',
    expReward: 24,
    regions: ['caverna_cristalina']
  },
  
  // ═══════════════════════════════════
  // PÂNTANO MÍSTICO ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Sapo Venenoso',
    type: 'normal',
    baseStats: { hp: 50, attack: 8, defense: 6, magic: 12, speed: 6 },
    abilities: [
      { id: 'toxic_spit', name: 'Cuspe Tóxico', description: 'Veneno à distância', damage: 10, range: 3, cooldown: 1, currentCooldown: 0, statusEffect: { type: 'poison', duration: 3, power: 5 }, icon: '🐸' }
    ],
    icon: '🐸',
    description: 'Um sapo que cospe veneno mortal.',
    expReward: 20,
    regions: ['pantano_mistico'],
    seedDrop: 'lotus_pantano'
  },
  {
    name: 'Sanguessuga Gigante',
    type: 'normal',
    baseStats: { hp: 45, attack: 10, defense: 4, magic: 6, speed: 7 },
    abilities: [
      { id: 'blood_suck', name: 'Sugar Sangue', description: 'Drena vida', damage: 12, healing: 10, range: 1, cooldown: 1, currentCooldown: 0, icon: '🩸' }
    ],
    icon: '🪱',
    description: 'Criatura parasita do pântano.',
    expReward: 18,
    regions: ['pantano_mistico']
  },
  {
    name: 'Planta Carnívora',
    type: 'normal',
    baseStats: { hp: 65, attack: 16, defense: 8, magic: 4, speed: 2 },
    abilities: [
      { id: 'chomp', name: 'Mordida Grande', description: 'Grande mordida', damage: 20, range: 1, cooldown: 1, currentCooldown: 0, icon: '🌿' }
    ],
    icon: '🌿',
    description: 'Planta que devora criaturas.',
    expReward: 22,
    regions: ['pantano_mistico']
  },
  
  // ═══════════════════════════════════
  // MONTANHA CELESTE ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Águia Tempestade',
    type: 'normal',
    baseStats: { hp: 55, attack: 14, defense: 6, magic: 10, speed: 14 },
    abilities: [
      { id: 'lightning_dive', name: 'Mergulho Relâmpago', description: 'Ataque elétrico', damage: 16, range: 3, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'stun', duration: 1, power: 1 }, icon: '⚡' }
    ],
    icon: '🦅',
    description: 'Águia que comanda os raios.',
    expReward: 28,
    regions: ['montanha_celeste'],
    seedDrop: 'flor_celestial'
  },
  {
    name: 'Elemental de Ar',
    type: 'normal',
    baseStats: { hp: 40, attack: 8, defense: 4, magic: 16, speed: 16 },
    abilities: [
      { id: 'wind_blast', name: 'Rajada de Vento', description: 'Ataque de ar', damage: 14, range: 4, cooldown: 1, currentCooldown: 0, icon: '💨' }
    ],
    icon: '🌪️',
    description: 'Espírito do vento das alturas.',
    expReward: 26,
    regions: ['montanha_celeste']
  },
  {
    name: 'Grifo Jovem',
    type: 'normal',
    baseStats: { hp: 70, attack: 14, defense: 10, magic: 6, speed: 10 },
    abilities: [
      { id: 'talon_strike', name: 'Golpe de Garra', description: 'Garras afiadas', damage: 18, range: 1, cooldown: 0, currentCooldown: 0, icon: '🦁' }
    ],
    icon: '🦁',
    description: 'Um grifo em treinamento.',
    expReward: 30,
    regions: ['montanha_celeste']
  },
  
  // ═══════════════════════════════════
  // RUÍNAS ANTIGAS ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Esqueleto Guardião',
    type: 'normal',
    baseStats: { hp: 60, attack: 12, defense: 8, magic: 4, speed: 7 },
    abilities: [
      { id: 'bone_strike', name: 'Golpe de Osso', description: 'Ataque de osso', damage: 14, range: 1, cooldown: 0, currentCooldown: 0, icon: '🦴' }
    ],
    icon: '💀',
    description: 'Guardião dos túmulos antigos.',
    expReward: 24,
    regions: ['ruinas_antigas'],
    seedDrop: 'hera_antiga'
  },
  {
    name: 'Armadilha Animada',
    type: 'normal',
    baseStats: { hp: 50, attack: 16, defense: 14, magic: 2, speed: 4 },
    abilities: [
      { id: 'snap', name: 'Estalar', description: 'Armadilha fecha', damage: 20, range: 1, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'slow', duration: 2, power: 4 }, icon: '⚙️' }
    ],
    icon: '⚙️',
    description: 'Uma armadilha ganha vida.',
    expReward: 22,
    regions: ['ruinas_antigas']
  },
  {
    name: 'Fantasma Guardião',
    type: 'normal',
    baseStats: { hp: 40, attack: 8, defense: 4, magic: 16, speed: 12 },
    abilities: [
      { id: 'ghostly_touch', name: 'Toque Fantasma', description: 'Ataque mágico', damage: 14, range: 2, cooldown: 1, currentCooldown: 0, statusEffect: { type: 'curse', duration: 2, power: 3 }, icon: '👻' }
    ],
    icon: '👻',
    description: 'Espírito protetor das ruínas.',
    expReward: 26,
    regions: ['ruinas_antigas']
  },
  
  // ═══════════════════════════════════
  // GENERIC ENEMIES (ALL REGIONS)
  // ═══════════════════════════════════
  {
    name: 'Bandido Mariposa',
    type: 'normal',
    baseStats: { hp: 40, attack: 8, defense: 5, magic: 3, speed: 7 },
    abilities: [
      { id: 'bite', name: 'Mordida', description: 'Ataque básico', damage: 10, range: 1, cooldown: 0, currentCooldown: 0, icon: '🦷' }
    ],
    icon: '🦟',
    description: 'Um ladrão comum das sombras.',
    expReward: 15,
    regions: ['jardim_encantado', 'floresta_sombria', 'pantano_mistico', 'ruinas_antigas', 'caverna_cristalina', 'montanha_celeste']
  },
  {
    name: 'Guarda Besouro',
    type: 'normal',
    baseStats: { hp: 70, attack: 8, defense: 12, magic: 2, speed: 4 },
    abilities: [
      { id: 'shell_bash', name: 'Pancada de Carapaça', description: 'Golpe pesado', damage: 12, range: 1, cooldown: 0, currentCooldown: 0, icon: '🪲' }
    ],
    icon: '🪲',
    description: 'Defensor blindado.',
    expReward: 18,
    regions: ['jardim_encantado', 'floresta_sombria', 'pantano_mistico', 'ruinas_antigas', 'caverna_cristalina', 'montanha_celeste']
  },

  // ═══════════════════════════════════
  // ELITE ENEMIES
  // ═══════════════════════════════════
  {
    name: 'Mestre das Lâminas Louva-a-Deus',
    type: 'elite',
    baseStats: { hp: 120, attack: 18, defense: 10, magic: 8, speed: 12 },
    abilities: [
      { id: 'blade_dance', name: 'Dança das Lâminas', description: 'Ataque múltiplo', damage: 22, range: 1, cooldown: 2, currentCooldown: 0, icon: '⚔️' },
      { id: 'swift_strike', name: 'Golpe Veloz', description: 'Ataque rápido', damage: 14, range: 2, cooldown: 0, currentCooldown: 0, icon: '🗡️' }
    ],
    icon: '🦗',
    description: 'Mestre das artes marciais.',
    expReward: 60,
    regions: ['jardim_encantado', 'floresta_sombria']
  },
  {
    name: 'Senhor da Guerra Escorpião',
    type: 'elite',
    baseStats: { hp: 150, attack: 16, defense: 14, magic: 6, speed: 7 },
    abilities: [
      { id: 'tail_strike', name: 'Golpe de Cauda', description: 'Cauda venenosa', damage: 20, range: 2, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'poison', duration: 3, power: 6 }, icon: '🦂' },
      { id: 'claw_crush', name: 'Esmagar com Garras', description: 'Garras esmagadoras', damage: 18, range: 1, cooldown: 1, currentCooldown: 0, icon: '🦞' }
    ],
    icon: '🦂',
    description: 'Líder guerreiro implacável.',
    expReward: 70,
    regions: ['pantano_mistico', 'caverna_cristalina', 'ruinas_antigas']
  },
  {
    name: 'Arquimago Libélula',
    type: 'elite',
    baseStats: { hp: 90, attack: 8, defense: 8, magic: 22, speed: 14 },
    abilities: [
      { id: 'elemental_storm', name: 'Tempestade Elemental', description: 'Magia em área', damage: 25, range: 4, cooldown: 3, currentCooldown: 0, areaOfEffect: 2, icon: '🌪️' },
      { id: 'arcane_missile', name: 'Míssil Arcano', description: 'Projétil mágico', damage: 16, range: 5, cooldown: 0, currentCooldown: 0, icon: '💫' }
    ],
    icon: '🪁',
    description: 'Mestre das artes arcanas.',
    expReward: 65,
    regions: ['montanha_celeste', 'ruinas_antigas']
  },
  {
    name: 'Golem Guardião de Cristal',
    type: 'elite',
    baseStats: { hp: 180, attack: 14, defense: 20, magic: 10, speed: 4 },
    abilities: [
      { id: 'crystal_prison', name: 'Prisão de Cristal', description: 'Aprisiona o alvo', damage: 15, range: 3, cooldown: 3, currentCooldown: 0, statusEffect: { type: 'stun', duration: 2, power: 1 }, icon: '💎' },
      { id: 'gem_barrage', name: 'Rajada de Gemas', description: 'Múltiplos projéteis', damage: 18, range: 4, cooldown: 1, currentCooldown: 0, areaOfEffect: 1, icon: '✨' }
    ],
    icon: '🗿',
    description: 'Guardião ancestral das cavernas.',
    expReward: 80,
    regions: ['caverna_cristalina']
  },
  
  // ═══════════════════════════════════
  // REGION BOSSES
  // ═══════════════════════════════════
  {
    name: 'Rainha das Abelhas',
    type: 'boss',
    baseStats: { hp: 300, attack: 20, defense: 15, magic: 18, speed: 8 },
    abilities: [
      { id: 'royal_decree', name: 'Decreto Real', description: 'Fortalece aliados', range: 10, cooldown: 4, currentCooldown: 0, areaOfEffect: 10, statusEffect: { type: 'haste', duration: 2, power: 5 }, icon: '👑' },
      { id: 'swarm_strike', name: 'Ataque do Enxame', description: 'Dano massivo em área', damage: 25, range: 3, cooldown: 3, currentCooldown: 0, areaOfEffect: 2, icon: '🐝' },
      { id: 'sting_barrage', name: 'Rajada de Ferrões', description: 'Múltiplos ferrões', damage: 18, range: 2, cooldown: 1, currentCooldown: 0, statusEffect: { type: 'poison', duration: 3, power: 5 }, icon: '💉' }
    ],
    icon: '👑',
    description: 'Soberana absoluta do Jardim Encantado.',
    expReward: 200,
    regions: ['jardim_encantado']
  },
  {
    name: 'Aranha Matriarca',
    type: 'boss',
    baseStats: { hp: 350, attack: 22, defense: 12, magic: 20, speed: 10 },
    abilities: [
      { id: 'web_trap', name: 'Armadilha de Teia', description: 'Imobiliza todos', range: 10, cooldown: 5, currentCooldown: 0, areaOfEffect: 3, statusEffect: { type: 'slow', duration: 3, power: 8 }, icon: '🕸️' },
      { id: 'venom_spray', name: 'Spray de Veneno', description: 'Veneno em área', damage: 20, range: 4, cooldown: 2, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'poison', duration: 4, power: 6 }, icon: '☠️' },
      { id: 'shadow_bite', name: 'Mordida das Sombras', description: 'Ataque devastador', damage: 30, range: 1, cooldown: 1, currentCooldown: 0, icon: '🕷️' }
    ],
    icon: '🕷️',
    description: 'A mãe de todas as aranhas da floresta.',
    expReward: 250,
    regions: ['floresta_sombria']
  },
  {
    name: 'Guardião de Cristal',
    type: 'boss',
    baseStats: { hp: 450, attack: 18, defense: 28, magic: 15, speed: 5 },
    abilities: [
      { id: 'crystal_slam', name: 'Pancada de Cristal', description: 'Golpe devastador', damage: 30, range: 2, cooldown: 2, currentCooldown: 0, areaOfEffect: 1, statusEffect: { type: 'stun', duration: 1, power: 1 }, icon: '💎' },
      { id: 'regenerate', name: 'Regeneração Cristalina', description: 'Cura a si mesmo', healing: 60, range: 0, cooldown: 4, currentCooldown: 0, icon: '💚' },
      { id: 'crystal_barrage', name: 'Rajada de Cristais', description: 'Ataque à distância', damage: 22, range: 5, cooldown: 1, currentCooldown: 0, areaOfEffect: 1, icon: '✨' }
    ],
    icon: '💠',
    description: 'Protetor ancestral da Caverna Cristalina.',
    expReward: 280,
    regions: ['caverna_cristalina']
  },
  {
    name: 'Hidra do Pântano',
    type: 'boss',
    baseStats: { hp: 400, attack: 24, defense: 14, magic: 20, speed: 6 },
    abilities: [
      { id: 'multi_head', name: 'Ataque de Múltiplas Cabeças', description: 'Ataque triplo', damage: 18, range: 2, cooldown: 1, currentCooldown: 0, areaOfEffect: 2, icon: '🐲' },
      { id: 'toxic_breath', name: 'Sopro Tóxico', description: 'Veneno devastador', damage: 25, range: 4, cooldown: 3, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'poison', duration: 4, power: 8 }, icon: '☠️' },
      { id: 'regeneration', name: 'Regeneração', description: 'Cura as cabeças', healing: 50, range: 0, cooldown: 5, currentCooldown: 0, icon: '💚' }
    ],
    icon: '🐉',
    description: 'A temível criatura do Pântano Místico.',
    expReward: 270,
    regions: ['pantano_mistico']
  },
  {
    name: 'Fênix Ancestral',
    type: 'boss',
    baseStats: { hp: 380, attack: 26, defense: 12, magic: 30, speed: 14 },
    abilities: [
      { id: 'flame_burst', name: 'Explosão de Chamas', description: 'Fogo em área', damage: 35, range: 4, cooldown: 2, currentCooldown: 0, areaOfEffect: 2, statusEffect: { type: 'burn', duration: 3, power: 6 }, icon: '🔥' },
      { id: 'rebirth', name: 'Renascimento', description: 'Cura-se completamente (1x)', healing: 200, range: 0, cooldown: 20, currentCooldown: 0, icon: '🔄' },
      { id: 'divine_light', name: 'Luz Divina', description: 'Ataque celestial', damage: 28, range: 5, cooldown: 1, currentCooldown: 0, icon: '✨' }
    ],
    icon: '🔥',
    description: 'A fênix imortal da Montanha Celeste.',
    expReward: 350,
    regions: ['montanha_celeste']
  },
  {
    name: 'Imperador Lich',
    type: 'boss',
    baseStats: { hp: 500, attack: 25, defense: 18, magic: 35, speed: 8 },
    abilities: [
      { id: 'death_ray', name: 'Raio da Morte', description: 'Magia letal', damage: 40, range: 6, cooldown: 3, currentCooldown: 0, icon: '💀' },
      { id: 'summon_undead', name: 'Invocar Mortos', description: 'Invoca esqueletos', damage: 0, range: 10, cooldown: 5, currentCooldown: 0, icon: '👻' },
      { id: 'soul_drain', name: 'Drenar Alma', description: 'Rouba vida e magia', damage: 25, healing: 30, range: 4, cooldown: 2, currentCooldown: 0, statusEffect: { type: 'curse', duration: 3, power: 6 }, icon: '🩸' },
      { id: 'dark_barrier', name: 'Barreira das Trevas', description: 'Aumenta defesa', range: 0, cooldown: 6, currentCooldown: 0, statusEffect: { type: 'bless', duration: 3, power: 10 }, icon: '🛡️' }
    ],
    icon: '💀',
    description: 'O imperador não-morto das Ruínas Antigas.',
    expReward: 500,
    regions: ['ruinas_antigas']
  }
];

// ════════════════════════════════════════════════════════════════
// ENEMY CREATION FUNCTIONS
// ════════════════════════════════════════════════════════════════

export function createEnemy(type: 'normal' | 'elite' | 'boss', floor: number, region?: RegionKey): Enemy {
  let candidates = ENEMY_TEMPLATES.filter(e => e.type === type);
  
  // Filter by region if specified
  if (region) {
    const regionCandidates = candidates.filter(e => e.regions.includes(region));
    if (regionCandidates.length > 0) {
      candidates = regionCandidates;
    }
  }
  
  const template = candidates[Math.floor(Math.random() * candidates.length)];
  
  // Scale stats based on floor and region danger level
  let scaleFactor = 1 + (floor - 1) * 0.15;
  if (region) {
    scaleFactor *= 1 + (REGIONS[region].dangerLevel - 1) * 0.08;
  }
  
  // Determine seed drop
  const seedDrops: PlantType[] = [];
  if (template.seedDrop && Math.random() < 0.15) {
    seedDrops.push(template.seedDrop);
  }
  
  return {
    id: crypto.randomUUID(),
    name: template.name,
    type: template.type,
    stats: {
      hp: Math.floor(template.baseStats.hp * scaleFactor),
      maxHp: Math.floor(template.baseStats.hp * scaleFactor),
      attack: Math.floor(template.baseStats.attack * scaleFactor),
      defense: Math.floor(template.baseStats.defense * scaleFactor),
      magic: Math.floor(template.baseStats.magic * scaleFactor),
      speed: Math.floor(template.baseStats.speed * scaleFactor),
      luck: 5
    },
    abilities: template.abilities.map(a => ({ ...a, currentCooldown: 0 })),
    icon: template.icon,
    description: template.description,
    region,
    loot: {
      gold: Math.floor((10 + template.expReward / 2) * scaleFactor),
      exp: Math.floor(template.expReward * scaleFactor),
      seeds: seedDrops.length > 0 ? seedDrops : undefined
    }
  };
}

export function createRegionBoss(region: RegionKey, floor: number): Enemy {
  const bossCandidates = ENEMY_TEMPLATES.filter(e => e.type === 'boss' && e.regions.includes(region));
  
  if (bossCandidates.length === 0) {
    // Fallback to any boss
    return createEnemy('boss', floor, region);
  }
  
  const template = bossCandidates[0]; // Each region has one boss
  const scaleFactor = 1 + (floor - 1) * 0.2;
  
  // Boss always drops seeds from their region
  const regionData = REGIONS[region];
  const seedDrops = regionData.seeds.slice(0, 2); // Up to 2 seeds
  
  return {
    id: crypto.randomUUID(),
    name: template.name,
    type: 'boss',
    stats: {
      hp: Math.floor(template.baseStats.hp * scaleFactor),
      maxHp: Math.floor(template.baseStats.hp * scaleFactor),
      attack: Math.floor(template.baseStats.attack * scaleFactor),
      defense: Math.floor(template.baseStats.defense * scaleFactor),
      magic: Math.floor(template.baseStats.magic * scaleFactor),
      speed: Math.floor(template.baseStats.speed * scaleFactor),
      luck: 10
    },
    abilities: template.abilities.map(a => ({ ...a, currentCooldown: 0 })),
    icon: template.icon,
    description: template.description,
    region,
    loot: {
      gold: Math.floor(100 + (template.expReward / 2) * scaleFactor),
      exp: Math.floor(template.expReward * scaleFactor),
      seeds: seedDrops
    }
  };
}

export function createEnemyGroup(roomType: 'combat' | 'elite' | 'boss', floor: number, region?: RegionKey): Enemy[] {
  if (roomType === 'boss') {
    if (region) {
      return [createRegionBoss(region, floor)];
    }
    return [createEnemy('boss', floor, region)];
  } else if (roomType === 'elite') {
    return [createEnemy('elite', floor, region), createEnemy('normal', floor, region)];
  } else {
    const count = Math.min(2 + Math.floor(floor / 2), 4);
    return Array.from({ length: count }, () => createEnemy('normal', floor, region));
  }
}

export function getRegionEnemyNames(region: RegionKey): string[] {
  return ENEMY_TEMPLATES
    .filter(e => e.regions.includes(region) && e.type === 'normal')
    .map(e => e.name);
}

export function getRegionBossName(region: RegionKey): string {
  const boss = ENEMY_TEMPLATES.find(e => e.regions.includes(region) && e.type === 'boss');
  return boss?.name || 'Chefe Desconhecido';
}
