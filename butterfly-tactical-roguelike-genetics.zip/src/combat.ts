import { CombatState, CombatUnit, Position, Butterfly, Enemy, Ability } from './types';

const GRID_SIZE = 10;

// Grid size constant

export function initializeCombat(party: Butterfly[], enemies: Enemy[]): CombatState {
  // Create empty grid
  const grid: (CombatUnit | null)[][] = Array.from({ length: GRID_SIZE }, () =>
    Array.from({ length: GRID_SIZE }, () => null)
  );
  
  // Place player units on left side
  const playerUnits: CombatUnit[] = party.map((butterfly, i) => {
    const pos: Position = { x: 1, y: Math.min(2 + i * 2, GRID_SIZE - 2) };
    // Initialize cooldowns from butterfly abilities
    const cooldowns: Record<string, number> = {};
    butterfly.abilities.forEach(a => { cooldowns[a.name] = 0; });
    const unit: CombatUnit = {
      butterfly,
      position: pos,
      isPlayer: true,
      hasMoved: false,
      hasActed: false,
      activeEffects: [],
      cooldowns
    };
    grid[pos.y][pos.x] = unit;
    return unit;
  });
  
  // Place enemy units on right side
  const enemyUnits: CombatUnit[] = enemies.map((enemy, i) => {
    const pos: Position = { x: GRID_SIZE - 2, y: Math.min(2 + i * 2, GRID_SIZE - 2) };
    // Initialize cooldowns from enemy abilities
    const cooldowns: Record<string, number> = {};
    enemy.abilities.forEach(a => { cooldowns[a.name] = 0; });
    const unit: CombatUnit = {
      enemy,
      position: pos,
      isPlayer: false,
      hasMoved: false,
      hasActed: false,
      activeEffects: [],
      cooldowns
    };
    grid[pos.y][pos.x] = unit;
    return unit;
  });
  
  return {
    grid,
    playerUnits,
    enemyUnits,
    turn: 1,
    phase: 'player',
    selectedUnit: null,
    selectedAbility: null,
    log: ['⚔️ Combate iniciado!'],
    isComplete: false,
    victory: false
  };
}

export function getDistance(pos1: Position, pos2: Position): number {
  return Math.abs(pos1.x - pos2.x) + Math.abs(pos1.y - pos2.y);
}

export function getValidMoves(state: CombatState, unit: CombatUnit): Position[] {
  const grid = state.grid;
  const moves: Position[] = [];
  const stats = unit.butterfly?.stats || unit.enemy?.stats;
  const moveRange = Math.min(Math.floor((stats?.speed || 5) / 3) + 2, 5);
  
  for (let y = 0; y < GRID_SIZE; y++) {
    for (let x = 0; x < GRID_SIZE; x++) {
      const dist = getDistance(unit.position, { x, y });
      if (dist > 0 && dist <= moveRange && !grid[y][x]) {
        moves.push({ x, y });
      }
    }
  }
  
  return moves;
}

export function getValidTargets(state: CombatState, unit: CombatUnit, ability: Ability): Position[] {
  const targets: Position[] = [];
  const allUnits = [...state.playerUnits, ...state.enemyUnits];
  
  for (const target of allUnits) {
    const dist = getDistance(unit.position, target.position);
    const targetStats = target.butterfly?.stats || target.enemy?.stats;
    if (!targetStats || targetStats.hp <= 0) continue;
    
    if (dist <= ability.range) {
      // Healing/buff abilities target allies, damage abilities target enemies
      if (ability.healing || ability.statusEffect?.type === 'bless' || ability.statusEffect?.type === 'regen' || ability.statusEffect?.type === 'haste') {
        if (unit.isPlayer === target.isPlayer) {
          targets.push(target.position);
        }
      } else {
        if (unit.isPlayer !== target.isPlayer) {
          targets.push(target.position);
        }
      }
    }
  }
  
  return targets;
}

export function moveUnit(state: CombatState, unit: CombatUnit, newPos: Position): CombatState {
  const newGrid = state.grid.map(row => [...row]);
  
  // Clear old position
  newGrid[unit.position.y][unit.position.x] = null;
  
  // Update unit position
  const updatedUnit = { ...unit, position: newPos, hasMoved: true };
  
  // Set new position
  newGrid[newPos.y][newPos.x] = updatedUnit;
  
  // Update in player or enemy units array
  const newPlayerUnits = state.playerUnits.map(u => 
    u.butterfly?.id === unit.butterfly?.id ? updatedUnit : u
  );
  const newEnemyUnits = state.enemyUnits.map(u => 
    u.enemy?.id === unit.enemy?.id ? updatedUnit : u
  );
  
  return {
    ...state,
    grid: newGrid,
    playerUnits: newPlayerUnits,
    enemyUnits: newEnemyUnits,
    selectedUnit: updatedUnit,
    log: [...state.log, `🦋 ${unit.butterfly?.name || unit.enemy?.name} moveu para (${newPos.x}, ${newPos.y})`]
  };
}

function calculateDamage(attacker: CombatUnit, ability: Ability, defender: CombatUnit): number {
  const attackerStats = attacker.butterfly?.stats || attacker.enemy?.stats;
  const defenderStats = defender.butterfly?.stats || defender.enemy?.stats;
  
  if (!attackerStats || !defenderStats) return 0;
  
  const baseDamage = ability.damage || 0;
  const attackStat = ability.damage && ability.damage > 0 ? 
    (baseDamage > 20 ? attackerStats.magic : attackerStats.attack) : 0;
  
  const rawDamage = baseDamage + Math.floor(attackStat * 0.5);
  const defense = Math.floor(defenderStats.defense * 0.3);
  
  // Check for effects
  const hasCurse = defender.activeEffects.some(e => e.type === 'curse');
  const hasBless = defender.activeEffects.some(e => e.type === 'bless');
  
  let finalDamage = Math.max(1, rawDamage - defense);
  if (hasCurse) finalDamage = Math.floor(finalDamage * 1.25);
  if (hasBless) finalDamage = Math.floor(finalDamage * 0.8);
  
  return finalDamage;
}

export function useAbility(state: CombatState, unit: CombatUnit, ability: Ability, targetPos: Position): CombatState {
  let newState = { ...state };
  const newLog = [...state.log];
  
  // Find target at position
  const allUnits = [...state.playerUnits, ...state.enemyUnits];
  const target = allUnits.find(u => u.position.x === targetPos.x && u.position.y === targetPos.y);
  
  if (!target) return state;
  
  const unitName = unit.butterfly?.name || unit.enemy?.name;
  const targetName = target.butterfly?.name || target.enemy?.name;
  
  // Apply damage
  if (ability.damage && ability.damage > 0) {
    const damage = calculateDamage(unit, ability, target);
    
    if (target.butterfly) {
      target.butterfly.stats.hp -= damage;
      newLog.push(`💥 ${unitName} usou ${ability.name} em ${targetName} causando ${damage} de dano!`);
    } else if (target.enemy) {
      target.enemy.stats.hp -= damage;
      newLog.push(`💥 ${unitName} usou ${ability.name} em ${targetName} causando ${damage} de dano!`);
    }
  }
  
  // Apply healing
  if (ability.healing && ability.healing > 0) {
    const casterStats = unit.butterfly?.stats || unit.enemy?.stats;
    const healAmount = ability.healing + Math.floor((casterStats?.magic || 0) * 0.3);
    
    if (target.butterfly) {
      target.butterfly.stats.hp = Math.min(target.butterfly.stats.maxHp, target.butterfly.stats.hp + healAmount);
      newLog.push(`💚 ${unitName} curou ${targetName} em ${healAmount} HP!`);
    } else if (target.enemy) {
      target.enemy.stats.hp = Math.min(target.enemy.stats.maxHp, target.enemy.stats.hp + healAmount);
      newLog.push(`💚 ${unitName} curou ${targetName} em ${healAmount} HP!`);
    }
  }
  
  // Apply status effect
  if (ability.statusEffect) {
    const existingEffect = target.activeEffects.find(e => e.type === ability.statusEffect!.type);
    if (!existingEffect) {
      target.activeEffects.push({
        type: ability.statusEffect.type,
        duration: ability.statusEffect.duration,
        power: ability.statusEffect.power,
        source: unitName || 'Unknown'
      });
      newLog.push(`✨ ${targetName} foi afetado por ${ability.statusEffect.type}!`);
    }
  }
  
  // Update unit's acted status and cooldown
  const updatedUnit = { ...unit, hasActed: true };
  
  // Update ability cooldown
  const updatedAbilities = (unit.butterfly?.abilities || unit.enemy?.abilities || []).map(a => 
    a.id === ability.id ? { ...a, currentCooldown: a.cooldown } : a
  );
  
  if (updatedUnit.butterfly) {
    updatedUnit.butterfly = { ...updatedUnit.butterfly, abilities: updatedAbilities };
  }
  
  // Update state
  newState = {
    ...state,
    log: newLog,
    playerUnits: state.playerUnits.map(u => {
      if (u.butterfly?.id === unit.butterfly?.id) return updatedUnit;
      if (u.position.x === targetPos.x && u.position.y === targetPos.y) return target;
      return u;
    }),
    enemyUnits: state.enemyUnits.map(u => {
      if (u.enemy?.id === unit.enemy?.id) return updatedUnit;
      if (u.position.x === targetPos.x && u.position.y === targetPos.y) return target;
      return u;
    })
  };
  
  // Update grid
  const newGrid = state.grid.map(row => [...row]);
  newGrid[unit.position.y][unit.position.x] = updatedUnit;
  newGrid[targetPos.y][targetPos.x] = target;
  newState.grid = newGrid;
  
  return newState;
}

function processStatusEffects(unit: CombatUnit, log: string[]): void {
  const stats = unit.butterfly?.stats || unit.enemy?.stats;
  const name = unit.butterfly?.name || unit.enemy?.name;
  
  if (!stats) return;
  
  unit.activeEffects = unit.activeEffects.filter(effect => {
    switch (effect.type) {
      case 'poison':
        const poisonDmg = effect.power;
        stats.hp -= poisonDmg;
        log.push(`☠️ ${name} recebeu ${poisonDmg} de dano de veneno!`);
        break;
      case 'burn':
        const burnDmg = effect.power;
        stats.hp -= burnDmg;
        log.push(`🔥 ${name} recebeu ${burnDmg} de dano de queimadura!`);
        break;
      case 'regen':
        const healAmt = effect.power;
        stats.hp = Math.min(stats.maxHp, stats.hp + healAmt);
        log.push(`💚 ${name} regenerou ${healAmt} HP!`);
        break;
    }
    
    effect.duration--;
    return effect.duration > 0;
  });
}

export function endPlayerTurn(state: CombatState): CombatState {
  const newLog = [...state.log];
  
  // Process status effects for all units
  [...state.playerUnits, ...state.enemyUnits].forEach(unit => {
    processStatusEffects(unit, newLog);
  });
  
  // Reset player units
  const resetPlayerUnits = state.playerUnits.map(u => ({
    ...u,
    hasMoved: false,
    hasActed: false
  }));
  
  // Reduce cooldowns
  resetPlayerUnits.forEach(u => {
    if (u.butterfly) {
      u.butterfly.abilities = u.butterfly.abilities.map(a => ({
        ...a,
        currentCooldown: Math.max(0, a.currentCooldown - 1)
      }));
    }
  });
  
  // Check for victory/defeat
  const playerAlive = state.playerUnits.some(u => u.butterfly && u.butterfly.stats.hp > 0);
  const enemyAlive = state.enemyUnits.some(u => u.enemy && u.enemy.stats.hp > 0);
  
  if (!playerAlive) {
    return {
      ...state,
      log: [...newLog, '💀 Derrota... Todas as borboletas caíram.'],
      isComplete: true,
      victory: false
    };
  }
  
  if (!enemyAlive) {
    return {
      ...state,
      log: [...newLog, '🎉 Vitória! Todos os inimigos foram derrotados!'],
      isComplete: true,
      victory: true
    };
  }
  
  return {
    ...state,
    playerUnits: resetPlayerUnits,
    phase: 'enemy',
    log: [...newLog, '🔄 Turno do inimigo...']
  };
}

export function executeEnemyTurn(state: CombatState): CombatState {
  let newState = { ...state };
  
  for (const enemyUnit of state.enemyUnits) {
    if (!enemyUnit.enemy || enemyUnit.enemy.stats.hp <= 0) continue;
    
    // Find closest player
    let closestPlayer: CombatUnit | null = null;
    let closestDist = Infinity;
    
    for (const playerUnit of state.playerUnits) {
      if (!playerUnit.butterfly || playerUnit.butterfly.stats.hp <= 0) continue;
      const dist = getDistance(enemyUnit.position, playerUnit.position);
      if (dist < closestDist) {
        closestDist = dist;
        closestPlayer = playerUnit;
      }
    }
    
    if (!closestPlayer) continue;
    
    // Get available ability
    const availableAbility = enemyUnit.enemy.abilities.find(a => 
      a.currentCooldown === 0 && a.damage && a.damage > 0
    ) || enemyUnit.enemy.abilities[0];
    
    // If in range, attack
    if (closestDist <= availableAbility.range) {
      newState = useAbility(newState, enemyUnit, availableAbility, closestPlayer.position);
    } else {
      // Move toward player
      const validMoves = getValidMoves(newState, enemyUnit);
      if (validMoves.length > 0) {
        // Find move that gets closest to player
        let bestMove = validMoves[0];
        let bestDist = getDistance(bestMove, closestPlayer.position);
        
        for (const move of validMoves) {
          const dist = getDistance(move, closestPlayer.position);
          if (dist < bestDist) {
            bestDist = dist;
            bestMove = move;
          }
        }
        
        newState = moveUnit(newState, enemyUnit, bestMove);
      }
    }
  }
  
  // Reset enemy units and switch to player turn
  const resetEnemyUnits = newState.enemyUnits.map(u => ({
    ...u,
    hasMoved: false,
    hasActed: false
  }));
  
  // Reduce enemy cooldowns
  resetEnemyUnits.forEach(u => {
    if (u.enemy) {
      u.enemy.abilities = u.enemy.abilities.map(a => ({
        ...a,
        currentCooldown: Math.max(0, a.currentCooldown - 1)
      }));
    }
  });
  
  // Check for victory/defeat after enemy actions
  const playerAlive = newState.playerUnits.some(u => u.butterfly && u.butterfly.stats.hp > 0);
  const enemyAlive = newState.enemyUnits.some(u => u.enemy && u.enemy.stats.hp > 0);
  
  if (!playerAlive) {
    return {
      ...newState,
      enemyUnits: resetEnemyUnits,
      log: [...newState.log, '💀 Derrota... Todas as borboletas caíram.'],
      isComplete: true,
      victory: false
    };
  }
  
  if (!enemyAlive) {
    return {
      ...newState,
      enemyUnits: resetEnemyUnits,
      log: [...newState.log, '🎉 Vitória! Todos os inimigos foram derrotados!'],
      isComplete: true,
      victory: true
    };
  }
  
  return {
    ...newState,
    enemyUnits: resetEnemyUnits,
    turn: state.turn + 1,
    phase: 'player',
    log: [...newState.log, `📍 Turno ${state.turn + 1} - Sua vez!`]
  };
}
