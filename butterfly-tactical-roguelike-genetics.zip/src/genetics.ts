import { Butterfly, Gene, Genetics, Mutation, Stats, ButterflyAppearance, ButterflyClass, Gender, Personality, NegativeTrait, Phenotype, ParentInfo, RegionKey } from './types';
import { getClassAbilities, getClassStats } from './classes';
import { REGIONS } from './regions';

// Gene pools
const WING_PATTERNS = ['spotted', 'striped', 'solid', 'gradient', 'fractal', 'crystalline', 'ethereal', 'cosmic'];
const WING_COLORS = ['ruby', 'sapphire', 'emerald', 'gold', 'silver', 'obsidian', 'opal', 'prismatic'];
const BODY_TYPES = ['slender', 'robust', 'ethereal', 'armored', 'fuzzy', 'crystalline', 'shadowy', 'radiant'];
const ANTENNAE = ['feathered', 'clubbed', 'spiral', 'branched', 'glowing', 'sensory', 'cosmic', 'crowned'];
const EYE_TYPES = ['compound', 'crystal', 'void', 'prismatic', 'ancient', 'mystic', 'predator', 'celestial'];
const SPECIAL_TRAITS = ['none', 'bioluminescent', 'venomous', 'magnetic', 'psychic', 'temporal', 'elemental', 'divine'];
const PERSONALITIES: Personality[] = ['curioso', 'corajoso', 'brincalhao', 'sabio', 'timido', 'agressivo'];

// Region-exclusive trait mappings
const REGION_TRAIT_LABELS: Record<string, string> = {
  // Jardim Encantado
  'pétalas_brilhantes': 'Pétalas Brilhantes',
  'aura_floral': 'Aura Floral',
  'asas_perfumadas': 'Asas Perfumadas',
  'rosa_encantado': 'Rosa Encantado',
  'lavanda_magica': 'Lavanda Mágica',
  'verde_primavera': 'Verde Primavera',
  
  // Floresta Sombria
  'visao_noturna': 'Visão Noturna',
  'camuflagem_sombria': 'Camuflagem Sombria',
  'asas_silenciosas': 'Asas Silenciosas',
  'negro_profundo': 'Negro Profundo',
  'roxo_noturno': 'Roxo Noturno',
  'verde_musgo': 'Verde Musgo',
  
  // Caverna Cristalina
  'corpo_cristalino': 'Corpo Cristalino',
  'reflexo_prismatico': 'Reflexo Prismático',
  'asas_diamante': 'Asas de Diamante',
  'cristal_puro': 'Cristal Puro',
  'ametista': 'Ametista',
  'safira': 'Safira',
  'rubi': 'Rubi',
  
  // Pântano Místico
  'resistencia_toxinas': 'Resistência a Toxinas',
  'guelras_asas': 'Guelras nas Asas',
  'bioluminescencia': 'Bioluminescência',
  'verde_toxico': 'Verde Tóxico',
  'azul_pantano': 'Azul Pântano',
  'marrom_lama': 'Marrom Lama',
  
  // Montanha Celeste
  'asas_celestiais': 'Asas Celestiais',
  'resistencia_altitude': 'Resistência à Altitude',
  'bencao_divina': 'Bênção Divina',
  'branco_celestial': 'Branco Celestial',
  'dourado_divino': 'Dourado Divino',
  'azul_celeste': 'Azul Celeste',
  
  // Ruínas Antigas
  'conhecimento_ancestral': 'Conhecimento Ancestral',
  'resistencia_magica': 'Resistência Mágica',
  'longevidade': 'Longevidade',
  'dourado_antigo': 'Dourado Antigo',
  'bronze_patina': 'Bronze Pátina',
  'jade_imperial': 'Jade Imperial'
};

// Region trait stat bonuses
const REGION_TRAIT_BONUSES: Record<string, Partial<Stats>> = {
  // Jardim Encantado traits
  'pétalas_brilhantes': { luck: 5, magic: 2 },
  'aura_floral': { magic: 4 },
  'asas_perfumadas': { luck: 3, speed: 2 },
  
  // Floresta Sombria traits
  'visao_noturna': { luck: 4, attack: 2 },
  'camuflagem_sombria': { defense: 4, speed: 2 },
  'asas_silenciosas': { speed: 5, luck: 3 },
  
  // Caverna Cristalina traits
  'corpo_cristalino': { defense: 6, magic: 2 },
  'reflexo_prismatico': { magic: 5, luck: 3 },
  'asas_diamante': { defense: 8, attack: 3 },
  
  // Pântano Místico traits
  'resistencia_toxinas': { defense: 4, hp: 15 },
  'guelras_asas': { speed: 3, defense: 2 },
  'bioluminescencia': { magic: 4, luck: 4 },
  
  // Montanha Celeste traits
  'asas_celestiais': { magic: 6, speed: 4 },
  'resistencia_altitude': { hp: 20, defense: 3 },
  'bencao_divina': { hp: 15, magic: 5, luck: 5 },
  
  // Ruínas Antigas traits
  'conhecimento_ancestral': { magic: 8, luck: 4 },
  'resistencia_magica': { defense: 5, magic: 4 },
  'longevidade': { hp: 25, defense: 4 }
};

// Region-exclusive colors with hex values
const REGION_COLOR_MAP: Record<string, string> = {
  'rosa_encantado': '#ff69b4',
  'lavanda_magica': '#9370db',
  'verde_primavera': '#00fa9a',
  'negro_profundo': '#0a0a0a',
  'roxo_noturno': '#4b0082',
  'verde_musgo': '#3d5a3d',
  'cristal_puro': '#e6e6fa',
  'ametista': '#9966cc',
  'safira': '#0f52ba',
  'rubi': '#e0115f',
  'verde_toxico': '#7fff00',
  'azul_pantano': '#2f4f4f',
  'marrom_lama': '#5c4033',
  'branco_celestial': '#f0f8ff',
  'dourado_divino': '#ffd700',
  'azul_celeste': '#87ceeb',
  'dourado_antigo': '#cfb53b',
  'bronze_patina': '#cd7f32',
  'jade_imperial': '#00a86b'
};

// Region glow effects
const REGION_GLOW_MAP: Record<RegionKey, string> = {
  'jardim_encantado': '#ff69b4',
  'floresta_sombria': '#4b0082',
  'caverna_cristalina': '#e6e6fa',
  'pantano_mistico': '#7fff00',
  'montanha_celeste': '#ffd700',
  'ruinas_antigas': '#cfb53b'
};

const MUTATIONS: Mutation[] = [
  { id: 'iron_wings', name: 'Asas de Ferro', description: '+20% Defesa', rarity: 'common', icon: '🛡️', effect: (s) => ({ ...s, defense: Math.floor(s.defense * 1.2) }) },
  { id: 'swift_flutter', name: 'Voo Veloz', description: '+25% Velocidade', rarity: 'common', icon: '💨', effect: (s) => ({ ...s, speed: Math.floor(s.speed * 1.25) }) },
  { id: 'vital_essence', name: 'Essência Vital', description: '+30% HP', rarity: 'common', icon: '❤️', effect: (s) => ({ ...s, maxHp: Math.floor(s.maxHp * 1.3), hp: Math.floor(s.hp * 1.3) }) },
  { id: 'sharp_proboscis', name: 'Probóscide Afiada', description: '+20% Ataque', rarity: 'common', icon: '⚔️', effect: (s) => ({ ...s, attack: Math.floor(s.attack * 1.2) }) },
  { id: 'arcane_dust', name: 'Pó Arcano', description: '+25% Magia', rarity: 'rare', icon: '✨', effect: (s) => ({ ...s, magic: Math.floor(s.magic * 1.25) }) },
  { id: 'lucky_scales', name: 'Escamas da Sorte', description: '+40% Sorte', rarity: 'rare', icon: '🍀', effect: (s) => ({ ...s, luck: Math.floor(s.luck * 1.4) }) },
  { id: 'phoenix_wings', name: 'Asas de Fênix', description: '+15% Todos Stats', rarity: 'epic', icon: '🔥', effect: (s) => ({ 
    ...s, hp: Math.floor(s.hp * 1.15), maxHp: Math.floor(s.maxHp * 1.15), attack: Math.floor(s.attack * 1.15), 
    defense: Math.floor(s.defense * 1.15), magic: Math.floor(s.magic * 1.15), speed: Math.floor(s.speed * 1.15) 
  })},
  { id: 'void_touched', name: 'Toque do Vazio', description: '+50% Magia, -20% HP', rarity: 'epic', icon: '🌑', effect: (s) => ({ 
    ...s, magic: Math.floor(s.magic * 1.5), hp: Math.floor(s.hp * 0.8), maxHp: Math.floor(s.maxHp * 0.8) 
  })},
  { id: 'titan_form', name: 'Forma Titânica', description: '+60% HP & Defesa, -30% Velocidade', rarity: 'epic', icon: '🗿', effect: (s) => ({ 
    ...s, hp: Math.floor(s.hp * 1.6), maxHp: Math.floor(s.maxHp * 1.6), defense: Math.floor(s.defense * 1.6), speed: Math.floor(s.speed * 0.7) 
  })},
  { id: 'celestial_blessing', name: 'Bênção Celestial', description: '+30% Todos Stats', rarity: 'legendary', icon: '👼', effect: (s) => ({ 
    ...s, hp: Math.floor(s.hp * 1.3), maxHp: Math.floor(s.maxHp * 1.3), attack: Math.floor(s.attack * 1.3), 
    defense: Math.floor(s.defense * 1.3), magic: Math.floor(s.magic * 1.3), speed: Math.floor(s.speed * 1.3), luck: Math.floor(s.luck * 1.3)
  })},
  { id: 'primordial_essence', name: 'Essência Primordial', description: '+100% Magia, +50% Ataque', rarity: 'legendary', icon: '🌟', effect: (s) => ({ 
    ...s, magic: Math.floor(s.magic * 2), attack: Math.floor(s.attack * 1.5) 
  })},
  { id: 'eternal_wings', name: 'Asas Eternas', description: '+80% HP, +50% Defesa', rarity: 'legendary', icon: '♾️', effect: (s) => ({ 
    ...s, hp: Math.floor(s.hp * 1.8), maxHp: Math.floor(s.maxHp * 1.8), defense: Math.floor(s.defense * 1.5) 
  })},
];

const BUTTERFLY_NAMES = [
  'Aurora', 'Zéfiro', 'Luna', 'Sol', 'Nebulosa', 'Cristal', 'Sombra', 'Brasa',
  'Gelo', 'Flor', 'Sussurro', 'Tempestade', 'Alba', 'Crepúsculo', 'Névoa', 'Faísca',
  'Veludo', 'Ônix', 'Pérola', 'Rubi', 'Sálvia', 'Hera', 'Coral', 'Azul',
  'Carmesim', 'Violeta', 'Jade', 'Âmbar', 'Índigo', 'Escarlate', 'Celeste', 'Nova',
  'Estrela', 'Monarca', 'Safira', 'Topázio', 'Ametista', 'Opala', 'Granada', 'Turquesa'
];

const COLOR_MAP: Record<string, string> = {
  ruby: '#ef4444', sapphire: '#3b82f6', emerald: '#22c55e', gold: '#eab308',
  silver: '#a1a1aa', obsidian: '#27272a', opal: '#e879f9', prismatic: '#ec4899',
  ...REGION_COLOR_MAP
};

const COLOR_LABELS: Record<string, string> = {
  ruby: 'Rubi', sapphire: 'Safira', emerald: 'Esmeralda', gold: 'Dourada',
  silver: 'Prateada', obsidian: 'Obsidiana', opal: 'Opala', prismatic: 'Prismática'
};

const PATTERN_LABELS: Record<string, string> = {
  spotted: 'Manchada', striped: 'Listrada', solid: 'Sólida', gradient: 'Gradiente',
  fractal: 'Fractal', crystalline: 'Cristalina', ethereal: 'Etérea', cosmic: 'Cósmica'
};

const BODY_LABELS: Record<string, string> = {
  slender: 'Esguia', robust: 'Robusta', ethereal: 'Etérea', armored: 'Blindada',
  fuzzy: 'Peluda', crystalline: 'Cristalina', shadowy: 'Sombria', radiant: 'Radiante'
};

const TRAIT_LABELS: Record<string, string> = {
  none: 'Nenhum', bioluminescent: 'Bioluminescente', venomous: 'Venenosa',
  magnetic: 'Magnética', psychic: 'Psíquica', temporal: 'Temporal',
  elemental: 'Elemental', divine: 'Divina',
  ...REGION_TRAIT_LABELS
};

function randomChoice<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function createGene(pool: string[]): Gene {
  return {
    dominant: randomChoice(pool),
    recessive: randomChoice(pool)
  };
}

function createRegionGene(region: RegionKey): Gene {
  const regionData = REGIONS[region];
  const traits = [...regionData.exclusiveTraits, ...regionData.exclusiveColors];
  return {
    dominant: randomChoice(traits),
    recessive: randomChoice(traits)
  };
}

function inheritGene(parent1Gene: Gene, parent2Gene: Gene, mutationChance: number = 0.05): Gene {
  const allele1 = Math.random() < 0.5 ? parent1Gene.dominant : parent1Gene.recessive;
  const allele2 = Math.random() < 0.5 ? parent2Gene.dominant : parent2Gene.recessive;
  
  // Mutation chance for new alleles - higher if inbred
  const mutatedAllele1 = Math.random() < mutationChance ? parent1Gene.dominant : allele1;
  const mutatedAllele2 = Math.random() < mutationChance ? parent2Gene.dominant : allele2;
  
  return { dominant: mutatedAllele1, recessive: mutatedAllele2 };
}

export function createRandomGenetics(region?: RegionKey): Genetics {
  const base: Genetics = {
    wingPattern: createGene(WING_PATTERNS),
    wingColor: createGene(WING_COLORS),
    bodyType: createGene(BODY_TYPES),
    antennae: createGene(ANTENNAE),
    eyeType: createGene(EYE_TYPES),
    specialTrait: createGene(SPECIAL_TRAITS)
  };
  
  // Add region-exclusive trait if from a region
  if (region) {
    base.regionTrait = createRegionGene(region);
  }
  
  return base;
}

export function getPhenotype(genetics: Genetics): Phenotype {
  return {
    colorLabel: COLOR_LABELS[genetics.wingColor.dominant] || REGION_TRAIT_LABELS[genetics.wingColor.dominant] || genetics.wingColor.dominant,
    patternLabel: PATTERN_LABELS[genetics.wingPattern.dominant] || genetics.wingPattern.dominant,
    bodyLabel: BODY_LABELS[genetics.bodyType.dominant] || genetics.bodyType.dominant,
    traitLabel: TRAIT_LABELS[genetics.specialTrait.dominant] || genetics.specialTrait.dominant,
    regionTraitLabel: genetics.regionTrait ? (REGION_TRAIT_LABELS[genetics.regionTrait.dominant] || genetics.regionTrait.dominant) : undefined
  };
}

function geneticsToAppearance(genetics: Genetics, region?: RegionKey): ButterflyAppearance {
  let primaryColor = COLOR_MAP[genetics.wingColor.dominant] || '#9333ea';
  let secondaryColor = COLOR_MAP[genetics.wingColor.recessive] || '#6366f1';
  
  // Apply region-exclusive colors if present
  if (genetics.regionTrait) {
    const regionColor = REGION_COLOR_MAP[genetics.regionTrait.dominant];
    if (regionColor) {
      primaryColor = regionColor;
    }
    const regionSecondary = REGION_COLOR_MAP[genetics.regionTrait.recessive];
    if (regionSecondary) {
      secondaryColor = regionSecondary;
    }
  }
  
  const sizeMap: Record<string, ButterflyAppearance['size']> = {
    slender: 'small', robust: 'large', ethereal: 'medium', armored: 'large',
    fuzzy: 'medium', crystalline: 'medium', shadowy: 'small', radiant: 'giant'
  };
  
  return {
    primaryColor,
    secondaryColor,
    pattern: genetics.wingPattern.dominant,
    wingShape: genetics.bodyType.dominant,
    size: sizeMap[genetics.bodyType.dominant] || 'medium',
    glow: genetics.specialTrait.dominant !== 'none' ? primaryColor : undefined,
    regionGlow: region ? REGION_GLOW_MAP[region] : undefined
  };
}

function geneticsToStats(genetics: Genetics, butterflyClass: ButterflyClass): Stats {
  const classStats = getClassStats(butterflyClass);
  
  const bodyBonus: Record<string, Partial<Stats>> = {
    slender: { speed: 3, defense: -1 },
    robust: { hp: 15, speed: -2 },
    ethereal: { magic: 3, defense: -1 },
    armored: { defense: 4, speed: -2 },
    fuzzy: { hp: 5, luck: 2 },
    crystalline: { magic: 2, defense: 2 },
    shadowy: { speed: 4, attack: 2 },
    radiant: { magic: 4, hp: 10 }
  };
  
  const traitBonus: Record<string, Partial<Stats>> = {
    none: {},
    bioluminescent: { magic: 2 },
    venomous: { attack: 3 },
    magnetic: { defense: 3 },
    psychic: { magic: 4 },
    temporal: { speed: 5 },
    elemental: { magic: 3, attack: 2 },
    divine: { hp: 10, magic: 3 }
  };
  
  const bodyMod = bodyBonus[genetics.bodyType.dominant] || {};
  const traitMod = traitBonus[genetics.specialTrait.dominant] || {};
  
  // Apply region trait bonus if present
  let regionMod: Partial<Stats> = {};
  if (genetics.regionTrait) {
    regionMod = REGION_TRAIT_BONUSES[genetics.regionTrait.dominant] || {};
  }
  
  const baseStats: Stats = {
    hp: 80 + (classStats.hp || 0) + (bodyMod.hp || 0) + (traitMod.hp || 0) + (regionMod.hp || 0),
    maxHp: 80 + (classStats.hp || 0) + (bodyMod.hp || 0) + (traitMod.hp || 0) + (regionMod.hp || 0),
    attack: 10 + (classStats.attack || 0) + (bodyMod.attack || 0) + (traitMod.attack || 0) + (regionMod.attack || 0),
    defense: 8 + (classStats.defense || 0) + (bodyMod.defense || 0) + (traitMod.defense || 0) + (regionMod.defense || 0),
    magic: 8 + (classStats.magic || 0) + (bodyMod.magic || 0) + (traitMod.magic || 0) + (regionMod.magic || 0),
    speed: 10 + (classStats.speed || 0) + (bodyMod.speed || 0) + (traitMod.speed || 0) + (regionMod.speed || 0),
    luck: 5 + (classStats.luck || 0) + (bodyMod.luck || 0) + (traitMod.luck || 0) + (regionMod.luck || 0)
  };
  
  return baseStats;
}

function rollMutation(): Mutation | null {
  const roll = Math.random();
  if (roll > 0.3) return null;
  
  const rarityRoll = Math.random();
  let targetRarity: Mutation['rarity'];
  if (rarityRoll < 0.5) targetRarity = 'common';
  else if (rarityRoll < 0.8) targetRarity = 'rare';
  else if (rarityRoll < 0.95) targetRarity = 'epic';
  else targetRarity = 'legendary';
  
  const candidates = MUTATIONS.filter(m => m.rarity === targetRarity);
  return candidates.length > 0 ? randomChoice(candidates) : null;
}

// Calculate inbreeding coefficient based on shared ancestors
export function calculateInbreeding(bf1: Butterfly, bf2: Butterfly): number {
  if (!bf1.parentIds || !bf2.parentIds) return 0;
  
  const [p1a, p1b] = bf1.parentIds;
  const [p2a, p2b] = bf2.parentIds;
  
  // Siblings (same parents)
  if (p1a && p1b && p1a === p2a && p1b === p2b) return 0.5;
  
  // Half-siblings (one shared parent)
  if ((p1a && (p1a === p2a || p1a === p2b)) || (p1b && (p1b === p2a || p1b === p2b))) return 0.25;
  
  // Parent-child
  if (bf1.id === p2a || bf1.id === p2b || bf2.id === p1a || bf2.id === p1b) return 0.5;
  
  // Check grandparent relations via parents info
  if (bf1.parents && bf2.parents) {
    const sharedNames = [bf1.parents.father, bf1.parents.mother]
      .filter(n => [bf2.parents!.father, bf2.parents!.mother].includes(n));
    if (sharedNames.length > 0) return 0.125;
  }
  
  return 0;
}

// Apply inbreeding effects to offspring
export function applyInbreedingEffects(butterfly: Butterfly, inbreedCoeff: number): void {
  if (inbreedCoeff <= 0.05) return;
  
  butterfly.isInbred = true;
  butterfly.inbreedCoeff = inbreedCoeff;
  
  const negativeTraitPool: NegativeTrait[] = ['fragile_wings', 'weak_immunity', 'poor_vision', 'sterile', 'deformed'];
  const numDefects = Math.floor(inbreedCoeff * 10) + (Math.random() < inbreedCoeff ? 1 : 0);
  
  for (let i = 0; i < numDefects && butterfly.negativeTraits.length < negativeTraitPool.length; i++) {
    const available = negativeTraitPool.filter(t => !butterfly.negativeTraits.includes(t));
    if (available.length > 0) {
      butterfly.negativeTraits.push(randomChoice(available));
    }
  }
  
  // Apply negative effects to stats
  butterfly.negativeTraits.forEach(trait => {
    switch(trait) {
      case 'fragile_wings':
        butterfly.stats.defense = Math.floor(butterfly.stats.defense * 0.7);
        butterfly.stamina = Math.floor(butterfly.stamina * 0.7);
        break;
      case 'weak_immunity':
        butterfly.stats.maxHp = Math.floor(butterfly.stats.maxHp * 0.8);
        butterfly.stats.hp = butterfly.stats.maxHp;
        break;
      case 'poor_vision':
        butterfly.stats.luck = Math.floor(butterfly.stats.luck * 0.5);
        butterfly.agility = Math.floor(butterfly.agility * 0.8);
        break;
      case 'deformed':
        butterfly.stats.attack = Math.floor(butterfly.stats.attack * 0.8);
        butterfly.stats.magic = Math.floor(butterfly.stats.magic * 0.8);
        butterfly.beauty = Math.floor(butterfly.beauty * 0.5);
        break;
      case 'sterile':
        butterfly.fertility = 0;
        break;
    }
  });
}

// Personality modifiers
export function getPersonalityMod(bf: Butterfly, modType: string): number {
  const mods: Record<Personality, Record<string, number>> = {
    curioso: { adventureSpeed: 1.3, adventureLoot: 1.4, adventureSurvival: 0.9 },
    corajoso: { adventureSpeed: 0.8, adventureLoot: 1.1, adventureSurvival: 1.3 },
    brincalhao: { adventureSpeed: 0.9, adventureLoot: 1.0, adventureSurvival: 1.1 },
    sabio: { adventureSpeed: 1.0, adventureLoot: 1.2, adventureSurvival: 1.2 },
    timido: { adventureSpeed: 1.2, adventureLoot: 0.9, adventureSurvival: 1.4 },
    agressivo: { adventureSpeed: 0.7, adventureLoot: 1.0, adventureSurvival: 0.8 }
  };
  return mods[bf.personality]?.[modType] || 1.0;
}

export function breedGenetics(g1: Genetics, g2: Genetics, inbreedCoeff: number = 0): Genetics {
  const mutChance = 0.05 + (inbreedCoeff * 0.15); // Higher mutation rate if inbred
  
  const result: Genetics = {
    wingPattern: inheritGene(g1.wingPattern, g2.wingPattern, mutChance),
    wingColor: inheritGene(g1.wingColor, g2.wingColor, mutChance),
    bodyType: inheritGene(g1.bodyType, g2.bodyType, mutChance),
    antennae: inheritGene(g1.antennae, g2.antennae, mutChance),
    eyeType: inheritGene(g1.eyeType, g2.eyeType, mutChance),
    specialTrait: inheritGene(g1.specialTrait, g2.specialTrait, mutChance)
  };
  
  // Inherit region trait if either parent has one
  if (g1.regionTrait || g2.regionTrait) {
    if (g1.regionTrait && g2.regionTrait) {
      result.regionTrait = inheritGene(g1.regionTrait, g2.regionTrait, mutChance);
    } else {
      result.regionTrait = g1.regionTrait || g2.regionTrait;
    }
  }
  
  return result;
}

export function createButterfly(
  options: {
    genetics?: Genetics;
    parentIds?: [string | null, string | null];
    parents?: ParentInfo;
    generation?: number;
    inheritedMutations?: Mutation[];
    gender?: Gender;
    region?: RegionKey;
    age?: number;
  } = {}
): Butterfly {
  const {
    parentIds = [null, null],
    parents,
    generation = 1,
    inheritedMutations = [],
    gender,
    region,
    age = 0
  } = options;

  // Create genetics with region if specified
  const actualGenetics = options.genetics || createRandomGenetics(region);
  const butterflyClass = randomChoice<ButterflyClass>([
    'Mage', 'Cleric', 'Necromancer', 'Paladin', 'Rogue', 'Berserker', 'Ranger',
    'Summoner', 'Chronomancer', 'Druid', 'Alchemist', 'Bard', 'Monk', 'Warlock'
  ]);
  
  let stats = geneticsToStats(actualGenetics, butterflyClass);
  
  // Roll for new mutations
  const mutations: Mutation[] = [...inheritedMutations];
  const newMutation = rollMutation();
  if (newMutation && !mutations.find(m => m.id === newMutation.id)) {
    mutations.push(newMutation);
  }
  
  // Apply mutations to stats
  mutations.forEach(m => {
    stats = m.effect(stats);
  });

  const actualGender = gender || (Math.random() < 0.5 ? 'macho' : 'femea');
  const personality = randomChoice(PERSONALITIES);
  
  // Collect region exclusive traits for this butterfly
  const regionExclusiveTraits: string[] = [];
  if (region) {
    const regionData = REGIONS[region];
    if (actualGenetics.regionTrait) {
      regionExclusiveTraits.push(actualGenetics.regionTrait.dominant);
      if (actualGenetics.regionTrait.recessive !== actualGenetics.regionTrait.dominant) {
        regionExclusiveTraits.push(actualGenetics.regionTrait.recessive);
      }
    }
    // Add random exclusive trait from region
    if (Math.random() < 0.5) {
      const randomTrait = randomChoice([...regionData.exclusiveTraits, ...regionData.exclusiveColors]);
      if (!regionExclusiveTraits.includes(randomTrait)) {
        regionExclusiveTraits.push(randomTrait);
      }
    }
  }
  
  return {
    id: crypto.randomUUID(),
    name: randomChoice(BUTTERFLY_NAMES) + '-' + Math.floor(Math.random() * 1000),
    generation,
    gender: actualGender,
    genetics: actualGenetics,
    stats,
    class: butterflyClass,
    abilities: getClassAbilities(butterflyClass),
    mutations,
    level: 1,
    exp: 0,
    appearance: geneticsToAppearance(actualGenetics, region),
    parentIds,
    parents,
    
    // Extended stats
    age,
    maxAge: 80 + Math.floor(Math.random() * 40),
    fertility: 0.7 + Math.random() * 0.3,
    personality,
    stamina: 50 + Math.floor(Math.random() * 30),
    agility: 40 + Math.floor(Math.random() * 30),
    beauty: 50 + Math.floor(Math.random() * 50),
    
    // Inbreeding
    isInbred: false,
    inbreedCoeff: 0,
    negativeTraits: [],
    
    // Region & Adventure
    onAdventure: false,
    region,
    regionExclusiveTraits: regionExclusiveTraits.length > 0 ? regionExclusiveTraits : undefined
  };
}

export function breedButterflies(parent1: Butterfly, parent2: Butterfly): Butterfly {
  const inbreedCoeff = calculateInbreeding(parent1, parent2);
  const childGenetics = breedGenetics(parent1.genetics, parent2.genetics, inbreedCoeff);
  
  // Determine father/mother based on gender
  const father = parent1.gender === 'macho' ? parent1 : parent2;
  const mother = parent1.gender === 'femea' ? parent1 : parent2;
  
  // Chance to inherit parent mutations
  const inheritedMutations: Mutation[] = [];
  [...parent1.mutations, ...parent2.mutations].forEach(m => {
    if (Math.random() < 0.4 && !inheritedMutations.find(im => im.id === m.id)) {
      inheritedMutations.push(m);
    }
  });
  
  const newGeneration = Math.max(parent1.generation, parent2.generation) + 1;
  
  // Inherit region from either parent
  const childRegion = parent1.region || parent2.region;
  
  const child = createButterfly({
    genetics: childGenetics,
    parentIds: [parent1.id, parent2.id],
    parents: {
      father: father.name,
      mother: mother.name,
      fatherId: father.id,
      motherId: mother.id
    },
    generation: newGeneration,
    inheritedMutations,
    region: childRegion
  });
  
  // Inherit region exclusive traits from parents
  const inheritedRegionTraits: string[] = [];
  [parent1.regionExclusiveTraits, parent2.regionExclusiveTraits].forEach(traits => {
    if (traits) {
      traits.forEach(t => {
        if (Math.random() < 0.5 && !inheritedRegionTraits.includes(t)) {
          inheritedRegionTraits.push(t);
        }
      });
    }
  });
  if (inheritedRegionTraits.length > 0) {
    child.regionExclusiveTraits = [...(child.regionExclusiveTraits || []), ...inheritedRegionTraits];
  }
  
  // Apply inbreeding effects if any
  applyInbreedingEffects(child, inbreedCoeff);
  
  return child;
}

export function createStartingButterflies(): Butterfly[] {
  // Ensure we get a mix of genders
  const butterflies: Butterfly[] = [];
  butterflies.push(createButterfly({ gender: 'macho' }));
  butterflies.push(createButterfly({ gender: 'macho' }));
  butterflies.push(createButterfly({ gender: 'femea' }));
  butterflies.push(createButterfly({ gender: 'femea' }));
  return butterflies;
}

// Create a butterfly found in a specific region with exclusive traits
export function createRegionButterfly(region: RegionKey): Butterfly {
  return createButterfly({ region });
}

export { MUTATIONS, COLOR_MAP, COLOR_LABELS, PATTERN_LABELS, BODY_LABELS, TRAIT_LABELS, REGION_TRAIT_LABELS, REGION_COLOR_MAP };
