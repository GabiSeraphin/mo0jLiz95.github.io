// Butterfly Tactical Roguelike - Type Definitions

// ════════════════════════════════════════════════════════════════
// REGIONS & PLANTS
// ════════════════════════════════════════════════════════════════

export type RegionKey = 'jardim_encantado' | 'floresta_sombria' | 'caverna_cristalina' | 'pantano_mistico' | 'montanha_celeste' | 'ruinas_antigas';

export interface Region {
  key: RegionKey;
  name: string;
  desc: string;
  icon: string;
  duration: number;
  nectarCost: number;
  dangerLevel: number;
  deathChance: number;
  butterflyChance: number;
  seedChance: number;
  seeds: PlantType[];
  exclusiveTraits: string[];
  exclusiveColors: string[];
  enemyTypes: string[];
  bossName: string;
  bossIcon: string;
  floorCount: number;
  background: string;
}

export type PlantType = 'rosa_mistica' | 'lirio_lunar' | 'orquidea_sombria' | 'flor_cristal' | 'lotus_pantano' | 'flor_celestial' | 'hera_antiga' | 'cogumelo_brilhante';

export interface Plant {
  type: PlantType;
  name: string;
  icon: string;
  growTime: number;
  nectarYield: number;
  nectarType: 'basic' | 'premium' | 'mythic';
  region: RegionKey;
  description: string;
}

export interface PlantSlot {
  type: PlantType;
  progress: number;
  planted: number;
}

// ════════════════════════════════════════════════════════════════
// GENETICS
// ════════════════════════════════════════════════════════════════

export interface Gene {
  dominant: string;
  recessive: string;
}

export interface Genetics {
  wingPattern: Gene;
  wingColor: Gene;
  bodyType: Gene;
  antennae: Gene;
  eyeType: Gene;
  specialTrait: Gene;
  regionTrait?: Gene; // Region-exclusive trait
}

export interface Stats {
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  magic: number;
  speed: number;
  luck: number;
}

export interface Mutation {
  id: string;
  name: string;
  description: string;
  effect: (stats: Stats) => Stats;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  icon: string;
}

export type ButterflyClass = 
  | 'Mage' | 'Cleric' | 'Necromancer' | 'Paladin' | 'Rogue' 
  | 'Berserker' | 'Ranger' | 'Summoner' | 'Chronomancer' | 'Druid'
  | 'Alchemist' | 'Bard' | 'Monk' | 'Warlock';

export type Personality = 'curioso' | 'corajoso' | 'brincalhao' | 'sabio' | 'timido' | 'agressivo';
export type Gender = 'macho' | 'femea';
export type NegativeTrait = 'fragile_wings' | 'weak_immunity' | 'poor_vision' | 'sterile' | 'deformed';

export interface Ability {
  id: string;
  name: string;
  description: string;
  damage?: number;
  healing?: number;
  range: number;
  cooldown: number;
  currentCooldown: number;
  areaOfEffect?: number;
  statusEffect?: StatusEffect;
  icon: string;
}

export interface StatusEffect {
  type: 'poison' | 'burn' | 'freeze' | 'stun' | 'bless' | 'curse' | 'regen' | 'haste' | 'slow';
  duration: number;
  power: number;
}

export interface Phenotype {
  colorLabel: string;
  patternLabel: string;
  bodyLabel: string;
  traitLabel: string;
  regionTraitLabel?: string;
}

export interface ParentInfo {
  father: string;
  mother: string;
  fatherId: string;
  motherId: string;
}

export interface Butterfly {
  id: string;
  name: string;
  generation: number;
  gender: Gender;
  genetics: Genetics;
  stats: Stats;
  class: ButterflyClass;
  abilities: Ability[];
  mutations: Mutation[];
  level: number;
  exp: number;
  appearance: ButterflyAppearance;
  parentIds: [string | null, string | null];
  parents?: ParentInfo;
  
  // Extended stats
  age: number;
  maxAge: number;
  fertility: number;
  personality: Personality;
  stamina: number;
  agility: number;
  beauty: number;
  
  // Inbreeding
  isInbred: boolean;
  inbreedCoeff: number;
  negativeTraits: NegativeTrait[];
  
  // Region & Adventure state
  onAdventure: boolean;
  region?: RegionKey;
  regionExclusiveTraits?: string[];
}

export interface ButterflyAppearance {
  primaryColor: string;
  secondaryColor: string;
  pattern: string;
  wingShape: string;
  size: 'tiny' | 'small' | 'medium' | 'large' | 'giant';
  glow?: string;
  regionGlow?: string; // Special glow from region
}

// Combat
export interface Position {
  x: number;
  y: number;
}

export interface CombatUnit {
  butterfly?: Butterfly;
  enemy?: Enemy;
  position: Position;
  isPlayer: boolean;
  hasMoved: boolean;
  hasActed: boolean;
  activeEffects: ActiveEffect[];
  cooldowns: Record<string, number>;
}

export interface ActiveEffect {
  type: StatusEffect['type'];
  duration: number;
  power: number;
  source: string;
}

export interface CombatState {
  grid: (CombatUnit | null)[][];
  playerUnits: CombatUnit[];
  enemyUnits: CombatUnit[];
  turn: number;
  phase: 'player' | 'enemy' | 'complete';
  log: string[];
  selectedUnit: CombatUnit | null;
  selectedAbility: Ability | null;
  isComplete: boolean;
  victory: boolean;
}

export interface Enemy {
  id: string;
  name: string;
  type: 'normal' | 'elite' | 'boss';
  stats: Stats;
  abilities: Ability[];
  icon: string;
  description: string;
  loot?: { gold: number; exp: number; seeds?: PlantType[] };
  region?: RegionKey;
}

// Dungeon
export interface DungeonRoom {
  id: string;
  type: 'combat' | 'elite' | 'boss' | 'rest' | 'shop' | 'mystery' | 'treasure' | 'butterfly_encounter';
  position: { x: number; y: number };
  connections: string[];
  completed: boolean;
  available: boolean;
  icon: string;
}

export interface DungeonRun {
  floor: number;
  rooms: DungeonRoom[];
  currentRoomId: string;
  party: Butterfly[];
  gold: number;
  completedRooms: string[];
  region: RegionKey;
  foundSeeds: PlantType[];
  foundButterflies: Butterfly[];
}

// Adventure Regions
export interface ActiveAdventure {
  region: RegionKey;
  regionName: string;
  icon: string;
  butterflyId: string;
  butterflyName: string;
  startTime: number;
  duration: number;
  personality: Personality;
}

// Nectar types
export interface NectarStore {
  basic: number;
  premium: number;
  mythic: number;
}

export interface GameState {
  screen: 'menu' | 'household' | 'breeding' | 'dungeon' | 'combat' | 'party-select' | 'region-select' | 'victory' | 'defeat' | 'garden';
  household: Butterfly[];
  deadButterflies: Butterfly[];
  gold: number;
  nectar: NectarStore;
  dungeonRun: DungeonRun | null;
  combatState: CombatState | null;
  selectedButterflies: Butterfly[];
  breedingPair: [Butterfly | null, Butterfly | null];
  breedSlot1: number | null;
  breedSlot2: number | null;
  activeAdventures: ActiveAdventure[];
  selectedBf: number | null;
  plants: (PlantSlot | null)[];
  unlockedRegions: RegionKey[];
  selectedRegion: RegionKey | null;
}
