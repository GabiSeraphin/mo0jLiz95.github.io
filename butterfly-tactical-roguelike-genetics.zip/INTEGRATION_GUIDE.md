# 🦋 Integration Guide - How to Merge This Into Your Existing Project

## 📂 Files You Need to Copy

### Config Files (NEW - Easy to Edit!)
Copy the entire `src/config/` folder to your project:
- `src/config/types.config.ts` - Type definitions
- `src/config/bosses.config.ts` - **All bosses - easy to edit!**
- `src/config/enemies.config.ts` - **All enemies - easy to edit!**
- `src/config/regions.config.ts` - **Regions & tiles - easy to edit!**
- `src/config/plants.config.ts` - **Plants/seeds - easy to edit!**
- `src/config/events.config.ts` - **Mystery events - easy to edit!**
- `src/config/index.ts` - Exports everything
- `src/config/README.md` - Documentation

### Core Game Files
- `src/types.ts` - Updated type definitions
- `src/genetics.ts` - Breeding & genetics system
- `src/combat.ts` - Combat logic
- `src/dungeon.ts` - Dungeon generation
- `src/enemies.ts` - Enemy creation
- `src/regions.ts` - Legacy regions (can be merged with config)
- `src/classes.ts` - Butterfly classes (14+)

### Components
- `src/components/CombatGrid.tsx` - **Updated with region tiles!**
- `src/components/ButterflyCard.tsx` - Butterfly display
- `src/components/DungeonMap.tsx` - Dungeon visualization

---

## 🔗 How to Use the Config System

### 1. Import in your code:

```javascript
// In your existing code, add these imports:
import { 
  REGIONS_CONFIG, 
  BOSSES_CONFIG, 
  ENEMIES_CONFIG,
  PLANTS_CONFIG,
  EVENTS_CONFIG,
  TILES,
  getRegion,
  getBossForRegion,
  getEnemiesForRegion,
  getRandomEventForRegion,
  generateTileGrid
} from './config';
```

### 2. Replace your existing region data:

Your current `REGIONS` object can be merged with the config:

```javascript
// OLD WAY (your code)
const REGIONS = {
  jardim_encantado: {
    name: 'Jardim Encantado',
    duration: 30000,
    nectarCost: 10,
    // ...
  }
};

// NEW WAY (merged with config)
import { REGIONS_CONFIG } from './config';

// The config has MORE data including:
// - theme (colors, particles)
// - tiles (for combat grid)
// - exclusive traits, seeds, butterflies
// - enemy/elite/boss pools
// - mystery events

const region = REGIONS_CONFIG['jardim_encantado'];
console.log(region.theme.backgroundColor);  // '#e8f5e9'
console.log(region.exclusiveTraits);         // ['asas_florais', ...]
console.log(region.tiles);                   // [tile configs...]
```

### 3. Generate tile grid for combat:

```javascript
// When starting combat, generate tiles:
import { generateTileGrid } from './config';

const tileGrid = generateTileGrid('floresta_sombria', 10, 10);
// Returns 2D array like [['darkness', 'tree', 'mushroom', ...], ...]

// Pass to CombatGrid:
<CombatGrid
  state={combatState}
  validMoves={moves}
  validTargets={targets}
  onTileClick={handleClick}
  onUnitClick={handleUnit}
  regionId="floresta_sombria"
  tileGrid={tileGrid}
/>
```

### 4. Get region-specific content:

```javascript
import { 
  getEnemiesForRegion, 
  getElitesForRegion,
  getBossForRegion,
  getEventsForRegion,
  getPlantsForRegion 
} from './config';

// Get enemies for a region
const enemies = getEnemiesForRegion('caverna_cristalina');
// Returns [{ id: 'morcego_cristal', name: '...', ... }, ...]

// Get boss
const boss = getBossForRegion('caverna_cristalina');
// Returns full boss config with abilities, phases, loot

// Get events
const events = getEventsForRegion('caverna_cristalina');
// Returns mystery events for that region
```

---

## 🎮 Merging with Your Adventure System

Your code has this structure:
```javascript
function sendOnAdventure(bfIdx) {
  const r = REGIONS[pendingAdventureRegion];
  // ...
}
```

Merge it like this:
```javascript
import { REGIONS_CONFIG, getPlantsForRegion } from './config';

function sendOnAdventure(bfIdx) {
  // Get both old and new region data
  const r = REGIONS[pendingAdventureRegion];  // Your existing data
  const regionConfig = REGIONS_CONFIG[pendingAdventureRegion];  // New config data
  
  // Use new exclusive traits
  if (regionConfig) {
    console.log('Exclusive traits:', regionConfig.exclusiveTraits);
    console.log('Exclusive butterflies:', regionConfig.exclusiveButterflies);
  }
  
  // Get plants/seeds for this region
  const regionPlants = getPlantsForRegion(pendingAdventureRegion);
  // ...
}
```

---

## 🦋 Breeding System Integration

The genetics system is already compatible with your code. Key functions:

```javascript
import { 
  createButterfly,
  breedButterflies,
  calculateInbreeding,
  getPhenotype,
  REGION_TRAIT_LABELS
} from './genetics';

// Creating butterfly with region traits
const butterfly = createButterfly({ region: 'floresta_sombria' });
// Automatically has chance for region-exclusive traits!

// Breeding
const child = breedButterflies(parent1, parent2);
// Includes inbreeding calculation, negative traits, etc.

// Get phenotype for display
const ph = getPhenotype(butterfly.genetics);
console.log(ph.colorLabel);  // "Azul Royal"
```

---

## 🏛️ How to Edit Bosses

Open `src/config/bosses.config.ts`:

```typescript
// Add a new boss:
meu_boss: {
  id: 'meu_boss',
  name: 'Meu Boss Personalizado',
  emoji: '🐲',
  description: 'Um boss incrível!',
  region: 'jardim_encantado',  // Which region
  
  baseHp: 200,
  hpPerFloor: 30,
  attack: 25,
  defense: 15,
  speed: 5,
  
  color: '#FF0000',
  size: 'huge',
  
  abilities: [
    {
      name: 'Ataque Especial',
      description: 'Faz muito dano',
      damage: 40,
      type: 'attack',
      cooldown: 3,
      effect: 'burn',
      effectDuration: 2,
      targetType: 'area',
      areaSize: 3
    }
  ],
  
  phases: [
    { hpPercent: 100, behavior: 'normal', message: 'Diálogo inicial!' },
    { hpPercent: 50, behavior: 'enraged', message: 'Estou furioso!', attackBonus: 1.5 }
  ],
  
  loot: {
    gold: { min: 150, max: 300 },
    nectar: { min: 50, max: 100 },
    guaranteedItems: ['item_especial'],
    possibleButterfly: { chance: 0.3, traits: ['trait_raro'] },
    seeds: [{ type: 'semente_rara', chance: 0.5 }]
  },
  
  dialogue: {
    intro: 'Vocês ousam me desafiar?',
    phase2: 'Agora vocês verão meu verdadeiro poder!',
    defeat: 'Impossível... derrotado por borboletas...',
    victory: 'Hahaha! Patéticos insetos!'
  }
}
```

---

## 🗺️ How to Edit Regions & Tiles

Open `src/config/regions.config.ts`:

### Add new tile:
```typescript
// In TILES object:
meu_tile: {
  id: 'meu_tile',
  name: 'Meu Tile',
  emoji: '🌺',
  color: '#FF69B4',
  walkable: true,
  effect: { type: 'heal', value: 5, message: 'Você foi curado!' },
  spawnChance: 0.1
}
```

### Add new region:
```typescript
// In REGIONS_CONFIG:
minha_regiao: {
  id: 'minha_regiao',
  name: 'Minha Região',
  description: 'Uma região incrível!',
  icon: '🏔️',
  
  theme: {
    backgroundColor: '#1a1a2e',
    gridColor: '#2d2d44',
    accentColor: '#ff6b6b',
    ambientParticles: ['✨', '🌸', '🦋']
  },
  
  tiles: [TILES.grass, TILES.flower, TILES.meu_tile],
  
  enemyPool: ['enemy1', 'enemy2'],
  elitePool: ['elite1'],
  bossId: 'meu_boss',
  
  dangerLevel: 4,
  minFloors: 5,
  maxFloors: 7,
  
  unlockRequirement: {
    type: 'defeat_boss',
    value: 'boss_anterior'
  },
  
  nectarMultiplier: 1.5,
  goldMultiplier: 1.5,
  
  exclusiveTraits: ['trait1', 'trait2'],
  exclusiveSeeds: ['seed1', 'seed2'],
  exclusiveButterflies: {
    chance: 0.15,
    traits: ['trait_exclusivo'],
    colorPool: ['Cor1', 'Cor2']
  },
  
  mysteryEvents: ['event1', 'event2']
}
```

---

## ✅ Quick Checklist

- [ ] Copy `src/config/` folder
- [ ] Update imports in main files
- [ ] Add `regionId` prop to CombatGrid calls
- [ ] Merge REGIONS data with REGIONS_CONFIG
- [ ] Test breeding with region traits
- [ ] Test combat with region tiles
- [ ] Customize bosses/enemies/events as needed

---

## 🆘 Troubleshooting

**Error: Cannot find module './config'**
→ Make sure you copied the entire `src/config/` folder

**Tiles not showing**
→ Pass `regionId` to CombatGrid component

**Region traits not appearing**
→ Make sure `createButterfly({ region: 'region_id' })` is called

**Boss not spawning**
→ Check that `bossId` in region config matches boss `id`

---

Happy coding! 🦋✨
