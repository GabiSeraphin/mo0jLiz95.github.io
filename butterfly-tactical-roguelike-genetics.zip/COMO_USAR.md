# 🦋 Como Integrar o Sistema de Regiões com Seu Código

Este guia mostra como usar os novos sistemas de regiões, sementes, e borboletas exclusivas com seu código JavaScript existente.

---

## 📁 Estrutura dos Arquivos

```
src/
├── config/
│   ├── regions.config.ts    # ⭐ TODAS AS REGIÕES - Edite aqui!
│   ├── bosses.config.ts     # ⭐ TODOS OS BOSSES - Edite aqui!
│   ├── enemies.config.ts    # Inimigos por região
│   ├── plants.config.ts     # Sementes/plantas
│   └── events.config.ts     # Eventos misteriosos
```

---

## 🗺️ AS 6 REGIÕES

Cada região tem conteúdo exclusivo:

| Região | Ícone | Seeds Exclusivas | Traits Exclusivas | Boss |
|--------|-------|------------------|-------------------|------|
| Jardim Encantado | 🌸 | Rosa, Girassol, Margarida | Garden Blessing, Petal Wings | Queen Bee 👑🐝 |
| Floresta Sombria | 🌲 | Cogumelo Lunar, Erva Sombria | Shadow Cloak, Night Vision | Arachne 🕷️👑 |
| Caverna Cristalina | 💎 | Flor de Cristal, Musgo Brilhante | Crystal Wings, Gem Sense | Prismatic Guardian 💎🗿 |
| Pântano Misterioso | 🐸 | Lírio Venenoso, Erva do Pântano | Poison Immunity, Toxic Wings | Murkmire 🧙‍♀️🐸 |
| Vulcão Ardente | 🌋 | Flor de Fogo, Cinza Viva | Flame Wings, Phoenix Blood | Ignius 🌋👑 |
| Templo Celestial | 🏛️ | Flor Celestial, Orvalho Estrelar | Divine Wings, Starborn | Lunaris 🦋👑✨ |

---

## 🎮 COMO USAR NO SEU CÓDIGO JAVASCRIPT

### 1. Importar as Regiões

```javascript
// Copie o objeto REGIONS do arquivo regions.config.ts
// e adapte para JavaScript:

const REGIONS = {
  jardim_encantado: {
    id: 'jardim_encantado',
    name: 'Enchanted Garden',
    namePt: 'Jardim Encantado',
    icon: '🌸',
    iconImg: '/images/regions/garden.png',
    
    // Configurações de aventura (timed expeditions)
    duration: 30000,  // 30 segundos
    nectarCost: 10,
    dangerLevel: 1,
    deathChance: 0.02,
    butterflyChance: 0.3,
    seedChance: 0.4,
    
    // Sementes exclusivas desta região
    seeds: ['rosa', 'girassol', 'margarida'],
    
    // Tiles para o grid de combate
    tiles: [
      { id: 'grass', emoji: '🌿', color: '#7cb342', walkable: true, spawnWeight: 50 },
      { id: 'flower_pink', emoji: '🌸', color: '#f8bbd9', walkable: true, 
        effect: { type: 'heal', value: 5, message: 'A flor te cura!' }, spawnWeight: 15 },
      // ... mais tiles
    ],
    
    // Traits exclusivas
    exclusiveTraits: [
      { id: 'garden_blessing', name: 'Bênção do Jardim', rarity: 'uncommon' },
      { id: 'petal_wings', name: 'Asas de Pétala', rarity: 'rare' }
    ],
    
    // Cores exclusivas de borboletas
    exclusiveColors: ['#FFB6C1', '#FFC0CB', '#FF69B4'],
    
    // Padrões exclusivos
    exclusivePatterns: ['spotted_pink', 'striped_gold'],
    
    // Inimigos desta região
    enemies: [
      { id: 'bee', name: 'Worker Bee', emoji: '🐝', hp: 30, attack: 8 },
      { id: 'ladybug', name: 'Angry Ladybug', emoji: '🐞', hp: 25, attack: 6 }
    ],
    
    // Boss desta região
    boss: {
      id: 'queen_bee',
      name: 'Queen Bee',
      namePt: 'Abelha Rainha',
      emoji: '👑🐝',
      hp: 200,
      attack: 15,
      phases: [
        { hpPercent: 75, message: 'Vocês ousam desafiar a Rainha?!' },
        { hpPercent: 40, message: 'Meus súditos irão destruí-los!' }
      ]
    }
  },
  // ... mais regiões
};
```

### 2. Usar no Sistema de Aventuras

```javascript
// Seu código de aventura adaptado:
function renderAdventureGrid() {
  const g = document.getElementById('adventureGrid');
  if (!g) return;
  
  g.innerHTML = Object.entries(REGIONS).map(([k, r]) => {
    // Verificar se região está desbloqueada
    const isUnlocked = GS.unlockedRegions.includes(k);
    
    return `
      <div class="adventure-card ${isUnlocked ? '' : 'locked'}" 
           onclick="${isUnlocked ? `openAdventureSelect('${k}')` : ''}">
        <div class="adventure-icon">
          ${r.iconImg ? `<img src="${r.iconImg}" alt="${r.namePt}" width="40">` : r.icon}
        </div>
        <div class="adventure-content">
          <div class="adventure-name">${r.namePt}</div>
          <div class="adventure-desc">${r.descPt}</div>
          <div class="adventure-stats">
            <span>⏱️ ${Math.round(r.duration/1000)}s</span>
            <span>🍯 ${r.nectarCost}</span>
            <span>⚠️ Lv${r.dangerLevel}</span>
            <span>☠️ ${Math.round(r.deathChance*100)}%</span>
          </div>
          ${!isUnlocked ? `<div class="unlock-req">🔒 Derrote ${r.unlockRequirement?.descriptionPt}</div>` : ''}
        </div>
        
        <!-- Mostrar sementes exclusivas -->
        <div class="exclusive-content">
          <div class="seeds-preview">
            ${r.seeds.map(s => PLANTS[s].icon).join(' ')}
          </div>
          <div class="traits-preview">
            ${r.exclusiveTraits.length} traits exclusivas
          </div>
        </div>
      </div>
    `;
  }).join('');
}
```

### 3. Encontrar Borboletas com Traits Exclusivas

```javascript
function createButterflyFromRegion(regionKey) {
  const region = REGIONS[regionKey];
  
  // Criar borboleta base
  const bf = createButterfly({});
  
  // Aplicar cores exclusivas da região (chance)
  if (Math.random() < 0.3 && region.exclusiveColors.length > 0) {
    const exclusiveColor = region.exclusiveColors[Math.floor(Math.random() * region.exclusiveColors.length)];
    bf.genetics.color = { allele1: exclusiveColor, allele2: exclusiveColor };
  }
  
  // Aplicar padrão exclusivo (chance menor)
  if (Math.random() < 0.2 && region.exclusivePatterns.length > 0) {
    const pattern = region.exclusivePatterns[Math.floor(Math.random() * region.exclusivePatterns.length)];
    bf.genetics.pattern = { allele1: pattern, allele2: pattern };
  }
  
  // Aplicar trait exclusiva (chance baseada na raridade)
  if (Math.random() < 0.15 && region.exclusiveTraits.length > 0) {
    const trait = region.exclusiveTraits[Math.floor(Math.random() * region.exclusiveTraits.length)];
    
    // Raridade afeta chance
    const rarityChance = {
      'common': 0.5,
      'uncommon': 0.3,
      'rare': 0.15,
      'legendary': 0.05
    };
    
    if (Math.random() < rarityChance[trait.rarity]) {
      bf.regionTrait = trait;
      bf.region = regionKey;
      
      // Aplicar bônus de stats
      if (trait.statBonus) {
        Object.entries(trait.statBonus).forEach(([stat, value]) => {
          bf[stat] = (bf[stat] || 0) + value;
        });
      }
    }
  }
  
  return bf;
}
```

### 4. Completar Aventura com Recompensas de Região

```javascript
function completeAdventure(i) {
  const a = GS.activeAdventures[i];
  const r = REGIONS[a.region];
  const bf = GS.butterflies.find(b => b.id === a.butterflyId);
  
  if (!bf) return;
  
  let results = [];
  
  // ... checks de sobrevivência ...
  
  // Encontrar borboleta COM TRAITS EXCLUSIVAS DA REGIÃO
  if (Math.random() < r.butterflyChance) {
    const found = createButterflyFromRegion(a.region);
    GS.butterflies.push(found);
    
    const ph = getPhenotype(found.genetics);
    let msg = `Achou ${found.name} (${ph.colorLabel})!`;
    
    // Se tem trait exclusiva, destacar!
    if (found.regionTrait) {
      msg += ` ⭐ TRAIT EXCLUSIVA: ${found.regionTrait.namePt}!`;
    }
    
    results.push(msg);
  }
  
  // Encontrar SEMENTES EXCLUSIVAS DA REGIÃO
  if (Math.random() < r.seedChance && r.seeds.length > 0) {
    const seedType = r.seeds[Math.floor(Math.random() * r.seeds.length)];
    const plant = PLANTS[seedType];
    
    const emptySlot = GS.plants.indexOf(null);
    if (emptySlot !== -1) {
      GS.plants[emptySlot] = { type: seedType, progress: 0 };
      results.push(`🌱 Encontrou semente de ${plant.namePt}! (Exclusiva de ${r.namePt})`);
    }
  }
  
  // ... resto do código ...
}
```

### 5. Gerar Grid de Tiles para Combate

```javascript
function generateRegionTileGrid(regionKey, width = 10, height = 10) {
  const region = REGIONS[regionKey];
  const grid = [];
  
  const totalWeight = region.tiles.reduce((sum, t) => sum + t.spawnWeight, 0);
  
  for (let y = 0; y < height; y++) {
    const row = [];
    for (let x = 0; x < width; x++) {
      // Seleção aleatória ponderada
      let random = Math.random() * totalWeight;
      let selectedTile = region.tiles[0];
      
      for (const tile of region.tiles) {
        random -= tile.spawnWeight;
        if (random <= 0) {
          selectedTile = tile;
          break;
        }
      }
      
      row.push({ ...selectedTile });
    }
    grid.push(row);
  }
  
  // Garantir caminho walkable
  ensureWalkablePath(grid, region.tiles);
  
  return grid;
}

function ensureWalkablePath(grid, tiles) {
  const walkableTile = tiles.find(t => t.walkable && !t.effect) || tiles.find(t => t.walkable);
  
  let x = 0, y = 0;
  while (x < grid[0].length - 1 || y < grid.length - 1) {
    grid[y][x] = { ...walkableTile };
    
    if (x < grid[0].length - 1 && y < grid.length - 1) {
      if (Math.random() < 0.5) x++;
      else y++;
    } else if (x < grid[0].length - 1) {
      x++;
    } else {
      y++;
    }
  }
  grid[grid.length - 1][grid[0].length - 1] = { ...walkableTile };
}
```

### 6. Aplicar Efeitos de Tile Durante Combate

```javascript
function applyTileEffect(unit, tile) {
  if (!tile.effect) return;
  
  const effect = tile.effect;
  
  switch (effect.type) {
    case 'heal':
      unit.stats.hp = Math.min(unit.stats.maxHp, unit.stats.hp + effect.value);
      addCombatLog(`${unit.name} ${effect.message} (+${effect.value} HP)`);
      break;
      
    case 'damage':
      unit.stats.hp -= effect.value;
      addCombatLog(`${unit.name} ${effect.message} (-${effect.value} HP)`);
      break;
      
    case 'buff':
      unit.tempAttackBonus = (unit.tempAttackBonus || 0) + effect.value;
      addCombatLog(`${unit.name} ${effect.message}`);
      break;
      
    case 'debuff':
      unit.tempSpeedPenalty = (unit.tempSpeedPenalty || 0) + effect.value;
      addCombatLog(`${unit.name} ${effect.message}`);
      break;
      
    case 'nectar':
      GS.nectar.basic += effect.value;
      addCombatLog(`${effect.message}`);
      break;
      
    case 'trap':
      unit.stunnedTurns = (unit.stunnedTurns || 0) + effect.value;
      addCombatLog(`${unit.name} ${effect.message}`);
      break;
  }
}
```

---

## ✏️ COMO EDITAR REGIÕES

### Adicionar Nova Região

```javascript
// No objeto REGIONS, adicione:
nova_regiao: {
  id: 'nova_regiao',
  name: 'My New Region',
  namePt: 'Minha Nova Região',
  icon: '🏝️',
  iconImg: '/images/regions/nova.png',
  
  duration: 60000,
  nectarCost: 50,
  dangerLevel: 3,
  deathChance: 0.1,
  butterflyChance: 0.25,
  seedChance: 0.3,
  
  backgroundColor: '#1a5a3a',
  ambientColor: '#2a8a5a',
  particleEmoji: ['🌴', '🥥', '🦜'],
  
  tiles: [
    { id: 'sand', emoji: '🏖️', color: '#f4d03f', walkable: true, spawnWeight: 40 },
    { id: 'palm', emoji: '🌴', color: '#27ae60', walkable: false, spawnWeight: 20 },
    { id: 'water', emoji: '🌊', color: '#3498db', walkable: true, 
      effect: { type: 'heal', value: 10, message: 'Água refrescante!' }, spawnWeight: 15 }
  ],
  
  exclusiveTraits: [
    { id: 'beach_lover', name: 'Amante da Praia', namePt: 'Amante da Praia', rarity: 'uncommon' }
  ],
  
  seeds: ['coqueiro', 'hibisco'],
  
  exclusiveColors: ['#FFD700', '#FF6B6B', '#4ECDC4'],
  exclusivePatterns: ['tropical_stripes', 'coconut_spots'],
  
  enemies: [
    { id: 'crab', name: 'Caranguejo', emoji: '🦀', hp: 35, attack: 12 }
  ],
  
  boss: {
    id: 'beach_king',
    name: 'Rei da Praia',
    emoji: '🦀👑',
    hp: 300,
    attack: 25
  },
  
  unlockRequirement: {
    type: 'boss',
    value: 'queen_bee',
    descriptionPt: 'Derrote a Abelha Rainha'
  }
}
```

### Editar Boss Existente

```javascript
// Encontre o boss no objeto da região e modifique:
REGIONS.jardim_encantado.boss = {
  id: 'queen_bee',
  name: 'Queen Bee',
  namePt: 'Abelha Rainha',
  emoji: '👑🐝',
  hp: 250,  // Aumentei o HP
  attack: 20,  // Aumentei o ataque
  
  // Adicionar mais fases
  phases: [
    { hpPercent: 80, message: 'Fase 1!', attackBonus: 1.1 },
    { hpPercent: 60, message: 'Fase 2!', attackBonus: 1.3 },
    { hpPercent: 40, message: 'Fase 3!', attackBonus: 1.5 },
    { hpPercent: 20, message: 'FASE FINAL!', attackBonus: 2.0 }
  ],
  
  // Adicionar mais habilidades
  abilities: [
    { name: 'Royal Sting', damage: 30, range: 2, cooldown: 2 },
    { name: 'Summon Swarm', damage: 10, range: 5, cooldown: 4 },
    { name: 'NOVA HABILIDADE', damage: 50, range: 3, cooldown: 5 }
  ],
  
  // Melhorar loot
  loot: {
    nectar: { min: 100, max: 200, type: 'basic' },
    seedChance: 0.9,  // 90% chance de seed
    butterflyChance: 0.7,  // 70% chance de borboleta
    exclusiveTraitChance: 0.5  // 50% chance de trait exclusiva
  }
};
```

---

## 📊 SISTEMA DE PLANTAS/SEMENTES

```javascript
const PLANTS = {
  rosa: {
    id: 'rosa',
    name: 'Rose',
    namePt: 'Rosa',
    icon: '🌹',
    growthTime: 100,  // ticks para crescer
    nectarType: 'Rosa',
    nectarAmount: 3,
    cost: 15,
    region: 'jardim_encantado'  // Região de origem
  },
  
  cogumelo_lunar: {
    id: 'cogumelo_lunar',
    name: 'Moon Mushroom',
    namePt: 'Cogumelo Lunar',
    icon: '🍄',
    growthTime: 150,
    nectarType: 'FlordaLua',
    nectarAmount: 5,
    cost: 40,
    region: 'floresta_sombria'
  },
  
  flor_cristal: {
    id: 'flor_cristal',
    name: 'Crystal Flower',
    namePt: 'Flor de Cristal',
    icon: '💠',
    growthTime: 200,
    nectarType: 'Cristal',
    nectarAmount: 8,
    cost: 60,
    region: 'caverna_cristalina'
  }
  // ... mais plantas
};
```

---

## 🎯 RESUMO RÁPIDO

1. **REGIONS** = Objeto com todas as 6 regiões
2. **Cada região tem**:
   - `tiles[]` = Tiles para grid de combate
   - `seeds[]` = Sementes exclusivas
   - `exclusiveTraits[]` = Traits exclusivas
   - `exclusiveColors[]` = Cores de borboleta exclusivas
   - `enemies[]` = Inimigos normais
   - `boss` = Boss final
3. **Para editar**: Modifique diretamente o objeto REGIONS
4. **Para adicionar**: Copie uma região existente e modifique

---

## 🔧 Funções Úteis

```javascript
// Obter região pelo ID
function getRegion(id) {
  return REGIONS[id];
}

// Verificar se região está desbloqueada
function isRegionUnlocked(regionId, defeatedBosses) {
  const region = REGIONS[regionId];
  if (!region.unlockRequirement) return true;
  if (region.unlockRequirement.type === 'boss') {
    return defeatedBosses.includes(region.unlockRequirement.value);
  }
  return false;
}

// Obter todas regiões desbloqueadas
function getUnlockedRegions(defeatedBosses) {
  return Object.values(REGIONS).filter(r => isRegionUnlocked(r.id, defeatedBosses));
}

// Obter sementes disponíveis para compra (baseado em regiões desbloqueadas)
function getAvailableSeeds(unlockedRegions) {
  const seeds = [];
  unlockedRegions.forEach(regionId => {
    const region = REGIONS[regionId];
    region.seeds.forEach(seedId => {
      if (!seeds.find(s => s.id === seedId)) {
        seeds.push(PLANTS[seedId]);
      }
    });
  });
  return seeds;
}
```

---

Pronto! Agora você pode copiar estas estruturas para seu código JavaScript e adaptar conforme necessário. O sistema é totalmente modular e fácil de editar! 🦋✨
